package textScripts.TechUpgrade.Domino.TPA;

import java.lang.reflect.Method;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Pages.Common.MasterPage;
import Pages.Domino.TPA.TRCreateNewInvest;
import Pages.Domino.TPA.TRImportInvestDetail;
import Pages.Domino.TPA.TRReports;
import Pages.Domino.TPA.TRSearchEdit;
import Pages.Domino.TPA.TaxReportingLoginPage;
import SupportLibraries.BaseTest;
import SupportLibraries.CommonFns;
import SupportLibraries.ListenerClass;

public class HealthCheckForTaxPlanningApp extends BaseTest
{	
	/**
	 * 1. Test case for SSO & Application Login and to verify the User Login
	 */
	
	@Test
	public void checkLogin()
	{
		try
		{
			Assert.assertTrue(cmn_Fns.clickSSOLogin("ds1"));
			Assert.assertTrue(taxReporting_logPage.getLogin());			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Login is failed ");
		}
	}	
	
	/**
	 * 2. Test Case for validating the "Create New Investment Link" under Tax Credits Section.
	 */
	@Test(dependsOnMethods = {"checkLogin"})
	public void checkCreateNewInvestmentLink()
	{
		try
		{
			taxReporting_logPage.verfyCreateNewInvest();
			Assert.assertTrue(tr_createInvestPage.fillFormCNI());
			Assert.assertTrue(tr_createInvestPage.cnfrmFomrSubmission());
			Assert.assertTrue(tr_createInvestPage.clearForm());			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Failed to Navigate through Create New Investment Link");
		}
	}
	
	/**
	 * 3. Test case for checking import Investment Detail
	 */
	@Test(dependsOnMethods = {"checkLogin"})
	public void importInvestmentCheck()
	{
		try
		{
			Assert.assertTrue(taxReporting_logPage.goHome());
			taxReporting_logPage.verfyImportInvestDetl();
			Assert.assertTrue(tr_importInvestDetl.verfyImportPage());
			tr_importInvestDetl.checkImport();			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Cant click on Import Investment Detail");
		}
	}
	
	/**
	 * 4. Test Case for checking the Search/Edit Link
	 */
	@Test(dependsOnMethods = {"checkLogin"})
	public void searchAndEditCheck()
	{
		try
		{
			Assert.assertTrue(taxReporting_logPage.goHome());
			taxReporting_logPage.verfySearchEdit();
			Assert.assertTrue(tr_srchEdit.verfySearchEditPage());
			Assert.assertTrue(tr_srchEdit.checkSearchAndEdit());
			Assert.assertTrue(tr_srchEdit.editData());
			Thread.sleep(500);
			Assert.assertTrue(tr_srchEdit.cloneData());
			Assert.assertTrue(tr_srchEdit.deleteRecrd());			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Cant click on Search/Edit");
		}
	}
	
	/**
	 * 5. Test case for Checking the Reports section
	 */
	@Test(dependsOnMethods = {"checkLogin"})
	public void verifyReports()
	{
		try
		{
			Assert.assertTrue(taxReporting_logPage.goHome());
			taxReporting_logPage.verfyReports();
			Assert.assertTrue(tr_report.checkReportsVerfy());
			//Assert.assertTrue(tr_report.fillAndGenRprt());			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Cant click on Reports");
		}
	}
	
	/**
	 * 6. check Cases for Checking the Help Link
	 */
	@Test(dependsOnMethods = {"checkLogin"})
	public void verifyHelpLink()
	{
		try
		{
			Assert.assertTrue(taxReporting_logPage.goHome());
			Assert.assertTrue(taxReporting_logPage.verfyHelpLnk());
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail("Help Link is failing");
		}
	}
	
	/**
	 * Initialize method for instantiating the each page classes objects. 
	 * This method will be invoked before executing all the test cases
	 **/
	@BeforeClass
	public void intialize() 
	{
		masterpage = new MasterPage(driverScript.getBaseTest().getScriptHelper()); 
		cmn_Fns = new CommonFns(driverScript.getBaseTest().getScriptHelper());
		taxReporting_logPage = new TaxReportingLoginPage(driverScript.getBaseTest().getScriptHelper());
		tr_createInvestPage = new TRCreateNewInvest(driverScript.getBaseTest().getScriptHelper());
		tr_importInvestDetl = new TRImportInvestDetail(driverScript.getBaseTest().getScriptHelper());
		tr_srchEdit = new TRSearchEdit(driverScript.getBaseTest().getScriptHelper());
		tr_report = new TRReports(driverScript.getBaseTest().getScriptHelper());
	}
	
	/**
	 * getMethodName method sets the current test case Name.
	 * This method will be invoked once before executing every test cases
	 * @param method
	 **/
	@BeforeMethod
	public void getMethodName(Method method) 
	{
		masterpage.setCurrentTestCaseName(method.getName());		
	}

}
