package SupportLibraries;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import Pages.Common.MasterPage;
import Utils.StringEncrypt;

public class CommonFns extends MasterPage
{
	
	By uNameTextBox    	= By.name("USER");
	By uPwdTextBox    	= By.name("PASSWORD");
	By signOnButton	 	= By.xpath("//input[@class='button' and @value='Sign On']");
	public static String logoffWindow_1 = null;

	public CommonFns(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);
	}

	/**
	 * Common function for SSO Login
	 **/
	public boolean clickSSOLogin(String dataSet) throws Exception
	{
		String userName;
		try
		{
			driver.manage().window().maximize();
			driver.get(properties.getProperty("SSOLoginURL"));
			userName = dataLoader.getTestdata("LoginData", dataSet,"UserID");
			String key = dataLoader.getTestdata("LoginData", dataSet, "Key");                                         
            String passWord = dataLoader.getTestdata("LoginData", dataSet,"Password");
            String decodedPwd = StringEncrypt.decryptXOR(passWord,key);      
			getElement(uNameTextBox).clear();
			getElement(uNameTextBox).sendKeys(userName);			
			getElement(uPwdTextBox).clear();
			getElement(uPwdTextBox).sendKeys(decodedPwd);			
			getElement(signOnButton).click();
			Thread.sleep(3000);
			return true;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Failed to launch the application");
			throw new Exception("Failed to Launch Application");
		}
	}
	
}
