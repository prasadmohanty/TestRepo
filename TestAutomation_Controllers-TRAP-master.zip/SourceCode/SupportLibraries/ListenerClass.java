package SupportLibraries;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;


/**
 * 
 * ListenerClass implements all the listener methods and Report generation methods
 * @author Cognizant
 *
 */
public class ListenerClass  extends TestListenerAdapter {
	
	DataLoader loader=new DataLoader();
	DateFormat dateFormat                                           = new SimpleDateFormat("dd_MMM_yyyy__hh_mm_ssaa");
	private static long testCaseExecutionTime 						= 0;
	private static int 	passCount			  						= 0;
	private static int failCount   			  						= 0;
	private static int skipCount             					    = 0;
	private static LinkedHashMap<String, String> resultTable 		= new LinkedHashMap<String, String>();
	private static String destDir									= "\\"+ Settings.getInstance() != null ? (Settings.getInstance()).getProperty("screenShotLocation") : null;
	private static String pdfDestDir 								= "\\"+ Settings.getInstance() != null ? (Settings.getInstance()).getProperty("pdfFileLocation") : null;;
	public  static int executionCount								= 0;
    public 	static int flagCount									= 0;
    public  static long totalExecutionCount						    = 0;
    public static String methodPurpose								= "";
	public static String suiteName									= "";
	public static String errorMessage                               = null;
	public static boolean qaFailureFlag                             = false;
	public static boolean intFailureFlag                            = false;
	public static String strAppName			  						= "";
	public static String strBusinessArea			  				= "";
	  

	/**
	 * Invoked after the test class is instantiated and before any configuration method is called
	 */
	
	@Override
	public void onStart(ITestContext tc) {
		suiteName=tc.getSuite().getName();
		String strTestNGSuiteXMLPath = tc.getSuite().getXmlSuite().getFileName();
		String[] strDirs = strTestNGSuiteXMLPath.split(Pattern.quote(File.separator));
//		strAppName = strDirs[strDirs.length - 1].replaceFirst("Test.xml", "");
//		strBusinessArea = strDirs[strDirs.length - 2];
		String[] strFileNameParts = strDirs[strDirs.length - 1].split("_");
        strAppName = strFileNameParts[1];
        strBusinessArea = strFileNameParts[0]; 
		loader.LoadDatatables();
	}
	
	/**
	 * Overridden method from TestListenerAdapter class in test NG. This method
	 * will be invoked automatically once a test case fails
	 * 
	 * @param ITestResult
	 */
	@Override
	
	public void onTestFailure(ITestResult tr) {
		String screenShotFileName;
		String methodName = tr.getName();
		if(suiteName.contains("pdf"))
			screenShotFileName=backUpPdfAndReturnFileName(methodName);
		else
		
	    screenShotFileName = createScreenShotReturnFileName(methodName);
		

		qaFailureFlag = true;
		failCount++;
		testCaseExecutionTime=tr.getEndMillis()-tr.getStartMillis();		
		testCaseExecutionTime = testCaseExecutionTime/1000;
		try{
		methodPurpose=loader.getTestdata("Purpose", methodName, "Purpose");
		}
		catch(Throwable e){
			methodPurpose=null;	
		}
		resultTable.put(tr.getName(), tr.getName() + "@" + methodPurpose + "@"
				+ "Failed" + "@" + screenShotFileName + "@" + errorMessage+"@"+testCaseExecutionTime);
		errorMessage=null;
		totalExecutionCount=totalExecutionCount+testCaseExecutionTime;
	}

	
	/**
	 * Overridden method from TestListenerAdapter class in test NG. This method
	 * will be invoked automatically once a test case passes
	 * 
	 * @param ITestResult
	 */
	@Override
	public void onTestSuccess(ITestResult tr) {
		String screenShotFileName;
		String methodName = tr.getName();
		passCount++;
		if(suiteName.contains("pdf"))
			screenShotFileName=backUpPdfAndReturnFileName(methodName);
		else
		
	    screenShotFileName = createScreenShotReturnFileName(methodName);
		testCaseExecutionTime=tr.getEndMillis()-tr.getStartMillis();
		testCaseExecutionTime  = Math.round((float) testCaseExecutionTime/1000);
		try{
			methodPurpose=loader.getTestdata("Purpose", methodName, "Purpose");
			}
			catch(Throwable e){
				methodPurpose=null;		
			}
		
		resultTable.put(tr.getName(), tr.getName() + "@" + methodPurpose + "@"
				+ "Passed" + "@" + screenShotFileName + "@" + "NA"+"@"+testCaseExecutionTime);
		totalExecutionCount=totalExecutionCount+testCaseExecutionTime;


	}
		
	/**
	 * Overridden method from TestListenerAdapter class in test NG. This method
	 * will be invoked automatically once a test case skip
	 * 
	 * @param ITestResult
	 */

	@Override
	public void onTestSkipped(ITestResult tr) {
		String methodName = tr.getName();
		skipCount++;
		try{
			methodPurpose=loader.getTestdata("Purpose", methodName, "Purpose");
			}
			catch(Throwable e){
				methodPurpose=null;	
			}
		testCaseExecutionTime=tr.getEndMillis()-tr.getStartMillis();
		testCaseExecutionTime = testCaseExecutionTime/1000;
		resultTable.put(tr.getName(), tr.getName() + "@" + methodPurpose + "@"
				+ "Skipped" + "@" + "NA" + "@" + "NA"+"@"+testCaseExecutionTime);
		totalExecutionCount=totalExecutionCount+testCaseExecutionTime;



	}

	/**
	 * Invoked after all the tests have run and all their Configuration methods have been called.
	 */
	@Override
	public void onFinish(ITestContext tc) {
		
		 executionCount++;
		 flagCount++;
		HtmlGenerator.generateHtmlFile(resultTable,  passCount, failCount, skipCount);
				
	}
	
	
	
	/**
	 * Method takes screen shot and return the screen shot file name
	 * @param methodName
	 * @return
	 */
	/*private String createScreenShotReturnFileName(String methodName) 
	{
        File scrFile = ((TakesScreenshot) BaseTest.getWebDriver()).getScreenshotAs(OutputType.FILE);
        String destFile = methodName + dateFormat.format(new Date()) + ".png";
        String filepath = "W://TEMP//Screenshot//TRAP//";
        try 
        {
               FileUtils.copyFile(scrFile, new File(filepath + destFile));
        } 
        catch (IOException e) 
        {
               e.printStackTrace();
        }
        return filepath + destFile;
	}*/

	private String createScreenShotReturnFileName(String methodName) 
	{
		File scrFile = ((TakesScreenshot) BaseTest.getWebDriver())
				.getScreenshotAs(OutputType.FILE);
		String destFile = methodName + dateFormat.format(new Date()) + ".png";

		try {
			FileUtils.copyFile(scrFile, new File(destDir + "/" + destFile));
		} catch (IOException e) {
			e.printStackTrace();
		}

		return destDir + "/" + destFile;

	}
	
	/**
	 * Method saves the pdf file to a shared location and return the  file name
	 * @param methodName
	 * @return
	 */
	private String backUpPdfAndReturnFileName(String methodName) {
		
		String destFile = methodName + dateFormat.format(new Date()) + ".pdf";
		try {
			File srcFile = new File("C://Users/"
					+ System.getProperty("user.name")
					+ "/Downloads/ReportProxy.pdf");

			try {
				FileUtils.copyFile(srcFile, new File(pdfDestDir + destFile));
							} catch (IOException e) {

				e.printStackTrace();
			}

		} catch (Throwable t) {

		}
		return pdfDestDir  + destFile;
	}
	
	/**
	 * Method to set the error message. this message will be logged in to report as failure cause
	 * 
	 */

	
	public static  void setErrorMessage(String errorMessage){
		if(ListenerClass.errorMessage==null)
			ListenerClass.errorMessage=errorMessage;
	}
	
}
