package SupportLibraries;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import org.apache.commons.io.FileUtils;

public class HtmlGenerator {

	static StringBuffer bf = new StringBuffer();
	static String timeStamp;

	// static DateFormat formatSystemTime=new SimpleDateFormat("hh:mm:ss");
	
	/**
	 * Method to generate customized html report 
	 * @param resultTable
	 * @param failCount
	 * @param skipCount
	 * @param passCount
	 */
	public static void generateHtmlFile(
			
			LinkedHashMap<String, String> resultTable, int passCount,
			int failCount, int skipCount) {
		    
			DateFormat dateFormat  			 = new SimpleDateFormat("dd_MMM_yyyy__hh_mm_ssaa");
			timeStamp              			 = dateFormat.format(new Date());
			String cssPath                   = "\\"+ "\\HO\\dfs03\\cts_automation\\00_Selenium\\NMC\\DashboardTest\\CSS\\mystyle.css";
			String browser                   = Settings.getInstance() != null ? (Settings.getInstance()).getProperty("DefaultBrowser") : null;
			
			bf.append("<html>");
			bf.append("<head>");
			bf.append("<style>header{background-color:black;color:white;text-align:center;padding:5px;}");
			bf.append("nav{line-height:30px;background-color:#eeeeee;height:30px;width:100px;float:left;padding:5px;font-family:verdana;font-weight:bold}");
			bf.append("section{width:350px;float:left;padding:10px;}");
			bf.append("h2{font-size:100%}");
			bf.append("footer{background-color:black;color:white;clear:both;text-align:center;padding:5px;}");
			bf.append("table th{background:#333;color:white;font-weight:bold;padding:6px;border:1px solid #ccc;text-align:left;}");
			bf.append("table td{padding:6px;border:1px solid#ccc;text-align:left}</style>");

			// bf.append("<linkm rel=\"stylesheet>\" type=\"text/css\" href=\"%s\">");
			bf.append(String
					.format("<linkm rel=\"stylesheet>\" type=\"text/css\" href=\"%s\">",
							cssPath));
			bf.append("</head>");
			bf.append("<body>");
			bf.append("<header>");
			bf.append("<h1> Test Execution Result</h1>");
			bf.append("</header>");
			bf.append("<h2>Report Generated At:" + timeStamp + "</h2>");
			bf.append("<h2>Executed On Browser:" + browser + "</h2>");
			bf.append("<h2>Executed Suite :" + ListenerClass.suiteName + "</h2>");
//			bf.append("<section>");

			generateTable(resultTable, passCount, failCount, skipCount);

			completeHtmlCreation();
		

	}

	private static void generateTable(
			LinkedHashMap<String, String> resultTable, int passCount,
			int failCount, int skipCount) {
		int serialNumber = 0;
		String totalCount = String.valueOf(passCount + failCount + skipCount);
		bf.append("<h2>Execution Results </h2>");
		bf.append("<div style=\"width:100%\">");
        bf.append("<table border=\"1\" style=\"width:100%\" align=\"center\">"); 
		bf.append("<th>SlNo</th>");
		bf.append("<th>Test Case Name</th>");
		bf.append("<th>Test Case Purpose &ensp;&emsp;&ensp;&emsp;&ensp;&emsp;&ensp;&emsp;&ensp;&emsp;&ensp;&emsp;&ensp;&emsp;</th>");
		bf.append("<th>Execution Status</th> ");
		bf.append("<th>Screen Shots</th>");
		bf.append("<th>Failure Reason</th>");
		bf.append("<th>ExecutionTime(in Seconds)</th>");
		Set<String> resultTablekeys = resultTable.keySet();
		Iterator keys = resultTablekeys.iterator();

		while (keys.hasNext()) {
			String key = keys.next().toString();
			String[] keySplit = resultTable.get(key).split("@");
			serialNumber++;
			bf.append("<tr>");
			bf.append("<td>" + serialNumber + "</td>");
			bf.append("<td>" + keySplit[0] + "</td>");
			bf.append("<td>" + keySplit[1] + "</td>");
			if (keySplit[2].equalsIgnoreCase("Passed")) {
				bf.append("<td bgcolor=\"#006400\">" + keySplit[2] + "</td>");
				bf.append(String.format(
						"<td><a href=\"%s\">ScreenShot</a></td>", keySplit[3]));
			}

			else if (keySplit[2].equalsIgnoreCase("Failed")) {
				bf.append("<td bgcolor=\"#DC143C\">" + keySplit[2] + "</td>");
				bf.append(String.format(
						"<td><a href=\"%s\">ScreenShot</a></td>", keySplit[3]));
			} else {
				bf.append("<td bgcolor=\"#FF8C00\">" + keySplit[2] + "</td>");
				bf.append("<td>NA</td>");
			}
			bf.append("<td>" + keySplit[4] + "</td>");
			bf.append("<td>" + keySplit[5] + "</td>");
			bf.append("</tr>");
		}

		bf.append("</table>");
		 bf.append("</div>");
		bf.append("<h1>Execution Summary</h1>");
		bf.append("<table border=\"1\" style=\"float:center\" style=\"width:100%\">");
		bf.append("<tr>");
		bf.append("<td>Total Executed</td>");
		bf.append("<td>" + totalCount + "</td>");
		bf.append("</tr>");
		bf.append("<tr>");
		bf.append("<td>Passed</td>");
		bf.append("<td>" + passCount + "</td>");
		bf.append("</tr>");
		bf.append("<tr>");
		bf.append("<td>Failed</td>");
		bf.append("<td>" + failCount + "</td>");
		bf.append("</tr>");
		bf.append("<tr>");
		bf.append("<td>Skipped</td>");
		bf.append("<td>" + skipCount + "</td>");
		bf.append("</tr>");
		bf.append("<tr>");
		bf.append("<td>Total Execution Time(in Seconds)</td>");
		bf.append("<td>" + ListenerClass.totalExecutionCount + "</td>");
		bf.append("</tr>");
		bf.append("</table>");
       
	}

	private static void completeHtmlCreation() 
	{
//		bf.append("</section>");
		bf.append("<footer>NorthWesternMutual.com</footer>");
		bf.append("</body>");
		bf.append("</html>");

		String destDirHtml = "./HtmlReport";
			File parentFolder	= new File("./HtmlReport");
			String destFldHtml = "C://Users//ANA5334//TEST";
		String destFile = ListenerClass.suiteName + ".html";
		File html = new File(destDirHtml + "/" + destFile);
			//File htmlLoc = new File(destFldHtml + "/" + destFile);
			File htmlLoc = new File(destFldHtml);
		try 
		{
			BufferedWriter bfr = new BufferedWriter(new FileWriter(html));
			bfr.write(bf.toString());
			bfr.flush();
			bfr.close();
				FileUtils.copyDirectoryToDirectory(parentFolder, htmlLoc);
				//FileUtils.copyFile(html, htmlLoc);
		}		
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

}
