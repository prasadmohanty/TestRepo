package Pages.Domino.TPA;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class TRReports extends MasterPage 
{
	
	By rprtVerfyTxt				= By.xpath("//td[contains(text(),'Tax Credit - Reports')]");
	By reportYear				= By.id("txtReportYear");
	By genReportBtn				= By.id("searchButton");
	
	String year					= "2015";
	
	public TRReports(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);
	}
	
	/**
	 * Function for verifying the Reports Page 
	 * @throws Exception 
	 */
	public boolean checkReportsVerfy() throws Exception
	{
		try
		{
			if(getElement(rprtVerfyTxt).getText().contains("Tax Credit - Reports"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant Naviagte to Reports Page : ");
			throw(new Exception());
		}
	}
	
	/** 
	 * Function for fill data and to generate report
	 * @throws Exception 
	 */
	public boolean fillAndGenRprt() throws Exception
	{
		Robot rb = new Robot();
		int i =0;
		try
		{
			getElement(reportYear).sendKeys(year);
			clickUsingJavaScript(getElement(genReportBtn));
			Thread.sleep(4000);
			while(i<5)
			{
				Thread.sleep(2000);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				i++;
			}
			Thread.sleep(2500);	
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);				
			Thread.sleep(2500);
			
			if(isReportFileDownloaded("TCR_Report.xls"))
			{
				String filepath = "C://Users/"+getCutrrentLoggedInUser()+"/Downloads";
				File file = new File(filepath);
				FileUtils.cleanDirectory(file);
				return true;
			}
			return false;			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Report Cant be Generated : " + t.getMessage());
			throw(new Exception());
		}
	}
}
