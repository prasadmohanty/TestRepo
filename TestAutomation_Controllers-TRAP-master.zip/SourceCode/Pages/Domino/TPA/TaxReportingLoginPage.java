package Pages.Domino.TPA;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class TaxReportingLoginPage extends MasterPage
{
	By loginVerifyText			= By.partialLinkText("Home");
	By createNewInvestLink		= By.partialLinkText("Create New Investment");
	By homeVerifyText			= By.id("mainmenu");
	By importInvestDetail		= By.partialLinkText("Import Investment Detail");
	By homeLink					= By.xpath("//a[text()='Home']");
	By searchAndEdit			= By.partialLinkText("Search / Edit");
	By reportsLink				= By.partialLinkText("Tax Credit Reports");
	By helpLink					= By.xpath("//a[text()='Help']");
	By helpLinkText				= By.xpath("//span[@class='trapHeader']");
	By frameLink				= By.xpath("//div[@class='help-header']/iframe");
	
	String verfyHomeText		= "Main Menu";
	String helpURL				= "http://ws39test.nml.com/invtrap03/html/Help/TrapHelp.html";
	String reqText				= "Help	Document";
	
	public TaxReportingLoginPage(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);
		
	}
	

	/**
	 * function to Go Back to Home Page
	 * @throws Exception 
	 */
	public boolean goHome() throws Exception
	{
		try
		{
			getElement(homeLink).click();
			if(getElement(homeVerifyText).getText().contains(verfyHomeText))
				return true;
			return false;	
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Not able to navigate to Home Page: ");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for Logging into the Tax reporting application
	 * @throws Exception 
	 */
	
	public boolean getLogin() throws Exception
	{
		try
		{
			driver.get(properties.getProperty("TaxReportingURL"));
			if(getElement(loginVerifyText).getText().contains("Home"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant load the Tax Reprting Page :: ");
			throw(new Exception());
		}
	}
	
	/**
	 * function for checking the "Create New Investment" Link
	 * @throws Exception 
	 */
	
	public void verfyCreateNewInvest() throws Exception
	{
		try
		{
			getElement(createNewInvestLink).click();
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Create New Investment Link is not working : ");
			throw(new Exception());
		}
	}
	
	/**
	 * function to Click on Import Investment detail link and go Inside it
	 * @throws Exception 
	 */
	
	public void verfyImportInvestDetl() throws Exception
	{
		try
		{
			getElement(importInvestDetail).click();
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant click on Import Invest Detial Link : ");
			throw(new Exception());
		}
	}
	
	/**
	 * function for clicking the Search/Edit Link and to go Inside it
	 * @throws Exception 
	 */
	public void verfySearchEdit() throws Exception
	{
		try
		{
			getElement(searchAndEdit).click();
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant click on Search/Edit Link : ");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for checking the Reports Section
	 * @throws Exception 
	 */
	public void verfyReports() throws Exception
	{
		try
		{
			getElement(reportsLink).click();			
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant click on Reports Link : ");
			throw(new Exception());
		}
	}
	
	/**
	 * function for checking the Help Link
	 * @throws Exception 
	 */
	public boolean verfyHelpLnk() throws Exception
	{
		try
		{		
			clickUsingJavaScript(getElement(helpLink));
			Set<String> handle = driver.getWindowHandles();
			Iterator <String> itr = handle.iterator();			
			while(itr.hasNext())
			{
				driver.switchTo().window(itr.next());
				if(driver.getCurrentUrl().contains(helpURL))
					break;
			}
			driver.switchTo().frame(getElement(frameLink));			
			if(getElement(helpLinkText).getText().contains("Help"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant click on HELP Link : ");
			throw(new Exception());
		}
	}
}
