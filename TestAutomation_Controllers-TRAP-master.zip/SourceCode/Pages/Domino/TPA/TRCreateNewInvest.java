package Pages.Domino.TPA;

import org.openqa.selenium.By;
import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class TRCreateNewInvest extends MasterPage 
{
	String idText			= "912810FP8";
	String date				= "12/01/2016";
	String verfySuccess		= "SUCCESS";
	
	By idColumn				= By.name("primaryID");
	By searchLink			= By.xpath("//img[@class='imgButton cursor-style']");
	By acqDate				= By.name("acqDate");
	By sbmtBtn				= By.id("submitBtn");
	By checkSuccessText		= By.xpath("//tbody[@id='sortTbody']/tr[2]/td/span");
	By okBtn				= By.id("okButton");
	By issuerNamCol			= By.name("issuerName");
	By invAssNum			= By.name("invAssetIdNum");
	By homeLink				= By.xpath("//a[text()='Home']");
	By okCheckBtn			= By.xpath("//span[text()='OK']");
	By searchAndEdit		= By.partialLinkText("Search / Edit");
	By searchTextFld		= By.id("txtPrimaryID");
	By cloneYesBtn			= By.xpath("//span[text()='Yes']");
	By deleteRcrdBtn		= By.xpath("//tr[@id='row0']/td[14]/img");
	By searchBtn			= By.id("searchButton");
	By createNewInvestLink	= By.partialLinkText("Create New Investment");
	By clearBtn				= By.id("clearButton");

	public TRCreateNewInvest(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);	
	}
	
	/**
	 * Function for inputing values and to check its populating
	 * @throws Exception 
	 */
	public boolean fillFormCNI() throws Exception
	{
		try
		{
			getElement(idColumn).sendKeys(idText);
			getElement(searchLink).click();
			Thread.sleep(2500);
			getElement(acqDate).sendKeys(date);
			getElement(sbmtBtn).click();			
			if(isElementVisible(okCheckBtn, 3))
			{
				clickUsingJavaScript(getElement(okCheckBtn));
				getElement(homeLink).click();
				getElement(searchAndEdit).click();
				getElement(searchTextFld).sendKeys(idText);
				getElement(searchBtn).click();
				getElement(deleteRcrdBtn).click();
				getElement(cloneYesBtn).click();
				getElement(homeLink).click();
				getElement(createNewInvestLink).click();
				getElement(idColumn).sendKeys(idText);
				getElement(searchLink).click();
				Thread.sleep(2000);
				getElement(acqDate).sendKeys(date);
				getElement(sbmtBtn).click();
			}
			if(getElement(checkSuccessText).getText().contains(verfySuccess))
					return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("ID Does not exist : ");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for Clicking OK and then to clear filled form Data
	 * @throws Exception 
	 */
	public boolean cnfrmFomrSubmission() throws Exception
	{
		try
		{
			Thread. sleep(500);			
			getElement(okBtn).click();
			getElement(okBtn).click();   
			if(getElement(sbmtBtn).getAttribute("value").contains("Submit"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("cant submit forma data and return to the page : ");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for clearing form Data
	 * @throws Exception 
	 */
	public boolean clearForm() throws Exception
	{
		try
		{
			getElement(idColumn).sendKeys(idText);
			getElement(searchLink).click();
			getElement(clearBtn).click();
			if(getElement(idColumn).getText().isEmpty())
				if(getElement(issuerNamCol).getText().isEmpty())
					if(getElement(invAssNum).getText().isEmpty())
						return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("cant clear the fomr data : ");
			throw(new Exception());
		}
	}
}
