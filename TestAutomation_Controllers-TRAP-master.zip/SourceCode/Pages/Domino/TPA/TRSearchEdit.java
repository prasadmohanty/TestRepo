package Pages.Domino.TPA;

import org.openqa.selenium.By;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class TRSearchEdit extends MasterPage
{
	String idSearchText				= "912810FP8";
	
	By searchTextFld				= By.id("txtPrimaryID");
	By searchBtn					= By.id("searchButton");
	By verfySerchEdtText			= By.xpath("//td[contains(text(),'Tax Credit - Search')]");	
	By primryIdText					= By.id("txtPrimaryID0");
	By prmryIdTextClone				= By.id("txtPrimaryID2");	
	By editImg						= By.id("editButton0");
	By saveBtn						= By.id("saveButton0");
	By cloneBtn						= By.xpath("//tr[@id='row0']/td[13]/img");
	By cloneYesBtn					= By.xpath("//span[text()='Yes']");
	By cloneErrOkBtn				= By.xpath("//span[text()='Yes']");
	By deleteRcrdBtn				= By.xpath("//tr[@id='row0']/td[14]/img");
	By delteCloneRcrdBtn			= By.xpath("//tr[@id='row2']/td[14]/img");;
	
	public TRSearchEdit(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);	
	}
	
	/**
	 * Function verifying the Search/Edit Page
	 * @throws Exception 
	 */
	public boolean verfySearchEditPage() throws Exception
	{
		try
		{
			if(getElement(verfySerchEdtText).getText().contains("Tax Credit - Search"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Search/Edit Link is not working : ");
			throw(new Exception());
		}
	}
	/**
	 * Function for Checking the EDIT/Search Option
	 * @throws Exception 
	 */
	public boolean checkSearchAndEdit() throws Exception
	{
		try
		{
			getElement(searchTextFld).sendKeys(idSearchText);
			getElement(searchBtn).click();
			if(getElement(primryIdText).getAttribute("value").toString().matches(idSearchText))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant Navigate to Search/Edit Option : ");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for editing the data
	 * @throws Exception 
	 */
	public boolean editData() throws Exception
	{
		try
		{
			getElement(editImg).click();
			if(getElement(saveBtn).isDisplayed() && getElement(saveBtn).isEnabled())
			{
				getElement(saveBtn).click();
				return true;
			}
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Edit is not working : ");
			throw(new Exception());
		}
	}
	
	/**
	 * function for making clone for a record
	 * @throws Exception 
	 */
	public boolean cloneData() throws Exception
	{
		try
		{
			getElement(cloneBtn).click();
			getElement(cloneYesBtn).click();
			if(getElement(prmryIdTextClone).getAttribute("value").contains(idSearchText))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Clone option is not working : ");
			throw(new Exception());
		}
	}
	
	/** 
	 * function for deleting the record
	 * @throws Exception 
	 */
	public boolean deleteRecrd() throws Exception
	{
		try
		{			
			getElement(delteCloneRcrdBtn).click();
			getElement(cloneYesBtn).click();
			getElement(deleteRcrdBtn).click();
			getElement(cloneYesBtn).click();			
			return !isElementVisible(primryIdText,2);
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Delete option is not working : ");
			throw(new Exception());
		}
	}
}
