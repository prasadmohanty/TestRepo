package Pages.Domino.TPA;

import org.openqa.selenium.By;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class TRImportInvestDetail extends MasterPage 
{
	
	By browseBtn				= By.id("filePath");
	By verfyImportPage			= By.xpath("//td[contains(text(),'Tax Credit - Import')]");
	By importBtn				= By.id("importButton");			
	
			
	String filePath				= System.getProperty("user.dir")+"\\Resources\\TaxCreditImport_V101.csv";
	String autoItPath			= "./AutoIT/Upload.exe";

	public TRImportInvestDetail(ScriptHelper scriptHelper) 
	{
		super(scriptHelper);
	}
	
	/** 
	 *  function for uploading the csv file
	 * @throws Exception 
	 */
	public void checkImport() throws Exception
	{
		try
		{
			getElement(browseBtn).sendKeys(filePath);
//			getElement(browseBtn).click();
//			String [] cmd = {autoItPath,filePath};
//			Runtime.getRuntime().exec(cmd);	
//			Thread.sleep(3000);
			getElement(importBtn).click();
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Importing is not working :");
			throw(new Exception());
		}
	}
	
	/**
	 * Function for checking Verify to see if we are on the Tax-Credit Import page
	 */
	public boolean verfyImportPage() throws Exception
	{
		try
		{
			if(getElement(verfyImportPage).getText().contains("Tax Credit - Import"))
				return true;
			return false;
		}
		catch(Throwable t)
		{
			ListenerClass.setErrorMessage("Cant navigate to Import Page : ");
			throw(new Exception());
		}
	}
}
