package com.test.runner;
import cucumber.api.junit.Cucumber;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
public class TestRunner {
	

	@RunWith(Cucumber.class)
	@CucumberOptions(
			dryRun = false,
	features = "classpath:featureFiles",
			glue = {"com.test.bindings"},
			plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"},
			monochrome=true"}
			)
	//@CucumberOptions(plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"})
	public class TestRunner {

	} 
}
