package runner;

import org.junit.runner.RunWith;

import cucumber.api.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="/cucumberdemo/features",
		glue={"/cucumberdemo/src/main/java/stepDefiition"},
		plugin={"pretty","html:target/cucumber-html-report","json:target/json"}
		//,tags={"@wip"}
		)
public class TestRunner {

}
