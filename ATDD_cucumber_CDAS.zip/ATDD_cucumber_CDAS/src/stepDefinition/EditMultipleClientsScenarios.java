package stepDefinition;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.Scenario;
import cucumber.api.java.After;
//import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;

public class EditMultipleClientsScenarios extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	 /*@Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	
	 
	 @And("^click on edit multiple client option$")
	 public void edit_multiple_client() throws Throwable {
		    Thread.sleep(4000);
	    	driver.findElement(By.xpath("//*[@id='editMultipleCards']")).click();
			
	 }
	  
	 @And("^I test the cancel edit multiple button option$")
	 public void cancel_edit_multiple_client() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='cancelMulSelect']")).click();
		    Thread.sleep(4000);
	    	driver.findElement(By.xpath("//*[@id='editMultipleCards']")).click();
			
	 }
	 
	 @And("^click on a single card edit radio button$")
	 public void single_radio_button() throws Throwable {
		   driver.findElement(By.xpath("//*[@id='card-3']/div/div[3]/label")).click();
		 
	 }
	 
	 @Then("^I should find the next edit button as disabled$")
	 public void next_button_disabled() throws Throwable {
		   Thread.sleep(1000);
		    boolean next=driver.findElement(By.xpath("//*[@id='btnNext']")).isEnabled();
			System.out.println(next);
			Assert.assertEquals(next,false);
			System.out.println("clicked on next button which is disabled");
		 
	 }
	 
	 @And("^I click on another edit card radio button and next$")
	 public void second_radio_button() throws Throwable {
		  driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
		  driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 @Then("^I land on edit screen and edit details$")
	 public void edit_details() throws Throwable {
		    Thread.sleep(4000);
		    Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			//input("dateOfBirth_xpath", data.get("Date of Birth"));
		    //input("TaxID_xpath", data.get("Tax Payer ID"));
			Select sal= new Select(driver.findElement(By.xpath(".//*[@id='ddlprefix']")));
			sal.selectByVisibleText("Atty");
			Select lin= new Select(driver.findElement(By.xpath(".//*[@id='ddllineage']")));
			lin.selectByVisibleText("I");
			Select cert= new Select(driver.findElement(By.xpath(".//*[@id='certificationform']")));
			cert.selectByVisibleText("W-9: Backup Withholding");
			Select back= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			back.selectByVisibleText("Not Required");
			Thread.sleep(7000);
			//click("corporate_xapth");
			driver.findElement(By.xpath("//*[@id='tincorporatetab']")).click();
			Select certt= new Select(driver.findElement(By.xpath(".//*[@id='certificationform']")));
			certt.selectByVisibleText("W-9: Backup Withholding");
			Select backk= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			backk.selectByVisibleText("Not Required");
			//click("personal_xpath");
			Thread.sleep(7000);
			driver.findElement(By.xpath("//*[@id='tinpersontab']")).click();
	 }			
	 @And("^click next$")
	 public void next() throws Throwable {
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			Thread.sleep(7000);
			driver.findElement(By.xpath("//*[@class='modal fade in']/div/div/div[3]/div/div/button[text()='Accept']")).click();
	 }
	 
	 @And("^navigate to confirm screen and validate the changes made$")
	 public void multiple_confirm() throws Throwable {
		    Thread.sleep(4000);
		    String text=driver.findElement(By.xpath("//*[@class='left-template']/div/div/div/div/div/h2")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"Before");
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@class='baseA']")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[@id='main-card-3']/div[7]/div/div/a")).click();
			Thread.sleep(2000);
			
			String num=driver.findElement(By.xpath("//*[@id='badgeClientCount']")).getText();
			System.out.println(num);
			Assert.assertEquals(num,"2");
			
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			//driver.findElement(By.xpath("//*[@id='baseA_13802554']/span")).click();
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			Thread.sleep(2000);
			
			
			/*String prdt=driver.findElement(By.xpath("//*[@id='link_39652491']/div/div/div/div[3]/div/div/div/h4")).getText();
			System.out.println(prdt);
			Assert.assertEquals(prdt,"Product");
			
			String role=driver.findElement(By.xpath("//*[@id='link_39652491']/div/div/div/div[3]/div/div/div[2]/h4")).getText();
			System.out.println(role);
			Assert.assertEquals(role,"Roles");*/
			
			String after=driver.findElement(By.xpath("//div[@class='right-template']/div/h2")).getText();
			System.out.println(after);
			Assert.assertEquals(after,"After");
			
			String impctdProduct=driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText();
			System.out.println(impctdProduct);
			Assert.assertEquals(impctdProduct,"Impacted Product Number(s):");
			
			String impctdProductNum=driver.findElement(By.xpath("//*[@class='col-lg-offset-1 col-md-offset-1 col-xs-offset-1 col-sm-offset-1 col-xs-4 col-lg-4 col-md-4 col-sm-4 col-xs-4 products']/h4")).getText();
			System.out.println(impctdProductNum);
			Assert.assertEquals(impctdProductNum,"Product Number");
			
			String impctdRoleNum=driver.findElement(By.xpath("//div[@class='additional-policies related-products col-lg-12 col-md-12 col-sm-12 col-xs-12']/div/div[3]/div/div/div[2]/h4")).getText();
			System.out.println(impctdRoleNum);
			Assert.assertEquals(impctdRoleNum,"Roles");
			
			boolean backbutton=driver.findElement(By.xpath("//*[@id='btnBack']")).isEnabled();
			Assert.assertEquals(backbutton,true);
			boolean submit=driver.findElement(By.xpath("//*[@id='btnSubmit']")).isEnabled();
			Assert.assertEquals(submit,true);
			
		 
	 }
	 @And("^I click the three edit radio button and next$")
	 public void three_radio_button() throws Throwable {
		    driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='card-2']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='card-3']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 
	 @Then("^I get product deceased warning$")
	 public void deceased_warning() throws Throwable {
		    Thread.sleep(5000);
		    String alrt=driver.findElement(By.xpath("//*[@id='alrtMsg']/span[2]")).getText();
			System.out.println(alrt);
			Assert.assertEquals(alrt,"WARNING: CLIENT RECORDS SELECTED ARE ASSOCIATED WITH DECEASED CLIENT. THESE RECORDS CANNOT BE UPDATED.");
			
			boolean next=driver.findElement(By.xpath("//*[@id='btnNext']")).isEnabled();
			System.out.println(next);
			Assert.assertEquals(next,false);
	 }
	 
	 @And("^I deselect the first card$")
	 public void deselect() throws Throwable {
		    Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
	 }
	 
	 @And("^choose first and eleventh card and next$")
	 public void multiple() throws Throwable {
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='card-11']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 
	 @And("^choose first and fifth card and next$")
	 public void multiple_cards() throws Throwable {
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='card-5']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 
	 @And("^choose fifth and sixth card and next$")
	 public void fifth_sixth_cards() throws Throwable {
		    Thread.sleep(2000);
		    driver.findElement(By.xpath("//*[@id='card-5']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='card-6']/div/div[3]/label")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }			
	
	 @And("^validate the details of first card getting populated in the after section of confirm screen$")
	 public void different_cards_after() throws Throwable {
		    Thread.sleep(4000);
		    String text=driver.findElement(By.xpath("//*[@class='left-template']/div/div/div/div/div/h2")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"Before");
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@class='baseA']")).click();
			Thread.sleep(3000);
			String num=driver.findElement(By.xpath("//*[@id='badgeClientCount']")).getText();
			System.out.println(num);
			Assert.assertEquals(num,"2");
			
			String alert1=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
	        System.out.println(alert1);
	        Assert.assertEquals(alert1,"ALERT: REVIEW ALERTS FOR IMPACTED PRODUCTS BELOW.");
			
			String gender=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div/span")).getText();
	        System.out.println(gender);
	        Assert.assertEquals(gender,"Male");
	        
	        String bday=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[2]/span")).getText();
	        System.out.println(bday);
	        Assert.assertEquals(bday,"07/31/2016");
	        
	        String tin=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[3]/span")).getText();
	        System.out.println(tin);
	        Assert.assertEquals(tin,"545-31-3213");
	        
	        
	        String handling=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div/div[2]/span[2]")).getText();
	        System.out.println(handling);
	        Assert.assertEquals(handling,"Missing");
	        
	        String withholding=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div[2]/div[2]/span[2]")).getText();
	        System.out.println(withholding);
	        Assert.assertEquals(withholding,"Missing");
			
			String impctdProduct=driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText();
			System.out.println(impctdProduct);
			Assert.assertEquals(impctdProduct,"Impacted Product Number(s):");
			
			String proNum=driver.findElement(By.xpath("//div[@id='view-add-39652491']/div[3]/div/div[2]/div[2]/span/a")).getText();
			System.out.println(proNum);
			Assert.assertEquals(proNum,"18386883");
			
			String roleType=driver.findElement(By.xpath("//div[@id='view-add-39652491']/div[3]/div/div[2]/div[3]")).getText();
			System.out.println(roleType);
			Assert.assertEquals(roleType,"Insured, Owner");
		 
	 }
	 @Then("^I should get review alert and information on edit screen and next$")
	 public void info() throws Throwable {
		 Thread.sleep(3000);
		    String alrtmsg=driver.findElement(By.xpath("//h2[@id='heading']")).getText();
			System.out.println(alrtmsg);
			Assert.assertEquals(alrtmsg,"Review highlighted fields for inconsistencies and/or missing data. Enter changes needed. Data shown below will be applied to all cards.");
			
			
			String alert=driver.findElement(By.xpath("//div[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alert);
			Assert.assertEquals(alert,"ALERT: YOU HAVE CHANGED THE CLIENT'S NAME. IF THIS IS A DIFFERENT CLIENT, DO NOT PROCESS THIS CHANGE.");
			
			String info=driver.findElement(By.xpath("//div[@id='messageView']/div/div/span[2]")).getText();
			System.out.println(info);
			Assert.assertEquals(info,"INFORMATION: ONE OR MORE DIFFERENT ADDRESSES ON THE SELECTED CARD(S). THE ADDRESS ON THE CARD(S) CANNOT BE UPDATED. ADDRESS MUST BE UPDATED IN APPLICABLE MAINTENANCE SYSTEMS.");
			
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
	 }
	 @Then("^the next button should be enabled$")
	 public void next_button_enabled() throws Throwable {
		    boolean next1=driver.findElement(By.xpath("//*[@id='btnNext']")).isEnabled();
			System.out.println(next1);
			Assert.assertEquals(next1,true);
	 }
	 
	 @Then("^I should get different client type warning$")
	 public void different_LE() throws Throwable {
		    String alrt=driver.findElement(By.xpath("//*[@id='alrtMsg']/span[2]")).getText();
			System.out.println(alrt);
			Assert.assertEquals(alrt,"WARNING: DIFFERENT CLIENT TYPES CANNOT BE UPDATED AT THE SAME TIME. UPDATE ONE CLIENT TYPE AT A TIME.");
			 
	 }
	 @Then("^validate the details of first card getting populated in the edit screen$")
	 public void edit_screen() throws Throwable {
		    //click("MiddleName_xpath");
		    Thread.sleep(3000);
		    driver.findElement(By.xpath("//*[@id='middlename']")).click();
			String text_middlename=driver.findElement(By.xpath("//*[@id='middlename']")).getAttribute("placeholder");
			System.out.println(text_middlename);
			Assert.assertEquals(text_middlename,"Select or Type Middle Name");
			
			String bigcolor=driver.findElement(By.xpath("//*[@id='middlename']")).getCssValue("background-color");
			System.out.println(bigcolor);
			Assert.assertEquals(bigcolor,"transparent");
			
			String text=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-MiddleNames']/div")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"E");
			
			//click("dateOfBirth_xpath");
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).click();
			String dob_text=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-BirthDates']/div")).getText();
			System.out.println(dob_text);
			Assert.assertEquals(dob_text,"02/19/1955");
			
			String dob_text2=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-BirthDates']/div[2]")).getText();
			System.out.println(dob_text2);
			Assert.assertEquals(dob_text2,"08/21/1937");
			
			String dateofbirth=driver.findElement(By.xpath("//*[@id='dateofbirth']")).getAttribute("placeholder");
			System.out.println(dateofbirth);
			Assert.assertEquals(dateofbirth,"Select or Type Birthdate");
			
			//click("TaxID_xpath");
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).click();
			String tin_text1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-TINs']/div[1]")).getText();
			System.out.println(tin_text1);
			Assert.assertEquals(tin_text1,"235-86-4174");
			
			String tin_text2=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-TINs']/div[2]")).getText();
			System.out.println(tin_text2);
			Assert.assertEquals(tin_text2,"553-90-1961");
			
			String bcolor=driver.findElement(By.xpath("//*[@id='taxpayerid']")).getCssValue("background-color");
			System.out.println(bcolor);
			Assert.assertEquals(bcolor,"transparent");
			
			String gender=driver.findElement(By.xpath("//*[@id='ddlgender']")).getCssValue("background-color");
			System.out.println(gender);
			Assert.assertEquals(gender,"rgba(253, 244, 165, 1)");
			
			
		}
	 
	 
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	       
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        
	        
	        else if(!scenario.isFailed())
	        
	            {
	        	
	        	driver.quit();
	        	
	        	}
	        
	        }
	        
	       }
      

