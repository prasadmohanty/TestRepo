package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddSecondaryAddressee extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	
	 
	@When("^I click on secondary addressee radio button$")
	public void i_click_on_secondary_addressee_radio_button() throws Throwable{
		Thread.sleep(8000);
		driver.findElement(By.xpath("//*[@class='role-bottom-line role-row-highlight']/label[text()='Secondary Addressee']")).click();
		
	  }
	@And("^I searched for (\\d+) and I am on change role screen$")
    public void i_searched_for_a_and_I_am_on_change_role_screen(String arg1) throws Throwable {
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("donald trump");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='advanced']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys(arg1);
		
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//*[@id='card-2']/div[2]")).click();
		driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='work']")).click();
		driver.findElement(By.xpath("//*[@id='prod-btn']")).click();
	}
	@And("^Use existing client as new Secondary addressee$")
    public void Use_existing_client_as_new_Secondary_addressee() throws Throwable{
    	
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("david ingbar");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		driver.findElement(By.xpath("//*[@id='results']/div[4]/div[2]/div/div[3]/div/div/div/div/button")).click();
	}
	 @And("^Use New client as new Seconday addressee$")
	    public void Use_New_client_as_new_Seconday_addressee() throws Throwable{
	    	
	    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("ashutosh panigrahi");
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("311 Hillcrest Dr");
			driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Lower Burrell");
			Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
		    sc.selectByVisibleText("PA - Pennsylvania");
			driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("15068");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			
	    }
	 @Then("^I should get alert ALERT: POLICY ALREADY HAS FOUR DISTINCT CLIENTS. ONLY INSURED CAN BE ADDED AS SECONDARY ADDRESSEE$")
	    public void I_should_get_alert$() throws Throwable{
	    	String head_Text=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(head_Text);
			Assert.assertEquals(head_Text,"ALERT: POLICY ALREADY HAS FOUR DISTINCT CLIENTS. ONLY INSURED CAN BE ADDED AS SECONDARY ADDRESSEE");
			System.out.println("First validation successful");
	 }
	 @Then("^I should see the add secondary addressee radio button disabled$")
	    public void Then_I_should_see_the_add_secondary_addressee_radio_button_disabled() throws Throwable{
	    	boolean radio=driver.findElement(By.xpath("//*[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12']/div[3]/input")).isEnabled();
			System.out.println(radio);
			Assert.assertEquals(radio,false);
			System.out.println("test case passed");
	 }	
	 
	 @Then("^I should land on add sec addressee confirmation page$")
	    public void I_should_land_on_add_sec_addressee_confirmation_page() throws Throwable{
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText().contains("Confirm Secondary Addressee Change"));
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title align-new-role']")).getText().contains("Add Secondary Addressee"));
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText().contains("Impacted Product Number(s):"));
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='label-description']")).getText().contains("Product Number"));
	 
	 }
	 
	@After
	public void embedScreenshot(Scenario scenario) {
	       
        if(scenario.isFailed()) {
        try {
        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
            driver.quit();
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
        	
        }
        }
else if(!scenario.isFailed())
            
        {
    	
    	driver.quit();
    	
    	}
    
    }
    
   }

    
    
