package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Chaining extends AbstractPageDefinition {
	
	WebDriver driver = getDriver(null);
	
	 /*@Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  
       }*/
	
	
	 @When("^I search for \"([^\"]*)\"$")
	 public void i_search_for(String arg1) throws Throwable {
		 driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg1);
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
			
	 }

	 @And("^click on merge client option$")
	 public void click_on_merge_client_option() throws Throwable {
		    Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='chain']")).click();
	     
	 }
	 @And("^I look for \"([^\"]*)\"$")
	 public void i_look_for(String arg2) throws Throwable {
		    Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg2);
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Use']")).click();
	     
	 }
	 @Then("^I should find the first use button as disabled$")
	 public void use_button_disabled() throws Throwable{
		   Thread.sleep(2000);
		   boolean use=driver.findElement(By.xpath("//*[@class='fly-actions-link']/button")).isEnabled();
		   System.out.println(use);
		   Assert.assertEquals(use,false);
	 }
	 @When("^I look for \"([^\"]*)\" and use second card$")
	 public void i_look_for_and_use_second_card(String arg3) throws Throwable {
		 Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg3);
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			driver.findElement(By.xpath("//button[@id='btn-action-1301035518']")).click();
	     
	 }
	 
	 @Then("^I should get couple of Use NMC ID radio button enabled$")
	 public void i_shou_get_couple_of_Use_NMC_ID_enabled() throws Throwable {
		    boolean UseNMCID_button1=driver.findElement(By.xpath("//*[@id='card-radio-1']/label[text()='Use NMC ID: sholomonb']")).isEnabled();
			System.out.println(UseNMCID_button1);
			
			boolean UseNMCID_button2=driver.findElement(By.xpath("//*[@id='card-radio-1']/label[text()='Use NMC ID: darrow']")).isEnabled();
			System.out.println(UseNMCID_button2);
			
			
		    if(UseNMCID_button1 && UseNMCID_button2 !=false){{
			System.out.println("test case passed");}
		    }
		    
		    driver.findElement(By.xpath("//*[@id='card-radio-1']/label[text()='Use NMC ID: sholomonb']")).click();
		    driver.findElement(By.xpath("//*[@id='btnNext']")).click();
		    
	 }
	 
	 @Then("^I should get couple of alerts and warning$")
	 public void i_shou_get_couple_of_alerts_and_warning() throws Throwable {
		    Thread.sleep(5000);
		    String Alert1=driver.findElement(By.xpath("//*[@class='chain-alert-div col-lg-12 no-right-margin']/div/div/span[2]")).getText();
			System.out.println(Alert1);
			Assert.assertEquals(Alert1,"ALERT: CLIENT BIRTHDATE NO LONGER MATCHES THE CONTRACT BIRTHDATE AND A CASE WILL BE CREATED TO CORRECT THE CONTRACT, AS THIS RESULTS IN AN AGE CHANGE.");
			System.out.println("test case1 Passed");
			
			
			String Alert2=driver.findElement(By.xpath("//*[@class='chain-alert-div col-lg-12 no-right-margin']/div/div[2]/span[2]")).getText();
			System.out.println(Alert2);
			Assert.assertEquals(Alert2,"ALERT: CLIENT GENDER NO LONGER MATCHES THE CONTRACT GENDER AND A CASE WILL BE CREATED TO CORRECT THE CONTRACT, AS THIS RESULTS IN A CHANGE TO THE CONTRACT");
			System.out.println("test case2 Passed");
			

			String Warning=driver.findElement(By.xpath("//*[@class='alert alert-danger fade in alert-styleclass alert-error alert-card-panel']/span[2]")).getText();
			System.out.println(Warning);
			Assert.assertEquals(Warning,"WARNING: CLIENT RECORD DOES NOT HAVE INSURED/ANNUITANT ROLE ON ANY INFORCE/TERMINATED POLICY. CANNOT BE CHAINED.");
			System.out.println("test case3 Passed");
	 
	 }
	 @And("^choose the primary radio button$")
	 public void choose_the_primary_radio_button() throws Throwable {
		 Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='card-radio-0']/label[text()='Set as Primary Record']")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
		 
	 }
	 
	 @And("^I click on second card as primary record$")
	 public void choose_second_primary_radio_button() throws Throwable {
		 Thread.sleep(4000);
		    //driver.findElement(By.xpath("//*[@class='col-lg-offset-1 col-md-offset-1 col-lg-10 col-md-10 card-radio card-radio-0-1300865328']/label[text()='Set as Primary Record']")).click();
		 driver.findElement(By.xpath("//*[@id='main-card-1']/div[4]/div/div/div/div/div/label")).click();  
		 driver.findElement(By.xpath("//*[@id='btnNext']")).click();
		    
			
	 }
	
	 @Then("^I should get JCL information$")
	 public void i_should_get_jcl_information() throws Throwable {
		 Thread.sleep(2000);
		    String Information=driver.findElement(By.xpath("//*[@id='card-container-bottom']/div[2]/div[2]/span[2]")).getText();
			System.out.println(Information);
			Assert.assertEquals(Information,"INFORMATION: JOINT LIFE POLICY 13199807 HAS SECONDARY ADDRESSEE WHO IS NOT INSURED. REMOVE AND THEN CHAIN.");
			System.out.println("test case Passed");
			
	 }
	 
	 @Then("^I should get a Warning$")
	 public void i_should_get_an_Warning() throws Throwable {
		 Thread.sleep(12000);
		    String Warning=driver.findElement(By.xpath("//*[@class='alert alert-danger fade in alert-styleclass alert-error alert-card-panel']/span[2]")).getText();
			System.out.println(Warning);
			
			if (Warning.equals("WARNING: CLIENT RECORD DOES NOT HAVE INSURED/ANNUITANT ROLE ON ANY INFORCE/TERMINATED POLICY. CANNOT BE CHAINED.")){
				System.out.println("First test case passed");

			} else if (Warning.equals("WARNING: CLIENT RECORD IS RELATED TO GROUP PENSION/VARIABLE ANNUITY, CANNOT BE CHAINED.")) {
				System.out.println("Second test case passedd");

			} else if (Warning.equals("WARNING: CLIENT RECORD IS RELATED TO ULIFE/LTC POLICY, CANNOT BE CHAINED.")){
				System.out.println("Third test case passsedd");
				
			} else if (Warning.equals("WARNING: CLIENT RECORD IS RELATED TO INVESTMENT ACCOUNTS, CANNOT BE CHAINED.")){
				System.out.println("Fourth test case passsedd");
			
			} else if (Warning.equals("WARNING: PAYER AND INSURED ARE NOT SAME FOR THIS NON-ISA EP POLICY 10219868")){
				System.out.println("Fifth test case passsedd");
			}
		
			else(driver.findElement(By.xpath("//*[@class='acq']/label"))).click();
	 }
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
