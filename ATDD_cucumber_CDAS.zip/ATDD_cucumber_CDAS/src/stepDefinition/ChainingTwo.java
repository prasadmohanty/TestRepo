package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChainingTwo extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	
	 @When("^I search for \"([^\"]*)\" policy number$")
	 public void i_search_for_policy_number(String arg4) throws Throwable {
		 driver.findElement(By.xpath("//*[@id='search']")).sendKeys("abinash panigrahi");
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='advanced']")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys(arg4);
			
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(7000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
			Thread.sleep(2000);
	    
	 }

	 @When("^I look for \"([^\"]*)\" and choose first card$")
	 public void i_look_for_and_choose_first_card(String arg5) throws Throwable {
		 driver.findElement(By.xpath("//*[@id='product']")).clear();
		 driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys(arg5);
		 driver.findElement(By.xpath("//*[@id='submit']")).click();
		 Thread.sleep(7000);
	     driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
	     Thread.sleep(5000);
	     driver.findElement(By.xpath("//*[@id='card-action']/div/div/button[text()='Use']")).click();
	 }
	 
	 @And("^choose the first button as primary radio button$")
	 public void choose_the_first_primary_radio_button() throws Throwable {
		 Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='card-radio-0']/label[text()='Set as Primary Record']")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='btnBack']")).click();
			Thread.sleep(5000);
	 }

	 @Then("^I should get warnings$")
	 public void i_should_get_warnings() throws Throwable {
		 String warning1=driver.findElement(By.xpath("//*[@id='card-container-left']/div[2]/div/span[2]")).getText();
			System.out.println(warning1);
			if (warning1.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY D016322 WHICH CURRENTLY HAS A POLICY FREEZE OF N, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")){
				System.out.println("First test case passed");

			} else if (warning1.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY 10245288 WHICH CURRENTLY HAS A POLICY FREEZE OF Q, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")) {
				System.out.println("Second test case passed");

			} else if (warning1.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY D144452 WHICH CURRENTLY HAS A POLICY FREEZE OF U, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")){
				System.out.println("Third test case passed");
				
			}
			else
			{
				(driver.findElement(By.xpath("//*[@class='acq']/label"))).click();
			}

	        String warning2=driver.findElement(By.xpath("//*[@id='card-container-right']/div[3]/div/span[2]")).getText();
			System.out.println(warning2);
			if (warning2.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY D1892909 WHICH CURRENTLY HAS A POLICY FREEZE OF O, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")){
				System.out.println("First test case passed");

			} else if (warning2.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY 12732222 WHICH CURRENTLY HAS A POLICY FREEZE OF S, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")) {
				System.out.println("Second test case passed");
			} else if (warning2.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY D1531635 WHICH CURRENTLY HAS A POLICY FREEZE OF X, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")) {
				System.out.println("Third test case passed");
			} else if (warning2.equals("WARNING: CLIENT RECORD IS RELATED TO POLICY 19651415 WHICH CURRENTLY HAS A POLICY FREEZE OF W, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS CLIENT.")) {
				System.out.println("Fourth test case passed");
			}
			else
				{
					(driver.findElement(By.xpath("//*[@class='acw']/label"))).click();
				}
				
	        System.out.println("Test case is Passed");
	    
	 }
	 @Then("^I should get alerts$")
	 public void i_should_get_alerts() throws Throwable {
		 String alert1=driver.findElement(By.xpath("//*[@id='card-container-left']/div[2]/div/span[2]")).getText();
			System.out.println(alert1);
			if (alert1.equals("ALERT: CLIENT RECORD IS RELATED TO POLICY 10953513 WHICH CURRENTLY HAS A POLICY FREEZE OF K, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")){
				System.out.println("First test case passed");

			} else if (alert1.equals("ALERT: CLIENT RECORD IS RELATED TO POLICY 10389723 WHICH CURRENTLY HAS A POLICY FREEZE OF P, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")) {
				System.out.println("Second test case passed");

			} 
			else
			{
				(driver.findElement(By.xpath("//*[@class='acq']/label"))).click();
			}

	        String alert2=driver.findElement(By.xpath("//*[@id='card-container-right']/div[3]/div/span[2]")).getText();
			System.out.println(alert2);
			if (alert2.equals("ALERT: CLIENT RECORD IS RELATED TO POLICY 8899036 WHICH CURRENTLY HAS A POLICY FREEZE OF M, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")){
				System.out.println("First test case passed");

			} else if (alert2.equals("ALERT: CLIENT RECORD IS RELATED TO POLICY 10580499 WHICH CURRENTLY HAS A POLICY FREEZE OF R, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")) {
				System.out.println("Second test case passed");
			} else if (alert2.equals("ALERT: CLIENT RECORD IS RELATED TO POLICY 10662190 WHICH CURRENTLY HAS A POLICY FREEZE OF T, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")) {
				System.out.println("Third test case passed");
			
			}
			else
				{
					(driver.findElement(By.xpath("//*[@class='acw']/label"))).click();
				}
				
	        System.out.println("Test case is Passed");
	    
	 }


	 
	 @And("^I look for \"([^\"]*)\" and choose second card$")
	 public void i_look_for_and_use_second_card(String arg3) throws Throwable{
		 Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg3);
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-2']/div[2]")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Use']")).click();
		 
	 }
	 @Then("^I should get a Warning below secondary card$")
	 public void i_should_get_warning_below_secondary_card() throws Throwable{
		 Thread.sleep(2000);
		    String Product_list=driver.findElement(By.xpath("//*[@id='client-details-panel']/div[2]/div/div[2]/div/div/div[2]/div/h4")).getText();
			System.out.println(Product_list);
			Assert.assertEquals(Product_list,"No products available for this Client.");
			
			String warning=driver.findElement(By.xpath("//*[@id='card-container-right']/div[3]/div/span[2]")).getText();
			System.out.println(warning);
			Assert.assertEquals(warning,"WARNING: CLIENT RECORD DOES NOT HAVE INSURED/ANNUITANT ROLE ON ANY INFORCE/TERMINATED POLICY. CANNOT BE CHAINED.");
	 }
	
	 @And("^I click on secondary card as primary record$")
	 public void choose_secondary_primary_radio_button() throws Throwable {
		 Thread.sleep(4000);
		    //driver.findElement(By.xpath("//*[@class='col-lg-offset-1 col-md-offset-1 col-lg-10 col-md-10 card-radio card-radio-0-1300865328']/label[text()='Set as Primary Record']")).click();
		 driver.findElement(By.xpath("//*[@id='main-card-2']/div[4]/div/div/div/div/div/label")).click();  
		 driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
		    
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
