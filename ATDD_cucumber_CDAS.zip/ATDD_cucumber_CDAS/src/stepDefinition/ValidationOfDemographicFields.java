package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
//import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class ValidationOfDemographicFields extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  
        }*/
	 
	 @And("^choose first,third and fourth cards and next$")
	 public void next_demo() throws Throwable{
		 driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/label")).click();
	     driver.findElement(By.xpath("//*[@id='card-3']/div/div[3]/label")).click();
	     driver.findElement(By.xpath("//*[@id='card-4']/div/div[3]/label")).click();
		 driver.findElement(By.xpath("//button[@id='btnNext']")).click();
	 }
	 
	 @And("^I change the default values$")
	 public void change_values() throws Throwable{
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@id='us-phone']")).clear();
			driver.findElement(By.xpath("//*[@id='us-phone']")).sendKeys("1345345436");
			driver.findElement(By.xpath("//*[@id='extcode']")).clear();
			
			driver.findElement(By.xpath("//*[@id='email']")).clear();
			driver.findElement(By.xpath("//*[@id='email']")).sendKeys("a@gmail.com");
			
			Select sc=new Select(driver.findElement(By.xpath("//*[@id='ddl-emp-status']")));
			sc.selectByVisibleText("Employed");
			
			driver.findElement(By.xpath("//*[@id='annual-income']")).clear();
			driver.findElement(By.xpath("//*[@id='annual-income']")).sendKeys("332");
			
		    driver.findElement(By.xpath("//*[@id='txt-occupation']")).clear();
		    driver.findElement(By.xpath("//*[@id='txt-occupation']")).sendKeys("driver");
			
			driver.findElement(By.xpath("//*[@id='net-worth']")).clear();
			driver.findElement(By.xpath("//*[@id='net-worth']")).sendKeys("45123");
			
			driver.findElement(By.xpath("//button[@id='btnSave']")).click();
			
	 }
	 
	 @Then("^I should validate all the available options and highlighted fields and attributes$")
	 public void edit_screen_validation() throws Throwable{
		    Thread.sleep(3000);
		    
		    driver.findElement(By.xpath("//*[@id='us-phone']")).click();
			String phone=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-USPhones']/div/strong")).getText();
			System.out.println(phone);
			Assert.assertEquals(phone,"(243)564-7676");
			
			String phone1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-USPhones']/div[2]")).getText();
			System.out.println(phone1);
			Assert.assertEquals(phone1,"(770)934-0031");
			
			String phone2=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-USPhones']/div[3]")).getText();
			System.out.println(phone2);
			Assert.assertEquals(phone2,"(414)661-6125");
			
			String phone_highlight=driver.findElement(By.xpath("//*[@id='us-phone']")).getCssValue("background-color");
			System.out.println(phone_highlight);
			Assert.assertEquals(phone_highlight,"rgba(253, 244, 165, 1)");
			
			
            driver.findElement(By.xpath("//*[@id='extcode']")).click();
			String ext=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-Extension']/div/strong")).getText();
			System.out.println(ext);
			Assert.assertEquals(ext,"56889");
			
			
			driver.findElement(By.xpath("//*[@id='email']")).click();
			String mail=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-Email']/div/strong")).getText();
			System.out.println(mail);
			Assert.assertEquals(mail,"sandhyaramesh@northwesternmutual.com");
			
			String mail1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-Email']/div[2]")).getText();
			System.out.println(mail1);
			Assert.assertEquals(mail1,"neiljiles@test.com");
			
			driver.findElement(By.xpath("//*[@id='annual-income']")).click();
			String income=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-AnnualIncome']/div/strong")).getText();
			System.out.println(income);
			Assert.assertEquals(income,"$33");
			
			String income1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-AnnualIncome']/div[2]")).getText();
			System.out.println(income1);
			Assert.assertEquals(income1,"$100,000");
			
			driver.findElement(By.xpath("//*[@id='txt-occupation']")).click();
			String occup=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-Occupation']/div/strong")).getText();
			System.out.println(occup);
			Assert.assertEquals(occup,"NA");
			
			String occup1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-Occupation']/div[2]")).getText();
			System.out.println(occup1);
			Assert.assertEquals(occup1,"Race Car Driver");
			
			driver.findElement(By.xpath("//*[@id='net-worth']")).click();
			String net=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-NetWorth']/div/strong")).getText();
			System.out.println(net);
			Assert.assertEquals(net,"$45");
			
			String net1=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-NetWorth']/div[2]")).getText();
			System.out.println(net1);
			Assert.assertEquals(net1,"$3,333");
			
			String net2=driver.findElement(By.xpath("//*[@class='tt-dataset tt-dataset-NetWorth']/div[3]")).getText();
			System.out.println(net2);
			Assert.assertEquals(net2,"$10,000,000");
			
			String emp=driver.findElement(By.xpath("//*[@id='ddl-emp-status']/option[2]")).getText();
			System.out.println(emp);
			Assert.assertEquals(emp,"Not Provided");
			
			String emp1=driver.findElement(By.xpath("//*[@id='ddl-emp-status']/option[3]")).getText();
			System.out.println(emp1);
			Assert.assertEquals(emp1,"Employed");
			
			String emp2=driver.findElement(By.xpath("//*[@id='ddl-emp-status']/option[4]")).getText();
			System.out.println(emp2);
			Assert.assertEquals(emp2,"Unemployed");
			
			String emp3=driver.findElement(By.xpath("//*[@id='ddl-emp-status']/option[5]")).getText();
			System.out.println(emp3);
			Assert.assertEquals(emp3,"Retired");
			
			String addrssinfo=driver.findElement(By.xpath("//*[@id='messageView']/div/div/span[2]")).getText();
			System.out.println(addrssinfo);
			Assert.assertEquals(addrssinfo,"INFORMATION: ONE OR MORE DIFFERENT ADDRESSES ON THE SELECTED CARD(S). THE ADDRESS ON THE CARD(S) CANNOT BE UPDATED. ADDRESS MUST BE UPDATED IN APPLICABLE MAINTENANCE SYSTEMS.");
			
	 }
	 @Then("^I should validate all the changesin before and after screen$")
	 public void confirm_validation() throws Throwable{
		    Thread.sleep(3000);
		    //Validation of after card:
			
			String number=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div/div/span[2]")).getAttribute("class");
			System.out.println(number);
		    Assert.assertEquals(number," new-text");
				
			String number1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div/div/span[2]")).getText();
			System.out.println(number1);
			Assert.assertEquals(number1,"(134)534-5436");
			
			/*String email=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(email);
		    Assert.assertEquals(email," new-text");
				
			String email1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[2]/div/span[2]")).getText();
			System.out.println(email1);
			Assert.assertEquals(email1,"a@gmail.com");*/
			
			String emp=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[2]")).getAttribute("class");
			System.out.println(emp);
		    Assert.assertEquals(emp," new-text");
				
			String emp1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[2]")).getText();
			System.out.println(emp1);
			Assert.assertEquals(emp1,"Employed");
			
			String ocp=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp);
		    Assert.assertEquals(ocp," new-text");
				
			String ocp1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp1);
			Assert.assertEquals(ocp1,"driver");
			
			String income=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(income);
		    Assert.assertEquals(income," new-text");
				
			String income1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[6]")).getText();
			System.out.println(income1);
			Assert.assertEquals(income1,"$332");
			
			String net=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net);
		    Assert.assertEquals(net," new-text");
				
			String net1=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net1);
			Assert.assertEquals(net1,"$45,123");
			
			//validation fo before card
			String number_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(number_before);
		    Assert.assertEquals(number_before,"changed-text ");
				
		    /*String email_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(email_before);
		    Assert.assertEquals(email_before,"changed-text ");*/
				
			String email_before1=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[2]/div/span[2]")).getText();
			System.out.println(email_before1);
			Assert.assertEquals(email_before1,"sandhyaramesh@northwesternmutual.com");
			
			String emp_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[2]")).getAttribute("class");
			System.out.println(emp_before);
		    Assert.assertEquals(emp_before,"changed-text ");
				
			String emp_before1=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[2]")).getText();
			System.out.println(emp_before1);
			Assert.assertEquals(emp_before1,"Retired");
			
			String ocp_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp_before);
		    Assert.assertEquals(ocp_before,"changed-text ");
				
			String ocp_before1=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp_before1);
			Assert.assertEquals(ocp_before1,"NA");
			
			String inc_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(inc_before);
		    Assert.assertEquals(inc_before,"changed-text ");
				
			String inc_before1=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[6]")).getText();
			System.out.println(inc_before1);
			Assert.assertEquals(inc_before1,"$33");
			
			String net_before=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net_before);
		    Assert.assertEquals(net_before,"changed-text ");
				
			String net_before1=driver.findElement(By.xpath("//*[@id='front-1301696911collapsible']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net_before1);
			Assert.assertEquals(net_before1,"");
			
			//Validation of 2nd before card
			String number_before2=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(number_before2);
		    Assert.assertEquals(number_before2,"changed-text ");
		    
		    String number_before3=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div/div/span[2]")).getText();
			System.out.println(number_before3);
			Assert.assertEquals(number_before3,"(414)661-6125");
				
		    /*String email_before3=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(email_before3);
		    Assert.assertEquals(email_before3,"changed-text ");*/
				
			String email_before2=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[2]/div/span[2]")).getText();
			System.out.println(email_before2);
			Assert.assertEquals(email_before2,"neiljiles@test.com");
			
		   String ocp_before2=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp_before2);
		    Assert.assertEquals(ocp_before2,"changed-text ");
				
			String ocp_before3=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp_before3);
			Assert.assertEquals(ocp_before3,"Race Car Driver");
			
			String inc_before2=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(inc_before2);
		    Assert.assertEquals(inc_before2,"changed-text ");
				
			String inc_before3=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[6]")).getText();
			System.out.println(inc_before3);
			Assert.assertEquals(inc_before3,"$100,000");
			
			String net_before2=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net_before2);
		    Assert.assertEquals(net_before2,"changed-text ");
				
			String net_before3=driver.findElement(By.xpath("//*[@id='front-1301708272collapsible']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net_before3);
			Assert.assertEquals(net_before3,"$10,000,000");
			
			//Validation fo 3rd card
			String number_before4=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(number_before4);
		    Assert.assertEquals(number_before4,"changed-text ");
		    
		    String number_before5=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div/div/span[2]")).getText();
			System.out.println(number_before5);
			Assert.assertEquals(number_before5,"(770)934-0031");
				
		    String email_before4=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div/div[2]/span[2]")).getAttribute("class");
			System.out.println(email_before4);
		    Assert.assertEquals(email_before4,"missing-data-style changed-text ");
				
			String email_before5=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div/div[2]/span[2]")).getText();
			System.out.println(email_before5);
			Assert.assertEquals(email_before5,"Missing");
			
		   String ocp_before4=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp_before4);
		    Assert.assertEquals(ocp_before4,"missing-data-style changed-text ");
				
			String ocp_before5=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp_before5);
			Assert.assertEquals(ocp_before5,"Missing");
			
			String inc_before4=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(inc_before4);
		    Assert.assertEquals(inc_before4,"missing-data-style changed-text ");
				
			String inc_before5=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[6]")).getText();
			System.out.println(inc_before5);
			Assert.assertEquals(inc_before5,"Missing");
			
			String net_before4=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net_before4);
		    Assert.assertEquals(net_before4,"changed-text ");
				
			String net_before5=driver.findElement(By.xpath("//*[@id='front-19384780collapsible']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net_before5);
			Assert.assertEquals(net_before5,"$3,333");
			
			//Validation of 4th card
			String number_before6=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(number_before6);
		    Assert.assertEquals(number_before6,"changed-text ");
		    
		    String number_before7=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div/div/span[2]")).getText();
			System.out.println(number_before7);
			Assert.assertEquals(number_before7,"(770)934-0031");
				
		   /* String email_before6=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(email_before6);
		    Assert.assertEquals(email_before6,"missing-data-style changed-text ");
				
			String email_before7=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[2]/div/span[2]")).getText();
			System.out.println(email_before7);
			Assert.assertEquals(email_before7,"Missing");*/
			
		   String ocp_before6=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp_before6);
		    Assert.assertEquals(ocp_before6,"missing-data-style changed-text ");
				
			String ocp_before7=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp_before7);
			Assert.assertEquals(ocp_before7,"Missing");
			
			String inc_before6=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(inc_before6);
		    Assert.assertEquals(inc_before6,"missing-data-style changed-text ");
				
			String inc_before7=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[6]")).getText();
			System.out.println(inc_before7);
			Assert.assertEquals(inc_before7,"Missing");
			
			String net_before6=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net_before6);
		    Assert.assertEquals(net_before6,"missing-data-style changed-text ");
				
			String net_before7=driver.findElement(By.xpath("//*[@id='front-22677934collapsible']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net_before7);
			Assert.assertEquals(net_before7,"Missing");
			
			//validation of 5th card
			String number_before8=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(number_before8);
		    Assert.assertEquals(number_before8,"missing-data-style changed-text ");
		    
		    String number_before9=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div/div/span[2]")).getText();
			System.out.println(number_before9);
			Assert.assertEquals(number_before9,"Missing");
				
		    /*String email_before8=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(email_before8);
		    Assert.assertEquals(email_before8,"missing-data-style changed-text ");
				
			String email_before9=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[2]/div/span[2]")).getText();
			System.out.println(email_before9);
			Assert.assertEquals(email_before9,"Missing");*/
			
		    String ocp_before8=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[4]")).getAttribute("class");
			System.out.println(ocp_before8);
		    Assert.assertEquals(ocp_before8,"missing-data-style changed-text ");
				
			String ocp_before9=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[4]")).getText();
			System.out.println(ocp_before9);
			Assert.assertEquals(ocp_before9,"Missing");
			
			String inc_before8=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[6]")).getAttribute("class");
			System.out.println(inc_before8);
		    Assert.assertEquals(inc_before8,"missing-data-style changed-text ");
				
			String inc_before9=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[6]")).getText();
			System.out.println(inc_before9);
			Assert.assertEquals(inc_before9,"Missing");
			
			String net_before8=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[8]")).getAttribute("class");
			System.out.println(net_before8);
		    Assert.assertEquals(net_before8,"missing-data-style changed-text ");
				
			String net_before9=driver.findElement(By.xpath("//*[@id='front-30742754collapsible']/div[3]/div[2]/span[8]")).getText();
			System.out.println(net_before9);
			Assert.assertEquals(net_before9,"Missing");
			
			
		 
	 }
	 @After
	  public void embedScreenshot(Scenario scenario) {
	          
      if(scenario.isFailed()) {
      try {
      	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
          byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
          scenario.embed(screenshot, "image/png");
          driver.quit();
     
      } catch (WebDriverException somePlatformsDontSupportScreenshots) {
          System.err.println(somePlatformsDontSupportScreenshots.getMessage());
      	
      }
      }
      
      
      else if(!scenario.isFailed())
      
          {
      	
      	driver.quit();
      	
      	}
      
      }
      
     }




