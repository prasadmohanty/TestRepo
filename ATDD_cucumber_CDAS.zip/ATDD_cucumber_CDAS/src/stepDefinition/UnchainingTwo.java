package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UnchainingTwo extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	 
	 @When("^I search for \"([^\"]*)\" and choose fourth card$")
	 public void i_search_for_and_choose_fourth_card(String arg1) throws Throwable {
		    driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg1);
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-4']/div[2]")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button")).click();
		   
	 }
	 @And("^I look for \"([^\"]*)\" and click on eighth card$")
	 public void i_look_for_and_use_second_card(String arg3) throws Throwable {
		 Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg3);
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-8']/div[2]")).click();
			System.out.println("found card");
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Use']")).click();
			System.out.println("clicked");
	 }
	 @And("^I look for a new client$")
	 public void i_look_for_a_new_client() throws Throwable {
		    Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys(Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='search']")).sendKeys("Ashutosh panigrahi");
			driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
	 }
	 
	
	 
	 @Then("^I should get NMCID policy related information$")
	 public void i_should_get_birthday_warning() throws Throwable {
		    Thread.sleep(5000);
		    String Information=driver.findElement(By.xpath("//*[@class='alert alert-info fade in alert-styleclass alert-info ']/span[2]")).getText();
			System.out.println(Information);
			Assert.assertEquals(Information,"INFORMATION: THE POLICIES UNCHAINED HAVE AN NMC PROFILE WITH USER ID sholomonb. SELECT THE CLIENT RECORD TO RETAIN THE USER ID.");
			System.out.println("test case Passed");
	 }
	 
	 @Then("^I should get alert gender mismatch alert$")
	 public void gender_alert() throws Throwable {
		    String Alert=driver.findElement(By.xpath("//*[@class='chain-alert-div']/div/div[3]/span[2]")).getText();
			System.out.println(Alert);
			Assert.assertEquals(Alert,"ALERT: CLIENT GENDER NO LONGER MATCHES THE CONTRACT GENDER AND A CASE WILL BE CREATED TO CORRECT THE CONTRACT, AS THIS RESULTS IN A CHANGE TO THE CONTRACT");
			System.out.println("test case Passed");
		 
	 }
	 @Then("^I should get tax payer related alert$")
	 public void taxPayer_alert() throws Throwable {
		    String alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alert);
			Assert.assertEquals(alert, "ALERT: THE RECORD YOU HAVE SPLIT DOES NOT CONTAIN A TAXPAYER ID. CONSIDER ADDING A TAXPAYER ID TO PREVENT THESE CLIENTS FROM MERGING AGAIN.");
			System.out.println("test case is Passed");
	 }
	
	 @Then("^I should get DOB or gender required warning$")
	 public void dob_warning() throws Throwable {
		    String Warning=driver.findElement(By.xpath("//*[@class='alert alert-danger fade in alert-styleclass alert-error ']/span[2]")).getText();
			System.out.println(Warning);
			//Assert.assertEquals(Warning,"WARNING: BIRTHDATE IS MANDATORY FOR UNCHAINING.");
			//System.out.println("test case Passed");
			if (Warning.equals("WARNING: BIRTHDATE IS MANDATORY FOR UNCHAINING.")) {
				System.out.println("First case passed");

			} else if (Warning.equals("WARNING: GENDER IS MANDATORY FOR UNCHAINING.")) {
				System.out.println("Second case passed");

			}
			else
			{
				(driver.findElement(By.xpath("//*[@class='xc']/label"))).click();
			}
	 }
	  
	 @Then("^I should find the search filter option as disabled$")
	 public void search_filter_disabled() throws Throwable {
		    boolean Business_Button=driver.findElement(By.xpath("//*[@id='filter']")).isEnabled();
			System.out.println(Business_Button);
			Assert.assertEquals(Business_Button,false);
	 }
	 
	
	 
	 @And("^click next after selecting eleventh insured radio button$")
	 public void eleventh_radio_button() throws Throwable {
		    Thread.sleep(3000);
		    driver.findElement(By.xpath("//*[@id='view-add-prod-1974012-0']/div[11]/div/label")).click();
		    driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
		 
	 }
	 @And("^click next after selecting insured radio button$")
	 public void insured_radio_button() throws Throwable {
		    Thread.sleep(3000);
		    System.out.println("on before confirmation page");
		    driver.findElement(By.xpath("//*[@id='view-add-prod-1974012-0']/div[12]/div/label")).click();
		    driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
		 
	 }
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
