
package stepDefinition;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.Scenario;
import cucumber.api.java.After;
//import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EditClient extends AbstractPageDefinition {
	
	WebDriver driver = getDriver(null);
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  
       }*/
	
	
	 @When("^I search for \"([^\"]*)\" client$")
	 public void client_search(String arg1) throws Throwable {
		    driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg1);
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			
	 }
	 @And("^click on edit client option$")
	 public void edit_client() throws Throwable {
		    Thread.sleep(4000);
	    	driver.findElement(By.xpath("//*[@id='card-1']/div/div[3]/button")).click();
			
	 }
	 
	 @And("^click on fourth edit client option$")
	 public void fourth_edit() throws Throwable {
		    Thread.sleep(4000);
	    	driver.findElement(By.xpath("//*[@id='card-4']/div/div[3]/button")).click();
			
	 }
	 
	 @Then("^I should see Undeliverable in before and after screen$")
	 public void undeliverable() throws Throwable {
		    String underliverableafter=driver.findElement(By.xpath("//div[@class='undeliver-status']")).getText();
			System.out.println(underliverableafter);
			Assert.assertEquals(underliverableafter,"UNDELIVERABLE");
			
	        String underliverablebefore=driver.findElement(By.xpath("//*[@id='main-card-undefined']/div/div/div/div[2]/div/div/div[3]/strong/div")).getText();
			System.out.println(underliverablebefore);
			Assert.assertEquals(underliverablebefore,"UNDELIVERABLE");
		 
	 }
	  
	 @And("^I edit details of the client and click on next button$")
	 public void edit_screen() throws Throwable {
		   Thread.sleep(3000);
		    String head=driver.findElement(By.xpath("//*[@id='edit-client']/h1")).getText();
			System.out.println(head);
			Assert.assertEquals(head,"Edit Client Data");
		    Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			//input("dateOfBirth_xpath", data.get("Date of Birth"));
		    //input("TaxID_xpath", data.get("Tax Payer ID"));
			Select sal= new Select(driver.findElement(By.xpath(".//*[@id='ddlprefix']")));
			sal.selectByVisibleText("Atty");
			Select lin= new Select(driver.findElement(By.xpath(".//*[@id='ddllineage']")));
			lin.selectByVisibleText("I");
			Select cert= new Select(driver.findElement(By.xpath(".//*[@id='certificationform']")));
			cert.selectByVisibleText("W-9: Backup Withholding");
			Select back= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			back.selectByVisibleText("Not Required");
			Thread.sleep(7000);
			
			//click("corporate_xapth");
			driver.findElement(By.xpath("//*[@id='tincorporatetab']")).click();
			Select certt= new Select(driver.findElement(By.xpath(".//*[@id='certificationform']")));
			certt.selectByVisibleText("W-9: Backup Withholding");
			Select backk= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			backk.selectByVisibleText("Not Required");
			//click("personal_xpath");
			Thread.sleep(7000);
			driver.findElement(By.xpath("//*[@id='tinpersontab']")).click();
			
			String alrtmsg=driver.findElement(By.xpath("//*[@id='heading']")).getText();
			System.out.println(alrtmsg);
			Assert.assertEquals(alrtmsg,"Review highlighted fields for inconsistencies and/or missing data. Enter changes needed. Data shown below will be applied to all cards.");
			
			
			String alrt=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alrt);
			Assert.assertEquals(alrt,"ALERT: YOU HAVE CHANGED THE CLIENT'S NAME. IF THIS IS A DIFFERENT CLIENT, DO NOT PROCESS THIS CHANGE."); 
		    Thread.sleep(3000);
			
			//non-usa country address validation
			driver.findElement(By.xpath("//*[@id='countrynonusatab']")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='pobox']")).clear();
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("Street Test");
			driver.findElement(By.xpath("//*[@id='postaltext']")).sendKeys("");
			Select cnty= new Select(driver.findElement(By.xpath(".//*[@id='country']")));
			cnty.selectByVisibleText("India");
			String spclhandling=driver.findElement(By.xpath("//*[@id='specialHandling']/option")).getText();
			System.out.println(spclhandling);
			Assert.assertEquals(spclhandling,"Yes");
			Select mail= new Select(driver.findElement(By.xpath(".//*[@id='specialHandling']")));
			mail.selectByVisibleText("No - Undeliverable");
			Select mail1= new Select(driver.findElement(By.xpath(".//*[@id='specialHandling']")));
			mail1.selectByVisibleText("Yes");
			
			//usa country address validation
			driver.findElement(By.xpath("//*[@id='countryusatab']")).click();
			Thread.sleep(6000);
			//input("ExtraAddress_xapth", data.get("Extra Address"));
			driver.findElement(By.xpath("//*[@id='pobox']")).clear();
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("Street Test");
			driver.findElement(By.xpath("//*[@id='city']")).clear();
			driver.findElement(By.xpath("//*[@id='city']")).sendKeys("City Test");
			driver.findElement(By.xpath("//*[@id='zip']")).clear();
			driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("12313");
			Select state= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
			state.selectByVisibleText("DC - District of Columbia");
			String spclhandling1=driver.findElement(By.xpath("//*[@id='specialHandling']/option")).getText();
			System.out.println(spclhandling1);
			Assert.assertEquals(spclhandling1,"Yes");
			Select mai3= new Select(driver.findElement(By.xpath(".//*[@id='specialHandling']")));
			mai3.selectByVisibleText("No - Undeliverable");
			
			
			driver.findElement(By.xpath("//*[@id='us-phone']")).click();
			driver.findElement(By.xpath("//*[@id='us-phone']")).sendKeys("123 465 4123");
			
			driver.findElement(By.xpath("//*[@id='extcode']")).sendKeys("1");
			
			driver.findElement(By.xpath("//*[@id='email']")).sendKeys("abinash@gmail.com");
			
			String shortened=driver.findElement(By.xpath("//div[@class='container demographiccontainer']/div/div")).getText();
			System.out.println(shortened);
			Assert.assertEquals(shortened,"SHORTENED INFORMATION");
			
			String shortenedName=driver.findElement(By.xpath("//div[@class='container demographiccontainer']/div/div[2]/div/div")).getText();
			System.out.println(shortenedName);
			Assert.assertEquals(shortenedName,"SHORTENED NAME AND ADDRESS");
			
			String name=driver.findElement(By.xpath("//div[@id='short-name']/div/div/label")).getText();
			System.out.println(name);
			Assert.assertEquals(name,"Name");
			
			String shortAddress=driver.findElement(By.xpath("//div[@id='shortened-extra-address']/div/div/label")).getText();
			System.out.println(shortAddress);
			Assert.assertEquals(shortAddress,"Address or Name Continuation");
			
			String streetAddress=driver.findElement(By.xpath("//div[@id='shortened-street-address']/div/div/label")).getText();
			System.out.println(streetAddress);
			Assert.assertEquals(streetAddress,"Street or P.O. Box");
			
			String shortCity=driver.findElement(By.xpath("//div[@id='city-state-zip-section']/div/div/label")).getText();
			System.out.println(shortCity);
			Assert.assertEquals(shortCity,"City, State, Zip");
			
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			driver.findElement(By.xpath("//*[@class='modal fade in']/div/div/div[3]/div/div/button[text()='Accept']")).click();
			Thread.sleep(7000);
			
	 }
	 @And("^I edit details of the organization and click on next button$")
	 public void edit_org_screen() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='tinpersontab']")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='tincorporatetab']")).click();
			Select certt= new Select(driver.findElement(By.xpath(".//*[@id='certificationform']")));
			certt.selectByVisibleText("W-9: Backup Withholding");
			Select back= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			back.selectByVisibleText("Not Required");
			Select backk= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			backk.selectByVisibleText("Req'd - Client Notification");
			Select backkk= new Select(driver.findElement(By.xpath(".//*[@id='ddlw9backupform']")));
			backkk.selectByVisibleText("Req'd - IRS Notification");
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			driver.findElement(By.xpath("//*[@class='modal fade in']/div/div/div[3]/div/div/button[text()='Accept']")).click();
			Thread.sleep(7000);
	 }
	 @And("^I change the organization name with an \"([^\"]*)\"$")
	 public void org_name(String arg) throws Throwable {
		   Thread.sleep(4000);
		   driver.findElement(By.id("organization")).clear();
		   driver.findElement(By.id("organization")).sendKeys(arg);
		   driver.findElement(By.xpath("//*[@id='btnSave']")).click();
	  }
	 
	 @And("^I edit core data with \"([^\"]*)\"$")
	 public void core_data(String arg) throws Throwable {
		   Thread.sleep(4000);
		   driver.findElement(By.xpath("//*[@id='firstname']")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
		   driver.findElement(By.xpath("//*[@id='firstname']")).sendKeys("william#");
			
			driver.findElement(By.xpath("//*[@id='middlename']")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='middlename']")).sendKeys("q!");
			driver.findElement(By.xpath("//*[@id='lastname']")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='lastname']")).sendKeys("gibbs1");
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).sendKeys(arg);
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).sendKeys("545 31 3213");
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("//*[@id='btnSave']")).click();
	 }	 
	 
	 @And("^I clear dob and gender$")
	 public void dob_gender() throws Throwable {
		    Thread.sleep(4000);
		    Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("");
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).clear();
	 }
	 
	 @Then("^I should get dob and gender required inline messages$")
	 public void dob_genderinline_message() throws Throwable {
		    Thread.sleep(2000);
		    String after=driver.findElement(By.xpath("//*[@class='help-block']")).getText();
			System.out.println(after);
			Assert.assertEquals(after,"Gender is required.");
			
			String impctdProduct=driver.findElement(By.xpath("//div[@class='col-lg-2 col-md-2 col-sm-4 col-xs-12 val-group dob-field no-margin has-error']/div[2]/a")).getText();
			System.out.println(impctdProduct);
			Assert.assertEquals(impctdProduct,"Birth Date is required.");
		 
	 }
	 @Then("^I should see inline error messages$")
	 public void inline_message() throws Throwable {
		    Thread.sleep(3000);
		    driver.findElement(By.xpath("//button[@id='cancel']")).click();
		    String fName=driver.findElement(By.xpath("//div[@class='col-lg-3 col-md-3 col-sm-4 col-xs-12 val-group no-margin has-error']/div[2]/a")).getText();
			System.out.println(fName);
			Assert.assertEquals(fName,"First name format is not correct.");
			
			String mName=driver.findElement(By.xpath("//div[@class='col-lg-2 col-md-4 col-sm-4 col-xs-12 val-group no-margin has-error']/div[2]/a")).getText();
			System.out.println(mName);
			Assert.assertEquals(mName,"Middle name format is not correct.");
			
			String lName=driver.findElement(By.xpath("//div[@class='col-lg-3 col-md-3 col-sm-6 col-xs-12 val-group no-margin has-error']/div[2]/a")).getText();
			System.out.println(lName);
			Assert.assertEquals(lName,"Last name format is not correct.");
			
			String date=driver.findElement(By.xpath("//div[@class='col-lg-2 col-md-2 col-sm-4 col-xs-12 val-group dob-field no-margin has-error']/div[2]/a")).getText();
			System.out.println(date);
			//Assert.assertEquals(date,"Please enter the date in the format MM/DD/YYYY.");
			if(date.equals("Please enter the date in the format MM/DD/YYYY."))
			{
				System.out.println("Test case passed");
			}
			else if(date.equals("Birth Date cannot be in the future."))
			{
				System.out.println("second case passed");
			}
	 }
	 
	 @Then("^I should get valid recommendation$")
	 public void org_name() throws Throwable {
		    Thread.sleep(4000);
		    String title=driver.findElement(By.xpath("//*[@class='modal-title ']")).getText();
			System.out.println(title);
			Assert.assertEquals(title, "Organization Name Standardization");
			
			String review=driver.findElement(By.xpath("//*[@class='alert alert-warning fade in alert-styleclass alert-warning']")).getText();
			System.out.println(review);
			Assert.assertEquals(review, "ORGANIZATION NAME WAS STANDARDIZED - REVIEW");
			
			String input=driver.findElement(By.xpath("//*[@class='col-lg-4 col-md-8 col-sm-8 modalip-cls']/span")).getText();
			System.out.println(input);
			Assert.assertEquals(input, "YOUR INPUT");
			
			String standard=driver.findElement(By.xpath("//*[@class='col-lg-offset-4 col-lg-4 col-sm-4 no-padding']/span")).getText();
			System.out.println(standard);
			Assert.assertEquals(standard, "NAME STANDARDIZATION");
			
			String accept=driver.findElement(By.xpath("//*[@id='accept']")).getText();
			System.out.println(accept);
			Assert.assertEquals(accept, "Accept");
			
			String bypass=driver.findElement(By.xpath("//*[@id='bypass']")).getText();
			System.out.println(bypass);
			Assert.assertEquals(bypass, "Bypass");
			
			String cancel=driver.findElement(By.xpath("//*[@id='cancel']")).getText();
			System.out.println(cancel);
			Assert.assertEquals(cancel, "Cancel");
			
			driver.findElement(By.xpath("//*[@id='accept']")).click();
			Thread.sleep(7000);
			
			driver.findElement(By.xpath("//*[@class='modal fade in']/div/div/div[3]/div/div/button[text()='Accept']")).click();
			Thread.sleep(7000);
			
			String accept_text=driver.findElement(By.xpath("//*[@id='main-card-undefined']/div/div/div/div/div[2]/span")).getText();
			System.out.println(accept_text);
			if
			(accept_text.equals("infosys"))
			{
			System.out.println("First test case passed");
			}
			else if
			(accept_text.equals("Infosys Ltd"))
			{
			System.out.println("second test case passed");
			}
			else if
			(accept_text.equals("ABC & ABC"))
			{
			System.out.println("third test case passed");
			}
			else if
			(accept_text.equals("abc abc"))
			{
			System.out.println("fourth test case passed");
			}
			else
			{
				driver.findElement(By.xpath("//*[@id='to']")).click();
			}
			
	 }
	 @Then("^I should land on confirmation page and verify the changes made$")
	 public void confirm_screen() throws Throwable {
		    Thread.sleep(5000);
		    String text=driver.findElement(By.xpath("//*[@class='left-template']/div/div/div/div/div/h2")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"Before");
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@class='baseA']")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@class='relCollapseLink']")).click();
			
	        String prdt=driver.findElement(By.xpath("//*[@id='view-add-48493876']/div[3]/div/div/div/h4")).getText();
			System.out.println(prdt);
			Assert.assertEquals(prdt,"Product");
			
			String role=driver.findElement(By.xpath("//*[@id='view-add-48493876']/div[3]/div/div/div[2]/h4")).getText();
			System.out.println(role);
			Assert.assertEquals(role,"Roles");
			
			driver.findElement(By.xpath("//*[@class='relCollapseLink']")).click();
			
			String adrs=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div/div/h4")).getText();
			System.out.println(adrs);
			Assert.assertEquals(adrs,"Address:");
			String phone=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[5]/div/div/span/h4")).getText();
			System.out.println(phone);
			Assert.assertEquals(phone,"Phone:");
			String email=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[5]/div[2]/div/span/h4")).getText();
			System.out.println(email);
			Assert.assertEquals(email,"Email:");
			String scrunched=driver.findElement(By.xpath("//*[@id='scrunched-info']/h4")).getText();
			System.out.println(scrunched);
			Assert.assertEquals(scrunched,"Scrunched Name/Address   ");
			
			String after=driver.findElement(By.xpath("//div[@class='right-template']/div/h2")).getText();
			System.out.println(after);
			Assert.assertEquals(after,"After");
			
			String clientData=driver.findElement(By.xpath("//*[@id='edit-confirm-after']/div/span")).getText();
			System.out.println(clientData);
			Assert.assertEquals(clientData,"Client Data");
			
			String change=driver.findElement(By.xpath("//*[@id='main-card-undefined']/div/div/div/div[2]/div[4]/div[2]/div[2]/span[2]")).getText();
			System.out.println(change);
			Assert.assertEquals(change,"Req'd - IRS Notification");
			
			String impctdProduct=driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText();
			System.out.println(impctdProduct);
			Assert.assertEquals(impctdProduct,"Impacted Product Number(s):");
			
			String ProductNumber=driver.findElement(By.xpath("//*[@class='bottom']/div/div/div/div[3]/div/div/div/h4")).getText();
			System.out.println(ProductNumber);
			Assert.assertEquals(ProductNumber,"Product Number");
			
			String roleRight=driver.findElement(By.xpath("//*[@class='bottom']/div/div/div/div[3]/div/div/div[2]/h4")).getText();
			System.out.println(roleRight);
			Assert.assertEquals(roleRight,"Roles");
	 }
	 
	  
	 @Then("^I should land on edit confirmation page and verify the changes made$")
	 public void edit_confirm_screen() throws Throwable {
		    String address=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div/div/h4")).getText();
			System.out.println(address);
			Assert.assertEquals(address,"Address:");
			
	        
			String text=driver.findElement(By.xpath("//*[@class='left-template']/div/div/div/div/div/h2")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"Before");
			driver.findElement(By.xpath("//*[@class='expand-collapse-all']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@class='baseA']")).click();
			//driver.findElement(By.xpath("//*[@id='base_13802554']/div[4]/div[7]/div/div/a")).click();
			String num1=driver.findElement(By.xpath("//*[@id='badgeClientCount']")).getText();
			System.out.println(num1);
			Assert.assertEquals(num1,"2");
			
			//String alrt=driver.findElement(By.xpath("//*[@id='card-3']/div[2]/div[3]/span[2]")).getText();
			//System.out.println(alrt);
			//Assert.assertEquals(alrt,"WARNING: CLIENT SELECTED DOES NOT PLAY ANY ROLE THAT CAN BE UPDATED THROUGH THIS SYSTEM.");
			
			driver.findElement(By.xpath("//*[@class='relCollapseLink']")).click();
			/*String relProdMsg=driver.findElement(By.xpath("//*[@id='related-products-panel']/div/div/div")).getText();
			System.out.println(relProdMsg);
			Assert.assertEquals(relProdMsg,"No products available for this Client.");*/
			
			String prdt=driver.findElement(By.xpath("//*[@id='view-add-39652491']/div[3]/div/div/div/h4")).getText();
			System.out.println(prdt);
			Assert.assertEquals(prdt,"Product");
			
			String role=driver.findElement(By.xpath("//*[@id='view-add-39652491']/div[3]/div/div/div[2]/h4")).getText();
			System.out.println(role);
			Assert.assertEquals(role,"Roles");
			
			String after=driver.findElement(By.xpath("//*[@class='right-template']/div/h1")).getText();
			System.out.println(after);
			Assert.assertEquals(after,"Confirm Client Data Changes");
			
			String after1=driver.findElement(By.xpath("//*[@class='right-template']/div/h2")).getText();
			System.out.println(after1);
			Assert.assertEquals(after1,"After");
			
			String underliverable=driver.findElement(By.xpath("//div[@class='undeliver-status']")).getText();
			System.out.println(underliverable);
			Assert.assertEquals(underliverable,"UNDELIVERABLE");
			
			String gender=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div/span")).getText();
	        System.out.println(gender);
	        Assert.assertEquals(gender,"Male");
	        
	        String bday=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[2]/span")).getText();
	        System.out.println(bday);
	        Assert.assertEquals(bday,"07/31/2016");
	        
	        String tin=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[3]/span")).getText();
	        System.out.println(tin);
	        Assert.assertEquals(tin,"545-31-3213");
	        
	        String num=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div/div/span[2]")).getText();
	        System.out.println(num);
	        //Assert.assertEquals(num,"(123)465-4123 Ext :1");
	        
	        String email=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div[2]/div/span[2]")).getText();
	        System.out.println(email);
	        Assert.assertEquals(email,"abinash@gmail.com");
	        
	        String handling=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div/div[2]/span[2]")).getText();
	        System.out.println(handling);
	        Assert.assertEquals(handling,"W-9 Backup Withholding");
	        
	        String withholding=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[4]/div[2]/div[2]/span[2]")).getText();
	        System.out.println(withholding);
	        Assert.assertEquals(withholding,"Missing");
			
			String impctdProduct=driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText();
			System.out.println(impctdProduct);
			Assert.assertEquals(impctdProduct,"Impacted Product Number(s):"); 
	 }
	 

     @When("^I search for \"([^\"]*)\" and \"([^\"]*)\" policy$")
            public void i_search_for_and_policy(String arg1, String arg2) throws Throwable {
    	      driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg1);
     	      driver.findElement(By.xpath("//*[@id='submit']")).click();
 		      Thread.sleep(5000);
 		      driver.findElement(By.xpath("//*[@id='advanced']")).click();
              Thread.sleep(3000);
 		      driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys(arg2);
 		
 		      driver.findElement(By.xpath("//*[@id='submit']")).click();
     }

     @Then("^I should get stop message$")
           public void i_should_get_stop_message() throws Throwable {
    	     Thread.sleep(4000);
    	     String alrt=driver.findElement(By.xpath("//*[@id='alrtMsg']/span[2]")).getText();
 		     System.out.println(alrt);
 		//Assert.assertEquals(alrt,"WARNING: DIFFERENT CLIENT TYPES CANNOT BE UPDATED AT THE SAME TIME. UPDATE ONE CLIENT TYPE AT A TIME.");
 		
         if(alrt.equals("WARNING: CLIENT SELECTED IS RELATED TO INVESTMENT ACCOUNTS; CANNOT BE UPDATED THROUGH THIS SYSTEM."))
              {
         	   System.out.println("First test cases is Passed");
              }
         else if(alrt.equals("WARNING: CLIENT RECORDS SELECTED ARE ASSOCIATED WITH DECEASED CLIENT. THESE RECORDS CANNOT BE UPDATED."))
              {
         	   System.out.println("second test cases is Passed");
              }
         else if(alrt.equals("WARNING: CLIENT SELECTED DOES NOT PLAY ANY ROLE THAT CAN BE UPDATED THROUGH THIS SYSTEM."))
              {
    	           System.out.println("Third test cases is Passed");
              }
         else if(alrt.equals("WARNING: OPERATOR LAST NAME MATCHES CLIENT'S LAST NAME ON AT LEAST ONE CLIENT RECORD. PLEASE HAVE CASE REASSIGNED."))
              {
 	           System.out.println("Fourth test cases is Passed");
              }
         else if(alrt.equals("WARNING: UPDATES CANNOT BE MADE ON A PENDING POLICY WHEN STATUS IS FIELD OFFICE INPUT INCOMPLETE."))
              {
                System.out.println("Fifth test cases is Passed");
              }
         else if(alrt.equals("WARNING: CLIENT SELECTED HAS AN INVALID NAME OF CADOGAN J EXECUTORS; CANNOT BE UPDATED THROUGH THIS SYSTEM."))
              {
                System.out.println("Sixth test cases is Passed");
              }
         
         else if(alrt.equals("WARNING: CLIENT SELECTED IS RELATED TO ULIFE POLICIES; CANNOT BE UPDATED THROUGH THIS SYSTEM. CASE SHOULD BE TRANSFERRED TO ADVANCED MARKETS OPERATIONS DIVISION."))
              {
           System.out.println("Seventh test cases is Passed");
              }
          
          
         else
         {
         	driver.findElement(By.xpath("//*[@id='qu']"));
         }
   
     }
     
     @Then("^I should get a new popup window with accept cancel and bypass buttons$")
     public void accept_cancel_bypass() throws Throwable {
    	 Thread.sleep(7000);
 		
         String title=driver.findElement(By.xpath("//*[@class='modal-title ']")).getText();
 		 System.out.println(title);
 		 Assert.assertEquals(title, "Organization Name Standardization");
 		
 		 String title1=driver.findElement(By.xpath("//*[@class='alert alert-warning fade in alert-styleclass alert-warning']")).getText();
 		 System.out.println(title1);
 		 Assert.assertEquals(title1, "ORGANIZATION NAME WAS STANDARDIZED - REVIEW");
 		
 		
 		 Thread.sleep(10000);
 		 driver.findElement(By.xpath("//*[@id='bypass']")).click();
 		 Thread.sleep(4000);
 		
 		
 		 driver.findElement(By.xpath("//*[@class='modal fade in']/div/div/div[3]/div/div[2]/button")).click();
 		 Thread.sleep(7000);
 		
 		 String bypass=driver.findElement(By.xpath("//*[@id='main-card-undefined']/div/div/div/div/div[2]/span")).getText();
 		 System.out.println(bypass);
 		 Assert.assertEquals(bypass, "THE infosys");
 		
 		 Thread.sleep(3000);
 	     driver.findElement(By.xpath("//*[@id='btnBack']")).click();
 		
 		 Thread.sleep(7000);
 		 driver.findElement(By.xpath("//*[@id='btnSave']")).click();
 		
 		 String cancel=driver.findElement(By.xpath("//*[@id='cancel']")).getText();
 		 System.out.println(cancel);
 		 Assert.assertEquals(cancel, "");

     }
	 
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	       
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        
	        
	        else if(!scenario.isFailed())
	        
	            {
	        	
	        	driver.quit();
	        	
	        	}
	        
	        }
	        
	       }
         

