package stepDefinition;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangeOwner extends AbstractPageDefinition {
	
	
	
	@Before
	public void openBrowser(){ 
	 System.out.println("Called openBrowser");
	 System.setProperty("webdriver.ie.driver", "C://BRANCHES/IEDriverServer.exe");
     DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();

     ieCapabilities.setCapability("ignoreProtectedModeSettings", true);
     ieCapabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
     ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
     ieCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
     ieCapabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);

     driver = new InternetExplorerDriver(ieCapabilities);
     driver.get("http://ws43stage.nml.com/clntadm/index.html");
     driver.manage().deleteAllCookies();
     driver.manage().window().maximize();
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     
    //for invoking chrome browser when developer mode enabled extension pop up is there
       //System.out.println("Called openBrowser");
       //ChromeOptions options = new ChromeOptions();
       //options.addArguments("chrome.switches","--disable-extensions");
       //System.setProperty("webdriver.chrome.driver","C://BRANCHES/chromedriver.exe");
       //driver = new ChromeDriver(options);
       //driver.get("http://ws43stage.nml.com/clntadm/index.html");
       //driver.manage().deleteAllCookies();
       //driver.manage().window().maximize();
       //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
       
   //for invoking chrome browser
   /*    System.out.println("Called openBrowser");
         System.setProperty("webdriver.chrome.driver", "C://BRANCHES/chromedriver.exe");
         driver = new ChromeDriver();
         driver.get("http://ws43stage.nml.com/clntadm/index.html");
         driver.manage().deleteAllCookies();
         driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);*/
}
	 @When("^I click on change Owner radio button$")
		public void i_click_on_change_Owner_radio_button() throws Throwable{
			Thread.sleep(8000);
			driver.findElement(By.xpath("//*[@class='role-bottom-line role-row-highlight']/label[text()='Owner']")).click();
			driver.findElement(By.xpath("//*[@id='role-action-change-15']")).click();
			
	 }
	 @And("^I provide Owner details$")
		public void i_provide_Owner_details() throws Throwable{
		 Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id='ownerEffectiveDate']")).click();
			driver.findElement(By.xpath("//*[@id='ownerEffectiveDate']")).sendKeys("03/12/2016");
			Thread.sleep(2000);
    		Select rs= new Select(driver.findElement(By.xpath(".//*[@id='relationships']")));
    		rs.selectByVisibleText("Father");
    		driver.findElement(By.xpath("//*[@id='btnNext']")).click();
    		Thread.sleep(5000);
	 }
	 @Then("^I should get change owner confirmation page$")
		public void i_should_get_change_owner_confirmation_page() throws Throwable{
			String text= driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText();
			System.out.println(text);
			Assert.assertEquals(text,"Confirm Owner Change");
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div[5]/div/div/div/div/span")).getText().contains("RELATED INFORMATION FOR OWNER"));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div[5]/div/div/div/div/h4[1]")).getText().contains("Effective Date: "));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div[5]/div/div/div/div/h4[2]")).getText().contains("New Owner's Relationship to Insured: "));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div[5]/div/div/div/div/h4[3]")).getText().contains("Insured Becomes Owner at Age: "));
	 
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/div/div/div[3]/div[2]/div/span")).getText().contains("Product Number"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/div/div/div[3]/div/span")).getText().contains("Impacted Product Number(s):"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/div/div/div[3]/div[2]/div[2]")).getText().contains("20404714"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btnSubmit']")).getText().contains("Submit"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@id='btnCancel']")).getText().contains("Cancel"));
	 }
	 
   @After
	public void embedScreenshot(Scenario scenario) {
	       
        if(scenario.isFailed()) {
        try {
        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
            driver.quit();
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
        	
        }
        }
else if(!scenario.isFailed())
            
        {
    	
    	driver.quit();
    	
    	}
    
    }
    
   }

	
    
    
