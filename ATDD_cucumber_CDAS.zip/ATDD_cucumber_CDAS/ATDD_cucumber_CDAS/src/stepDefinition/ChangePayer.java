package stepDefinition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.Select;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;


import cucumber.api.java.en.When;

public class ChangePayer extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	

	@Given("^I am on CDAS landing screen$")    
    public void i_am_on_CDAS_landing_screen() throws Throwable {
	        driver.get("http://ws43stage.nml.com/clntadm/index.html");
	        //driver.manage().deleteAllCookies();
	    	driver.manage().window().maximize();
	    	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     }
    @And("^I searched for (\\d+) and I'm on change role screen$")
    public void i_searched_for_a_and_I_m_on_change_role_screen(String arg1) throws Throwable {
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("donald trump");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='advanced']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys(arg1);
		
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='work']")).click();
		driver.findElement(By.xpath("//*[@id='prod-btn']")).click();
		
		
    }
    @And("^I searched for policy D(\\d+) and I'm on change role screen$")
    public void i_searched_for_policy_D_and_I_m_on_change_role_screen(String arg1) throws Throwable {
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("donald trump");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='advanced']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys("D1981898");
		
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='work']")).click();
		driver.findElement(By.xpath("//*[@id='prod-btn']")).click();
        
    }
    @And("^I searched for policy number D(\\d+) and I'm on change role screen$")
    public void i_searched_for_policy_number_D_and_I_m_on_change_role_screen(String arg1) throws Throwable {
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("donald trump");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='advanced']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@name='product'][@id='product']")).sendKeys("D3002461");
		
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(7000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='work']")).click();
		driver.findElement(By.xpath("//*[@id='prod-btn']")).click();
    }
    
    @When("^I click on Payer radio button$")
	public void I_click_on_Payer_radio_button() throws Throwable {
		driver.findElement(By.xpath("//*[@id='role-label']/label[text()='Payer']")).click();
		driver.findElement(By.xpath("//*[@class='col-lg-12 col-md-12 col-sm-12 col-xs-12 back-card-style']/div[1]/label")).click();
		System.out.println("Clicked on role change option");
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[starts-with(@id,'change-14')]")).click();
		Thread.sleep(10000);
	}
    @When("^I select Payer radio button$")
	public void I_select_Payer_radio_button() throws Throwable {
		driver.findElement(By.xpath("//*[@id='role-label']/label[text()='Payer']")).click();
		driver.findElement(By.xpath("//*[@id='role-action-change-14']/span")).click();
		System.out.println("Clicked on role change option");
		Thread.sleep(10000);
		
	}
    
    @And("^Click on the first card before confirmation screen$")
    public void Click_on_the_first_card_before_confirmation_screen() throws Throwable{
    	Thread.sleep(10000);
    	if(driver.findElement(By
				.xpath(".//*[@id='main-card-1']/div[4]/div/div/div/div/div/label")) !=null){
			System.out.println("radio button exits");
			WebElement radioLabel = driver.findElement(By
					.xpath(".//*[@id='main-card-1']/div[4]/div/div/div/div/div/label"));
			System.out.println(radioLabel.getText());
			radioLabel.click(); 
		}
    	Thread.sleep(5000);
    	driver.findElement(By.xpath("//*[@id='btnChangeNext']")).click();
    }
    @And("^Select the other card before confirmation page$")
    public void Select_the_other_card_before_confirmation_screen() throws Throwable{
    	driver.findElement(By.xpath("//*[@id='main-card-undefined']/div[4]/div/div/div/div/div/label")).click();
    	driver.findElement(By.xpath("//*[@id='btnChangeNext']")).click();
		
    }
    @And("^Use existing client as new Payer$")
    public void Use_existing_client_as_new_Payer() throws Throwable{
    	
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("Abinash panigrahi");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		driver.findElement(By.xpath("//div[@class='fly-actions-link']/button[text()='Use']")).click();
    }
    @And("^Use New client as new Payer$")
    public void Use_New_client_as_new_Payer() throws Throwable{
    	
    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("ashutosh panigrahi");
    	driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("311 Hillcrest Dr");
		driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Lower Burrell");
		Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
	    sc.selectByVisibleText("PA - Pennsylvania");
		driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("15068");
		Thread.sleep(15000);
		driver.findElement(By.xpath("//*[@id='btnSave']")).click();
		
    }
    
    @After
	public void embedScreenshot(Scenario scenario) {
	       
        if(scenario.isFailed()) {
        try {
        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png");
            driver.quit();
        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
        	
        }
        }
        else if(!scenario.isFailed())
            
        {
    	
    	driver.quit();
    	
    	}
        
    }
   
   }

