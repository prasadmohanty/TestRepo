package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class ChangePayerNegative extends AbstractPageDefinition {
	  WebDriver driver = getDriver(null);
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
        }*/
	 @And("^provide invalid client details$")
	    public void new_invalid_details() throws Throwable{
	    	
	    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("ashutosh panigrahi");
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			Thread.sleep(5000);
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).click();
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).click();
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).sendKeys("45444644");
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("");
			driver.findElement(By.xpath("//*[@id='city']")).sendKeys("");
			Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
		    
			driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("");
			driver.findElement(By.xpath(".//*[@id='us-phone']")).click();
		    driver.findElement(By.xpath(".//*[@id='us-phone']")).sendKeys("(1");
		    
		    driver.findElement(By.xpath(".//*[@id='extcode']")).sendKeys("a");
		    driver.findElement(By.xpath(".//*[@id='email']")).sendKeys("(1");
		    driver.findElement(By.xpath(".//*[@id='annual-income']")).sendKeys("s");
		    driver.findElement(By.xpath(".//*[@id='net-worth']")).sendKeys("(1a");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
	    }
	    
	    @Then("^I should get inline error messages$")
	    public void newclient_error() throws Throwable{
	    	Thread.sleep(6000);
	    	String Taxper_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[2]/div/div[3]/div[3]/div[2]/a")).getText();
		    System.out.println(Taxper_invalid);
			Assert.assertEquals(Taxper_invalid,"This is invalid TIN Number.");	
			
			String POBox_invalid=driver.findElement(By.xpath("//*[@id='street-pad']/div[2]/a")).getText();
		    System.out.println(POBox_invalid);
			Assert.assertEquals(POBox_invalid,"Street or PO Box is required.");
			
			String City_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[6]/div[1]/div[2]/a")).getText();
		    System.out.println(City_invalid);
			Assert.assertEquals(City_invalid,"City is required.");
			
			String State_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[6]/div[2]/div[2]/a")).getText();
		    System.out.println(State_invalid);
			Assert.assertEquals(State_invalid,"State is required.");
			
			String Zip_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[6]/div[3]/div[2]/a")).getText();
		    System.out.println(Zip_invalid);
			Assert.assertEquals(Zip_invalid,"Zip Code is required.");
			
			String Extension_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[11]/div[2]/a")).getText();
		    System.out.println(Extension_invalid);
			Assert.assertEquals(Extension_invalid,"Invalid Extension. Only numbers are allowed.");
			
			String Phone_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[10]/div[2]/a")).getText();
		    System.out.println(Phone_invalid);
			Assert.assertEquals(Phone_invalid,"Phone Number must be completely filled. Valid Format: (XXX)XXX-XXXX");
			
			String Email_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[4]/div/div/div[13]/div[2]/a")).getText();
		    System.out.println(Email_invalid);
			Assert.assertEquals(Email_invalid,"Invalid e-mail format.");
			
			String Income_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[5]/div[2]/div/div/div[2]/div[2]/a")).getText();
		    System.out.println(Income_invalid);
			Assert.assertEquals(Income_invalid,"Invalid Annual Income format. Only numbers are allowed.");
			
			String Net_Worth_less_invalid=driver.findElement(By.xpath("//*[@id='new-client']/div/div[1]/div[2]/div[5]/div[2]/div/div/div[4]/div[2]/a")).getText();
		    System.out.println(Net_Worth_less_invalid);
			Assert.assertEquals(Net_Worth_less_invalid,"Invalid Net Worth Less Primary Residence format. Only digits are allowed.");
			
			
	    }
	    @Then("^I should get an alert$")
	    public void I_should_get_an_alert$() throws Throwable{
	    	String head_Text=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(head_Text);
			//Assert.assertEquals(head_Text,"ALERT: ISA 0068395 PAYER CHANGES NOT ALLOWED. NEW ISA MUST BE SET UP OR POLICY REMOVED FROM ISA");
			if(head_Text.equals("ALERT: ISA 0068395 PAYER CHANGES NOT ALLOWED. NEW ISA MUST BE SET UP OR POLICY REMOVED FROM ISA"))
			{
				System.out.println("first test case Passed");	
			}
			else if(head_Text.equals("WARNING: POLICY NUMBER D1981898 HAS BEEN TERMINATED TOO LONG; INFORMATION IS NO LONGER AVAILABLE ONLINE. CHANGES TO THIS DI CONTRACT ARE NOT ALLOWED."))
			{
				System.out.println("Second test case Passed");	
			}
			else if(head_Text.equals("ALERT: POLICY IS EP, PROCESS VIA EP SYSTEM"))
			{
				System.out.println("Third test case Passed");	
			}
			else
			{
				System.out.println("test case failed");
			}
			
	    }
	    @Then("^I should land on change payer confirmation page$")
	    public void payer_confirmation() throws Throwable{
	    	Thread.sleep(4000);
	    	String heading=driver.findElement(By.xpath("//div[@class='center-float']/h1")).getText();
		    System.out.println(heading);
			Assert.assertEquals(heading,"Confirm Payer Change");
			
			String from=driver.findElement(By.xpath("//div[@id='main-card-0']/div/div/span")).getText();
		    System.out.println(from);
			Assert.assertEquals(from,"Change Payer From");
			
			String to=driver.findElement(By.xpath("//div[@id='main-card-1']/div/div/span")).getText();
		    System.out.println(to);
			Assert.assertEquals(to,"Change Payer To");
			
		    boolean submit=driver.findElement(By.xpath("//button[@id='btnSubmit']")).isEnabled();
		    System.out.println(submit);
		    Assert.assertEquals(submit, true);
		    
		    boolean cancel=driver.findElement(By.xpath("//button[@id='btnCancel']")).isEnabled();
		    System.out.println(cancel);
		    Assert.assertEquals(cancel, true);
		    
		    boolean back=driver.findElement(By.xpath("//button[@id='btnBack']")).isEnabled();
		    System.out.println(back);
		    Assert.assertEquals(back, true);
	    	
	    }
	    
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	        
	    }
	   
	   }


