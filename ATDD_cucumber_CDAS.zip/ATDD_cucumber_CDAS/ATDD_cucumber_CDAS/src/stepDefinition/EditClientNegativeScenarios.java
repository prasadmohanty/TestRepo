package stepDefinition;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
//import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.remote.DesiredCapabilities;
//import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import cucumber.api.Scenario;
import cucumber.api.java.After;
//import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;

public class EditClientNegativeScenarios extends AbstractPageDefinition {
	
	WebDriver driver = getDriver(null);
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	 @And("^I remove the name,birthday and tin fields$")
	 public void name_gender_bday_remove() throws Throwable {
		   Thread.sleep(2000);
		   driver.findElement(By.xpath("//*[@id='firstname']")).clear();
		   driver.findElement(By.xpath("//*[@id='lastname']")).clear();
		 
	 }
	 
	 @And("^I use invalid demographic fields$")
	 public void invalid_demographic() throws Throwable {
		    Thread.sleep(2000);
		    driver.findElement(By.xpath(".//*[@id='phonenonusatab']")).click();
			Thread.sleep(3000);
		    driver.findElement(By.xpath(".//*[@id='foreignnumber']")).sendKeys("!");
		    String for_phone=driver.findElement(By.xpath("//*[@id='foreign-phone']/div[2]/a")).getText();
		    System.out.println(for_phone);
			Assert.assertEquals(for_phone,"Invalid Foreign code. Only numbers are allowed.");
			
			driver.findElement(By.xpath(".//*[@id='phoneusatab']")).click();
			Thread.sleep(2000);
		    driver.findElement(By.xpath(".//*[@id='us-phone']")).clear();
		    driver.findElement(By.xpath(".//*[@id='us-phone']")).sendKeys("134215632");
		    driver.findElement(By.xpath("//*[@id='extcode']")).sendKeys("!");
		    driver.findElement(By.xpath("//*[@id='email']")).sendKeys("!");
		    driver.findElement(By.xpath("//*[@id='annual-income']")).sendKeys("!");
		    driver.findElement(By.xpath("//*[@id='net-worth'] ")).sendKeys("a");
		 
	 }
	 @And("^I use invalid \"([^\"]*)\"street , \"([^\"]*)\"city and \"([^\"]*)\"zip fields$")
	 public void i_use_invalid_and_fields(String arg1, String arg2, String arg3) throws Throwable {
		//usa country address validation
			driver.findElement(By.xpath("//*[@id='countryusatab']")).click();
			Thread.sleep(6000);
			//input("ExtraAddress_xapth", data.get("Extra Address"));
			driver.findElement(By.xpath("//*[@id='pobox']")).clear();
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys(arg1);
			driver.findElement(By.xpath("//*[@id='city']")).clear();
			driver.findElement(By.xpath("//*[@id='city']")).sendKeys(arg2);
			driver.findElement(By.xpath("//*[@id='zip']")).clear();
			driver.findElement(By.xpath("//*[@id='zip']")).sendKeys(arg3);
			driver.findElement(By.xpath("//*[@id='extraaddress']")).sendKeys("1@");
			//input("ExtraAddress_xapth", data.get("Extra Address"));
			
			String spclhandling1=driver.findElement(By.xpath("//*[@id='specialHandling']/option")).getText();
			System.out.println(spclhandling1);
			Assert.assertEquals(spclhandling1,"Yes");
	 }
	 
	 @Then("^I should get inline error messages for all the address fields$")
	 public void address_inline() throws Throwable {
		 String extraAd=driver.findElement(By.xpath("//div[@class='col-lg-4 col-md-4 col-sm-8 col-xs-12 usa-field tab-fixed-style val-group extraaddress no-margin has-error']/div[2]/a")).getText();
			System.out.println(extraAd);
			Assert.assertEquals(extraAd,"Characters allowed in Extra Address are a-z, A-Z, 0-9, /, &, and #.");
			
			String street=driver.findElement(By.xpath("//*[@id='street-pad']/div[2]/a")).getText();
			System.out.println(street);
		    if
		    (street.equals("Characters allowed in street are a-z, A-Z, 0-9, number sign(#) and forward slash (/)"))
		    	{
		    	System.out.println("First test cases passed");
		    	}
		    else if(street.equals("Street or PO Box is required."))
		    {
		    	System.out.println("second test cases passed");
		    }
		    else
		    {
		    	System.out.println("test case failed");
		    	driver.findElement(By.xpath("//*[@id='kux-']")).click();
		    }
		    
		    String city=driver.findElement(By.xpath("//div[@class='col-lg-3 col-md-3 col-sm-6 col-xs-8 usa-field val-group city no-margin has-error']/div[2]/a")).getText();
			System.out.println(city);
		    if
		    (city.equals("Characters allowed in city name are a-z and A-Z."))
		    	{
		    	System.out.println("First test cases passed");
		    	}
		    else if(city.equals("City is required."))
		    {
		    	System.out.println("second test cases passed");
		    }
		    else
		    {
		    	System.out.println("test case failed");
		    	driver.findElement(By.xpath("//*[@id='kur-']")).click();
		    }
		    
		    String zip=driver.findElement(By.xpath("//div[@class='col-lg-2 col-md-2 col-sm-6 col-xs-12 usa-field val-group zip no-margin has-error']/div[2]/a")).getText();
			System.out.println(zip);
		    if
		    (zip.equals("Zip code must be 5 numeric digits."))
		    	{
		    	System.out.println("First test case passed");
		    	}
		    else if(zip.equals("Zip Code is required."))
		    {
		    	System.out.println("second test case passed");
		    }
		    else
		    {
		    	System.out.println("test case failed");
		    	driver.findElement(By.xpath("//*[@id='kuj-']")).click();
		    }
		    
		 
		 
	 }
		
	 @Then("^I should get inline messages for all the fields$")
	 public void name_gender_bday_inline() throws Throwable {
		
			String text_firstname=driver.findElement(By.xpath("//*[@id='firstname']")).getAttribute("placeholder");
			System.out.println(text_firstname);
			Assert.assertEquals(text_firstname,"Select or Type First Name");
			
			String text_middlename=driver.findElement(By.xpath("//*[@id='middlename']")).getAttribute("placeholder");
			System.out.println(text_middlename);
			Assert.assertEquals(text_middlename,"Select or Type Middle Name");
			
			
			String text_lastename=driver.findElement(By.xpath("//*[@id='lastname']")).getAttribute("placeholder");
			System.out.println(text_lastename);
			Assert.assertEquals(text_lastename,"Select or Type Last Name");
			
			String text_bday=driver.findElement(By.xpath("//*[@id='dateofbirth']")).getAttribute("placeholder");
			System.out.println(text_bday);
			Assert.assertEquals(text_bday,"Select or Type Birthdate");
			
			String text_TIN=driver.findElement(By.xpath("//*[@id='taxpayerid']")).getAttribute("placeholder");
			System.out.println(text_TIN);
			Assert.assertEquals(text_TIN,"Select or Type Taxpayer ID");
			
			String bcolor=driver.findElement(By.xpath("//*[@id='taxpayerid']")).getCssValue("background-color");
			System.out.println(bcolor);
			Assert.assertEquals(bcolor,"rgba(253, 244, 165, 1)");
			
			String gender=driver.findElement(By.xpath("//*[@id='ddlgender']")).getCssValue("background-color");
			System.out.println(gender);
			Assert.assertEquals(gender,"rgba(253, 244, 165, 1)");
			
		 
	 }
	 @Then("^I should get inline error messages for all the fields$")
	 public void demo_inline() throws Throwable {
		    String phone=driver.findElement(By.xpath("//*[@class='phone']/div[4]/div[2]/a")).getText();
		    System.out.println(phone);
			Assert.assertEquals(phone,"Phone Number must be completely filled. Valid Format: (XXX)XXX-XXXX");
		    
			String Extension_invalid=driver.findElement(By.xpath("//*[@class='phone']/div[5]/div[2]/a")).getText();
		    System.out.println(Extension_invalid);
			Assert.assertEquals(Extension_invalid,"Invalid Extension. Only numbers are allowed.");
			
			String Email_invalid=driver.findElement(By.xpath("//*[@class='phone']/div[7]/div[2]/a")).getText();
		    System.out.println(Email_invalid);
			Assert.assertEquals(Email_invalid,"Invalid e-mail format.");
			
			String Income_invalid=driver.findElement(By.xpath("//*[@class='non-person']/div[2]/div/div/div[2]/div[2]/a")).getText();
		    System.out.println(Income_invalid);
			Assert.assertEquals(Income_invalid,"Invalid Annual Income format. Only numbers are allowed.");
			
			String Net_Worth_less_invalid=driver.findElement(By.xpath("//*[@class='non-person']/div[2]/div/div/div[4]/div[2]/a")).getText();
		    System.out.println(Net_Worth_less_invalid);
			Assert.assertEquals(Net_Worth_less_invalid,"Invalid Net Worth Less Primary Residence format. Only digits are allowed.");
			
			
       }
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	       
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        
	        
	        else if(!scenario.isFailed())
	        
	            {
	        	
	        	driver.quit();
	        	
	        	}
	        
	        }
	        
	       }
   

