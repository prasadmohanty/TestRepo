package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class ValidationOfEditClientHighlightScenarios extends AbstractPageDefinition {
	
	WebDriver driver = getDriver(null);
	
	 /*@Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  
       }*/
	
	 
	 @And("^I change name,dob and tin and next$")
		   public void change_name_dob_tin() throws Throwable{
			Thread.sleep(3000);
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			//input("dateOfBirth_xpath", data.get("Date of Birth"));
		    //input("TaxID_xpath", data.get("Tax Payer ID"));
			driver.findElement(By.xpath("//*[@id='firstname']")).clear();
			driver.findElement(By.xpath("//*[@id='firstname']")).sendKeys("Nikunjaa");
			
			driver.findElement(By.xpath("//*[@id='middlename']")).clear();
			driver.findElement(By.xpath("//*[@id='middlename']")).sendKeys("JS");
			
			driver.findElement(By.xpath("//*[@id='lastname']")).clear();
			driver.findElement(By.xpath("//*[@id='lastname']")).sendKeys("Dasha");
			
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).clear();
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).sendKeys("07/12/2016");
			
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).clear();
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).sendKeys("124321675");
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			
		  }
	 
	 @And("^I change phone,mail and click on next$")
	   public void change_phone_mail() throws Throwable{
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='us-phone']")).sendKeys("1234534534");
			driver.findElement(By.xpath("//*[@id='email']")).sendKeys("a@gmail.com");
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
		 
	 }
	 
	 @And("^click on  second edit client option$")
	   public void second_edit() throws Throwable{
		    Thread.sleep(3000);
			driver.findElement(By.xpath("//*[@id='card-2']/div/div[3]/button")).click();
	 }
	 @Then("^I should view all the missing field as highlighted$")
	   public void edit_screen_highlight() throws Throwable{
		    Thread.sleep(3000);
		    String po=driver.findElement(By.xpath("//*[@id='pobox']")).getCssValue("background-color");
			System.out.println(po);
			Assert.assertEquals(po,"rgba(253, 244, 165, 1)");
			
			String city=driver.findElement(By.xpath("//*[@id='city']")).getCssValue("background-color");
			System.out.println(city);
			Assert.assertEquals(city,"rgba(253, 244, 165, 1)");
			
			String state=driver.findElement(By.xpath("//*[@id='state']")).getCssValue("background-color");
			System.out.println(state);
			Assert.assertEquals(state,"rgba(253, 244, 165, 1)");
			
			String zip=driver.findElement(By.xpath("//*[@id='zip']")).getCssValue("background-color");
			System.out.println(zip);
			Assert.assertEquals(zip,"rgba(253, 244, 165, 1)");
			
			String phone=driver.findElement(By.xpath("//*[@id='us-phone']")).getCssValue("background-color");
			System.out.println(phone);
			Assert.assertEquals(phone,"rgba(253, 244, 165, 1)");
			
			String email=driver.findElement(By.xpath("//*[@id='email']")).getCssValue("background-color");
			System.out.println(email);
			Assert.assertEquals(email,"rgba(253, 244, 165, 1)");
			
			String taxpayerid=driver.findElement(By.xpath("//*[@id='taxpayerid']")).getCssValue("background-color");
			System.out.println(taxpayerid);
			Assert.assertEquals(taxpayerid,"rgba(253, 244, 165, 1)");
			
			String ddlgender=driver.findElement(By.xpath("//*[@id='ddlgender']")).getCssValue("background-color");
			System.out.println(ddlgender);
			Assert.assertEquals(ddlgender,"rgba(253, 244, 165, 1)");
	 }
	 @Then("^I should get old values as striken out and new text on confirm screen$")
	     public void strikedOut() throws Throwable{
		    Thread.sleep(4000);
	        String name=driver.findElement(By.xpath("//*[@id='card-1']/div/div[2]/span")).getAttribute("class");
			System.out.println(name);
			Assert.assertEquals(name,"h7 changed-text ");
			
			String name1=driver.findElement(By.xpath("//*[@id='card-1']/div/div[2]/span")).getText();
			System.out.println(name1);
			Assert.assertEquals(name1,"Nikunja J Dash CHPC");
			
			String gender_before=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div/span")).getAttribute("class");
			System.out.println(gender_before);
			Assert.assertEquals(gender_before,"inline changed-text ");
			
			String gender_before1=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div/span")).getText();
			System.out.println(gender_before1);
			Assert.assertEquals(gender_before1,"Female");
			
			String dob=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div[2]/span")).getAttribute("class");
			System.out.println(dob);
			Assert.assertEquals(dob,"changed-text ");
			
			String dob1=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div[2]/span")).getText();
			System.out.println(dob1);
			Assert.assertEquals(dob1,"07/26/1935");
			
			String tin=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div[3]/span")).getAttribute("class");
			System.out.println(tin);
			Assert.assertEquals(tin,"changed-text ");
			
			String tin1=driver.findElement(By.xpath("//*[@id='card-1']/div[2]/div[2]/div[3]/span")).getText();
			System.out.println(tin1);
			Assert.assertEquals(tin1,"510-21-0437");
			
	        //Validation of after screen
			String name_after=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div/div[2]/span")).getAttribute("class");
			System.out.println(name_after);
			Assert.assertEquals(name_after,"h7  new-text");
			
			String name_after1=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div/div[2]/span")).getText();
			System.out.println(name_after1);
			Assert.assertEquals(name_after1,"Nikunjaa JS Dasha CHPC");
			
			String gender_after=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div/span")).getAttribute("class");
			System.out.println(gender_after);
			Assert.assertEquals(gender_after,"inline  new-text");
			
			String gender_after1=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div/span")).getText();
			System.out.println(gender_after1);
			Assert.assertEquals(gender_after1,"Male");
			
			String dob_after=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[2]/span")).getAttribute("class");
			System.out.println(dob_after);
			Assert.assertEquals(dob_after," new-text");
			
			String dob_after1=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[2]/span")).getText();
			System.out.println(dob_after1);
			Assert.assertEquals(dob_after1,"07/12/2016");
			
			String tin_after=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[3]/span")).getAttribute("class");
			System.out.println(tin_after);
			Assert.assertEquals(tin_after," new-text");
			
			String tin_after1=driver.findElement(By.xpath("//*[@id='card-container']/div/div/div/div/div[2]/div[2]/div[3]/span")).getText();
			System.out.println(tin_after1);
			Assert.assertEquals(tin_after1,"124-32-1675");
			
			//Validation of 1nd,3rd and 4th card
			String name2=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div/div[2]/span")).getAttribute("class");
			System.out.println(name2);
		    Assert.assertEquals(name2,"h7 changed-text ");
				
			String name3=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div/div[2]/span")).getText();
			System.out.println(name3);
			Assert.assertEquals(name3,"Nikunja J Dash CHPC");
			
			String name4=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div/div[2]/span")).getAttribute("class");
			System.out.println(name4);
		    Assert.assertEquals(name4,"h7 changed-text ");
				
			String name5=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div/div[2]/span")).getText();
			System.out.println(name5);
			Assert.assertEquals(name5,"Nikunja J Dash CHPC");
			
			//String name6=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div/div[2]/span")).getAttribute("class");
			//System.out.println(name6);
		    //Assert.assertEquals(name6,"h7 changed-text ");
				
			//String name7=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div/div[2]/span")).getText();
			//System.out.println(name7);
			//Assert.assertEquals(name7,"David H Ingbar");
			
			//gender
			String gender2=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div/span")).getAttribute("class");
			System.out.println(gender2);
			Assert.assertEquals(gender2,"inline changed-text ");
			
			String gender3=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div/span")).getText();
			System.out.println(gender3);
			Assert.assertEquals(gender3,"Female");
			
			String gender4=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div/span")).getAttribute("class");
			System.out.println(gender4);
			Assert.assertEquals(gender4,"inline changed-text ");
			
			String gender5=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div/span")).getText();
			System.out.println(gender5);
			Assert.assertEquals(gender5,"Female");
			
			//String gender6=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div/span")).getAttribute("class");
			//System.out.println(gender6);
			//Assert.assertEquals(gender6,"inline changed-text ");
			
			//String gender7=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div/span")).getText();
			//System.out.println(gender7);
			//Assert.assertEquals(gender7,"Female");
			
			//DOB
			String dob2=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div[2]/span")).getAttribute("class");
			System.out.println(dob2);
			Assert.assertEquals(dob2,"changed-text ");
			
			String dob3=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div[2]/span")).getText();
			System.out.println(dob3);
			Assert.assertEquals(dob3,"07/26/1935");
			
			String dob4=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div[2]/span")).getAttribute("class");
			System.out.println(dob4);
			Assert.assertEquals(dob4,"changed-text ");
			
			String dob5=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div[2]/span")).getText();
			System.out.println(dob5);
			Assert.assertEquals(dob5,"07/26/1935");
			
			//String dob6=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div[2]/span")).getAttribute("class");
			//System.out.println(dob6);
			//Assert.assertEquals(dob6,"changed-text ");
			
			//String dob7=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div[2]/span")).getText();
			//System.out.println(dob7);
			//Assert.assertEquals(dob7,"07/26/1935");
			
			//tin
			String tin2=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div[3]/span")).getAttribute("class");
			System.out.println(tin2);
			Assert.assertEquals(tin2,"changed-text ");
			
			String tin3=driver.findElement(By.xpath("//*[@id='base_12973301']/div[3]/div/div/div/div[2]/div[2]/div[3]/span")).getText();
			System.out.println(tin3);
			Assert.assertEquals(tin3,"510-21-0437");
			
			String tin4=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div[3]/span")).getAttribute("class");
			System.out.println(tin4);
			Assert.assertEquals(tin4,"changed-text ");
			
			String tin5=driver.findElement(By.xpath("//*[@id='base_12973301']/div[4]/div/div/div/div[2]/div[2]/div[3]/span")).getText();
			System.out.println(tin5);
			Assert.assertEquals(tin5,"510-21-0437");
			
			//String tin6=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div[3]/span")).getAttribute("class");
			//System.out.println(tin6);
			//Assert.assertEquals(tin6,"changed-text ");
			
			//String tin7=driver.findElement(By.xpath("//*[@id='base_12973301']/div[5]/div/div/div/div[2]/div[2]/div[3]/span")).getText();
			//System.out.println(tin7);
			//Assert.assertEquals(tin7,"510-21-0437");
			
		 
	 }
	 @Then("^I should get modified values as striken out on confirm screen$")
     public void strikenout() throws Throwable{
		    Thread.sleep(4000);
		    String num_after=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div/div/span[2]")).getAttribute("class");
			System.out.println(num_after);
			Assert.assertEquals(num_after," new-text");
			
			String no_after=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div/div/span[2]")).getText();
			System.out.println(no_after);
			Assert.assertEquals(no_after,"(123)453-4534");
			
			String mail=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(mail);
			Assert.assertEquals(mail," new-text");
			
			String email=driver.findElement(By.xpath("//*[@id='front-nulledit-confirm-after']/div[2]/div/span[2]")).getText();
			System.out.println(email);
			Assert.assertEquals(email,"a@gmail.com");
			
			String num_before=driver.findElement(By.xpath("//*[@id='front-74660270collapsible']/div/div/span[2]")).getAttribute("class");
			System.out.println(num_before);
			Assert.assertEquals(num_before,"missing-data-style changed-text ");
			
			String num_before1=driver.findElement(By.xpath("//*[@id='front-74660270collapsible']/div/div/span[2]")).getText();
			System.out.println(num_before1);
			Assert.assertEquals(num_before1,"Missing");
			
			String mail_before=driver.findElement(By.xpath("//*[@id='front-74660270collapsible']/div[2]/div/span[2]")).getAttribute("class");
			System.out.println(mail_before);
			Assert.assertEquals(mail_before,"missing-data-style changed-text ");
			
			String mail_before1=driver.findElement(By.xpath("//*[@id='front-74660270collapsible']/div[2]/div/span[2]")).getText();
			System.out.println(mail_before1);
			Assert.assertEquals(mail_before1,"Missing");
	 }
	 @After
		  public void embedScreenshot(Scenario scenario) {
		          
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	       
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        
	        
	        else if(!scenario.isFailed())
	        
	            {
	        	
	        	driver.quit();
	        	
	        	}
	        
	        }
	        
	       }
   


