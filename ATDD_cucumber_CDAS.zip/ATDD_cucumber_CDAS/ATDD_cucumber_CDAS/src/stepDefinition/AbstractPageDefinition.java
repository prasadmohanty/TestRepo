package stepDefinition;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class AbstractPageDefinition {
	
	protected static WebDriver driver;
	protected WebDriver getDriver(String browser)
	{
		if(driver==null){
			//for invoking IE browser
			    System.out.println("Called openBrowser");
		    	System.setProperty("webdriver.ie.driver", "C://BRANCHES/IEDriverServer.exe");
		        DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();

		        ieCapabilities.setCapability("ignoreProtectedModeSettings", true);
		        ieCapabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                ieCapabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		        ieCapabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		        ieCapabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, false);

		        driver = new InternetExplorerDriver(ieCapabilities);
		        
		   // for invoking chrome browser when developer mode enabled extension pop up is there   
			   System.out.println("Called openBrowser");
		       ChromeOptions options = new ChromeOptions();
		       options.addArguments("chrome.switches","--disable-extensions");
		       System.setProperty("webdriver.chrome.driver","C://BRANCHES/chromedriver.exe");
		       driver = new ChromeDriver(options);
			
		
		   // for invoking chrome browser
			  /*System.out.println("Called openBrowser");
		        System.setProperty("webdriver.chrome.driver", "C://BRANCHES/chromedriver.exe");
		        driver = new ChromeDriver();*/
			}
			
	   return driver;
	}

}
