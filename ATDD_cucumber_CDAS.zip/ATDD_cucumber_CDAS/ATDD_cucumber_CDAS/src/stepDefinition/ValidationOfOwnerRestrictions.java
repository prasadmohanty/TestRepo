package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class ValidationOfOwnerRestrictions extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	 /*@Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  
        }*/
	
	 
	 @Then("^I should get owner restriction on confirmation page$")
		   public void change_name_dob_tin() throws Throwable{
		    Thread.sleep(3000);
		    String alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alert);
			 if(alert.equals("ALERT: POLICY D000501 HAS A REFER TO HOME OFFC RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	    	   System.out.println("First test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY 10111393 HAS A TRUST MINR RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	    	   System.out.println("second test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY D996616 HAS A DIVORCE-SEPARATED RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
		           System.out.println("Third test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY 10796919 HAS A MULTIPLE RSTR RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Fourth test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY D1058763 HAS A DIVORCE RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Fifth test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY 10266985 HAS A SEPARATION RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Sixth test cases is Passed");
	         }
	    else if(alert.equals("ALERT: POLICY 10038892 HAS A POSSIBLE FORGERY RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Seventh test cases is Passed");
	         }
	    
	    else if(alert.equals("ALERT: POLICY D1089421 HAS A SEE FILE MEMO RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	        {
	      System.out.println("8th test cases is Passed");
	        }		 
			 
	    else
	         {
	    	driver.findElement(By.xpath("//*[@id='kalu']/span[31]")).click();
	         }
		
	 }
	 @Then("^I should get owner restrictions alert on confirmation page$")
	   public void owner_restriction() throws Throwable{
		 Thread.sleep(3000);
		    
		    String alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alert);
		
		
		 if(alert.equals("ALERT: POLICY 10001188 HAS A MINOR RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("First test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D092021 HAS A REFER TO HOME OFFC RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
		       System.out.println("Second test cases is Passed");
		     }
		 else if(alert.equals("ALERT: POLICY 10052611 HAS A OWNER DESCD-ESTATE RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Third test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D1023570 HAS A RESTRNG ORDER-B&T RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Fourth test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D1125070 HAS A RSTRNG ORD-LAW DPT RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Fisth test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D086491 HAS A CAUTION-LAW DPT RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Sixth test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D1127189 HAS A PASSWORD PROTECTED RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
	         {
	           System.out.println("Seventh test cases is Passed");
	         }
		 else if(alert.equals("ALERT: POLICY D017973 HAS A CRSPND - TITLE RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("Eighth test cases is Passed");
		    }		 
		 else if(alert.equals("ALERT: POLICY D207140 HAS A CRSPND - MISC RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("9th test cases is Passed");
		    }		 
		 else if(alert.equals("ALERT: POLICY D062957 HAS A ALERT-GIVE NO INFO RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("10th test cases is Passed");
		    }	
		 else if(alert.equals("ALERT: POLICY D142325 HAS A INSD INCOMPETENT RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("11th test cases is Passed");
		    }	
		 else if(alert.equals("ALERT: POLICY 10000369 HAS A MULTIPLE INFO RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("12th test cases is Passed");
		    }
		 else if(alert.equals("ALERT: POLICY 10079151 HAS A DECEASED RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED."))
		    {
		      System.out.println("13th test cases is Passed");
		    }
		 else
	        {
			 driver.findElement(By.xpath("//*[@id='kalqa']/span[31]")).click();
	        }
	 }
	 @Then("^I should get owner restriction alert at the impacted products section on confirmation page$")
	 public void owner_restrictions() throws Throwable{
		    String alrt=driver.findElement(By.xpath("//div[@class='edit-confirm-restrictions']/div/div[3]/span[2]")).getText();
			System.out.println(alrt);
			Assert.assertEquals(alrt,"ALERT: REVIEW ALERTS FOR IMPACTED PRODUCTS BELOW.");
		  
		    String alrt1=driver.findElement(By.xpath("//div[@class='bottom']/div/div/div/div[3]/div/div[2]/div/img")).getAttribute("data-content");
			System.out.println(alrt1);
			Assert.assertEquals(alrt1,"<div class='alert-div'>POLICY 10003475 HAS A TRUST MINR         RESTRICTION. REVIEW POLICY AND DETERMINE IF REQUEST SHOULD BE PROCESSED.</div>");
			
	 }
	 @And("^click on next$")
	 public void next() throws Throwable{
		 driver.findElement(By.xpath("//button[@id='btnSave']")).click();
	 }
	 
	 @After
	  public void embedScreenshot(Scenario scenario) {
	          
       if(scenario.isFailed()) {
       try {
       	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
           byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
           scenario.embed(screenshot, "image/png");
           driver.quit();
      
       } catch (WebDriverException somePlatformsDontSupportScreenshots) {
           System.err.println(somePlatformsDontSupportScreenshots.getMessage());
       	
       }
       }
       
       
       else if(!scenario.isFailed())
       
           {
       	
       	driver.quit();
       	
       	}
       
       }
       
      }




