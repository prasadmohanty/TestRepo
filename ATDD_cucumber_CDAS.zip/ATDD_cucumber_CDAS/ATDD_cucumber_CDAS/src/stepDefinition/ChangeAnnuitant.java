package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangeAnnuitant extends AbstractPageDefinition {
	
	WebDriver driver = getDriver(null);
	
	
	
	 @When("^I click on Annuitant radio button$")
		public void i_click_on_Annuitantradio_button() throws Throwable{
			Thread.sleep(8000);
			driver.findElement(By.xpath("//*[@class='role-bottom-line role-row-highlight']/label[text()='Annuitant']")).click();
			driver.findElement(By.xpath("//*[@id='role-action-change-21']")).click();
	 }
	
	 @Then("^I should land on change annuitant continued page and select NO$")
		public void i_should_land_on_change_annuitant_continued_page_and_select_NO() throws Throwable{
		    Thread.sleep(6000);
			driver.findElement(By.xpath("//*[@class='col-lg-6 col-md-6 col-sm-6 col-xs-6']/label[text()='No']")).click();
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 @Then("^I should land on change annuitant continued page and select Yes$")
		public void i_should_land_on_change_annuitant_continued_page_and_select_yes() throws Throwable{
		    Thread.sleep(6000);
			driver.findElement(By.xpath("//*[@class='col-lg-6 col-md-6 col-sm-6 col-xs-6']/label[text()='Yes']")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='ownerEffectiveDate']")).click();
			driver.findElement(By.xpath("//*[@id='ownerEffectiveDate']")).sendKeys("02 03 2014");
			driver.findElement(By.xpath("//*[@id='btnNext']")).click();
	 }
	 
	 @And("^I get redirected to change annuitant confirmation page$")
		public void i_get_redirected_to_change_annuitant_confirmation_page() throws Throwable{
		    Thread.sleep(5000);
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText().contains("Confirm Annuitant Change"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText().contains("Impacted Product Number(s):"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='label-description']")).getText().contains("Product Number"));
	 }
	 @Then("^I should get redirected to change annuitant confirmation page$")
		public void i_get_redirected_to_change_annuitant_confirmation_Page() throws Throwable{
		    Thread.sleep(5000);
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText().contains("Confirm Annuitant Change"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText().contains("Impacted Product Number(s):"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='label-description']")).getText().contains("Product Number"));
	 }
	 
	 @Then("^I should find the Annnuitant button disabled$")
		public void i_should_find_the_Annnuitant_button_disabled() throws Throwable{
		 Thread.sleep(5000);
		 boolean radio_button=driver.findElement(By.xpath("//*[@id='main-card-undefined']/div[6]/div/div/div/div/div/div/input")).isEnabled();
			System.out.println(radio_button);
			Assert.assertEquals(radio_button,false);
	 }
	 @And("^I get redirected to confirm annuitant change page$")
		public void i_get_redirected_to_confirm_annuitant_change_page() throws Throwable{
		    Thread.sleep(5000);
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText().contains("Confirm Annuitant Change"));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText().contains("Impacted Product Number(s):"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='label-description']")).getText().contains("RELATED INFORMATION FOR OWNER"));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-0']/div/div/span[text()='Change Annuitant  From']")).getText().contains("Change Annuitant  From"));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-0']/div/div/span[text()='Change Owner, Payer  From']")).getText().contains("Change Owner, Payer  From"));
			//Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div/div/span[text()='Change Annuitant, Owner, Payer To']")).getText().contains("Change Annuitant, Owner, Payer To"));
			Assert.assertTrue(driver.findElement(By.xpath("//*[@class='impacted-policies-label pad15']/span")).getText().contains("Product Number"));
	 }
	  
	 @And("^Click on the first card$")
	 public void Click_on_the_first_card() throws Throwable{
	    	Thread.sleep(10000);
	    	if(driver.findElement(By
					.xpath(".//*[@id='main-card-2']/div[4]/div/div/div/div/div/label")) !=null){
				System.out.println("radio button exits");
				WebElement radioLabel = driver.findElement(By
						.xpath(".//*[@id='main-card-2']/div[4]/div/div/div/div/div/label"));
				System.out.println(radioLabel.getText());
				radioLabel.click(); 
			}
	    	Thread.sleep(5000);
	    	driver.findElement(By.xpath("//*[@id='btnChangeNext']")).click();
	 }
	 
	 @And("^Click on the other card$")
	 public void Click_on_the_other_card() throws Throwable{
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id='card-radio-0']/label[text()='Make other Client Annuitant']")).click();
		 driver.findElement(By.xpath("//*[@id='btnChangeNext']")).click();
	 }
	 
	 @And("^Use existing client as new Annuitant$")
	 public void Use_existing_client_as_new_Annuitant() throws Throwable{
		 driver.findElement(By.xpath("//*[@id='search']")).sendKeys("david ingbar");
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			driver.findElement(By.xpath("//*[@id='results']/div[4]/div[2]/div/div[3]/div/div/div/div/button")).click();
	 }
	 @And("^Use New client as new Annuitant$")
	    public void Use_New_client_as_new_Annuitant() throws Throwable{
	    	
	    	driver.findElement(By.xpath("//*[@id='search']")).sendKeys("ashutosh panigrahi");
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-1']/div[2]")).click();
			Thread.sleep(5000);
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			driver.findElement(By.xpath(".//*[@id='dateofbirth']")).click();
			driver.findElement(By.xpath(".//*[@id='dateofbirth']")).sendKeys("01 01 1989");
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("311 Hillcrest Dr");
			driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Lower Burrell");
			Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
		    sc.selectByVisibleText("PA - Pennsylvania");
			driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("15068");
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
	 }
	 
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
