package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;


public class Unchaining extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
		 WebDriver driver = getDriver(null);
       }*/
	
	 
	 @And("^click on split client option$")
	 public void split() throws Throwable {
		  Thread.sleep(4000);
		  driver.findElement(By.xpath("//*[@id='unchain']")).click();  
		 
	 }
	 @And("^click next after selecting first radio button$")
	 public void radio_next() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@class='col-lg-1 col-md-1 col-sm-1 col-xs-1 card-check-box ']/label")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
		 
	 }
	 @And("^click next after selecting product radio button$")
	 public void radio_product_next() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='back-1974415']/div[3]/div/label")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
		 
	 }
	 @And("^click next after selecting aprropriate product radio button$")
	 public void button_next() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='back-8259782']/div[3]/div/label")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
	 }
	 @And("^click next after selecting correct product radio button$")
	 public void radio_button_next() throws Throwable {
		    Thread.sleep(4000);
		    driver.findElement(By.xpath("//*[@id='main-card-0']/div[2]/div/div/div[2]/div[3]/div/label")).click();
			driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).click();
	 } 
	 @And("^policy related warning$")
	 public void plocy_warning() throws Throwable {
		    Thread.sleep(2000);
	        String Warning=driver.findElement(By.xpath("//*[@class='alert alert-danger fade in alert-styleclass alert-error ']/span[2]")).getText();
		    System.out.println(Warning);
		    Assert.assertEquals(Warning,"WARNING: PAYER AND INSURED ARE NOT SAME FOR THIS NON-ISA EP POLICY 10219868");
		    System.out.println("test case1 Passed");
		    String Alert=driver.findElement(By.xpath("//*[@class='alert alert-warning fade in alert-styleclass alert-warning ']/span[2]")).getText();
			System.out.println(Alert);
			Assert.assertEquals(Alert,"ALERT: CLIENT BIRTHDATE NO LONGER MATCHES THE CONTRACT BIRTHDATE AND A CASE WILL BE CREATED TO CORRECT THE CONTRACT, AS THIS RESULTS IN AN AGE CHANGE.");
			System.out.println("test case3 Passed");
     }
	  
	 @Then("^I should find the next button as disabled$")
	 public void next_disable() throws Throwable {
		    Thread.sleep(4000);
		    boolean next=driver.findElement(By.xpath("//*[@class='fly-actions-link']/button[text()='Next']")).isEnabled();
			System.out.println(next);
			Assert.assertEquals(next,false);
			
	 }
	 @Then("^I should get policy freeze alert$")
	 public void i_should_get_policyfreeze_alert() throws Throwable {
		    String Alert=driver.findElement(By.xpath("//*[@id='card-container-top']/div[2]/div/span[2]")).getText();
			System.out.println(Alert);
			/*Assert.assertEquals(Alert,"ALERT: POLICY 10953513 CURRENTLY HAS A POLICY FREEZE OF K, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.");
			System.out.println("test case Passed");*/
			if (Alert.equals("ALERT: POLICY 10953513 CURRENTLY HAS A POLICY FREEZE OF K, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")) {
				System.out.println("Test case passed");

			} else if (Alert.equals("ALERT: POLICY 8899036 CURRENTLY HAS A POLICY FREEZE OF M, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")) {
				System.out.println("Test case passedd");

			} else if (Alert.equals("ALERT: POLICY 10662190 CURRENTLY HAS A POLICY FREEZE OF T, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.")){
				System.out.println("Test case passsedd");
			} 
			else
			{
				(driver.findElement(By.xpath("//*[@class='acq']/label"))).click();
			}
	 }
	 @Then("^I should get policy freeze alerts$")
	 public void i_should_get_policyfreeze_alerts() throws Throwable {
		 String Alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(Alert);
			/*Assert.assertEquals(Alert,"ALERT: POLICY 10953513 CURRENTLY HAS A POLICY FREEZE OF K, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.");
			System.out.println("test case Passed");*/
			if (Alert.equals("WARNING: POLICY 10245288 CURRENTLY HAS A POLICY FREEZE OF Q, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.")) {
				System.out.println("Test case passed");

			} else if (Alert.equals("WARNING: POLICY D1531635 CURRENTLY HAS A POLICY FREEZE OF X, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.")) {
				System.out.println("Test case passedd");

			} else if (Alert.equals("WARNING: POLICY 19651415 CURRENTLY HAS A POLICY FREEZE OF W, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.")) {
				System.out.println("Test case passedd");
				}
			
			else(driver.findElement(By.xpath("//*[@class='abc']/label"))).click();
	 }
	 @Then("^I should get policy freeze N warning$")
	 public void i_should_get_policyfreeze_N_warning() throws Throwable {
		    String Alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(Alert);
			Assert.assertEquals(Alert,"WARNING: POLICY D016322 CURRENTLY HAS A POLICY FREEZE OF N, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.");
			System.out.println("test case Passed");
	 }
	 
	 @Then("^I should get birthday related alert$")
	 public void i_should_get_birthday_warning() throws Throwable {
		    String Alert_birthday=driver.findElement(By.xpath("//*[@class='chain-alert-div']/div/div/span[2]")).getText();
			System.out.println(Alert_birthday);
			Assert.assertEquals(Alert_birthday,"ALERT: INSURED BIRTHDATE 1982-07-04 IS DIFFERENT FROM CLIENT BIRTHDATE 1943-02-27. VERIFY THE BIRTHDATE WAS ENTERED CORRECTLY. SINCE THERE IS NO AGE CHANGE, BIRTHDATE ON POLICY RECORD WOULD BE UPDATED.");
			System.out.println("test case Passed");
	 }
	 @Then("^I should get unchaining related Warning$")
	 public void i_should_get_policy_warning() throws Throwable {
		    String warning=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(warning);
			if (warning.equals("WARNING: CLIENT RECORD DOES NOT HAVE INSURED/ANNUITANT ROLE ON ANY INFORCE/TERMINATED POLICY. CANNOT BE UNCHAINED.")) {
				System.out.println("Second case passed");

			} else if (warning.equals("WARNING: CLIENT RECORD IS RELATED TO GROUP PENSION/VARIABLE ANNUITY, CANNOT BE UNCHAINED.")) {
				System.out.println("First case passed");

			} else
				{
				(driver.findElement(By.xpath("//*[@class='abc']/label"))).click();
				}
			
		
	 }
	  @Then("^I should get policy freeze R alert$")
	 public void i_should_get_policyfreeze_R_warning() throws Throwable {
		 String Alert=driver.findElement(By.xpath("//*[@id='card-container-top']/div[2]/div/span[2]")).getText();
			System.out.println(Alert);
			Assert.assertEquals(Alert,"ALERT: POLICY 10580499 CURRENTLY HAS A POLICY FREEZE OF R, REVIEW POLICY AND DETERMINE IF ADDITIONAL ACTION IS NEEDED.");
			System.out.println("test case Passed");
	 }
	 @Then("^I should get policy freeze O/S warning$")
	 public void i_should_get_policyfreeze_O_warning() throws Throwable {
		 String Alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(Alert);
			/*Assert.assertEquals(Alert,"WARNING: POLICY D1892909 CURRENTLY HAS A POLICY FREEZE OF O, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.");
			System.out.println("test case Passed");*/
			if (Alert.equals("WARNING: POLICY D1892909 CURRENTLY HAS A POLICY FREEZE OF O, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.")) {
				System.out.println("Test case passed");

			} else if (Alert.equals("WARNING: POLICY 14919704 CURRENTLY HAS A POLICY FREEZE OF S, REVIEW CASE NOTES AND CONTACT FREEZE OWNER BEFORE PROCEEDING. THE TRANSACTION WILL NOT BE PROCESSED FOR THIS POLICY.")) {
				System.out.println("Test case passedd");

			} 
			else(driver.findElement(By.xpath("//*[@class='abc ']/label"))).click();
			
	 }
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
