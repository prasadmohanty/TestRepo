package stepDefinition;


import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChangeSecondaryAddressee extends AbstractPageDefinition {
	 WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	 
       }*/
	
	 
	 @When("^I click on change secondary addressee radio button$")
		public void i_click_on_change_secondary_addressee_radio_button() throws Throwable{
			Thread.sleep(10000);
			driver.findElement(By.xpath("//*[@class='role-bottom-line role-row-highlight']/label[text()='Secondary Addressee']")).click();
			driver.findElement(By.xpath("//*[@id='role-action-change-160']")).click();
		  }
	 
	 @Then("^I should land on change sec addressee confirmation page$")
	    public void i_should_land_on_change_sec_addressee_confirmation_page() throws Throwable{
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='center-float']/h1")).getText().contains("Confirm Secondary Addressee Change"));
		 //Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-0']/div/div/span")).getText().contains("Change Secondary Addressee  From"));
		 //Assert.assertTrue(driver.findElement(By.xpath("//*[@id='main-card-1']/div/div/span")).getText().contains("Change Secondary Addressee To"));
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='screen-title no-padding']")).getText().contains("Impacted Product Number(s):"));
		 Assert.assertTrue(driver.findElement(By.xpath("//*[@class='label-description']")).getText().contains("Product Number"));
	 }
	 
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
