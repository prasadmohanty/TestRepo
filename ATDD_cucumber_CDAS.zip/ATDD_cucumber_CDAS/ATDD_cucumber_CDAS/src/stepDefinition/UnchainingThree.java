

package stepDefinition;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class UnchainingThree extends AbstractPageDefinition {
	WebDriver driver = getDriver(null);
	
	
	/* @Before
	  public void i_am_on_CDAS_landing_screen() throws Throwable{
	  WebDriver driver = getDriver(null);
       }*/
	
	
	 @And("^give details of new client$")
	 public void new_client_details() throws Throwable{
		    Thread.sleep(4000);
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).click();
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).sendKeys("11 12 1992");
			
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("311 Hillcrest Dr ");
		    driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Lower Burrell");
		    
		    Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
		    sc.selectByVisibleText("PA - Pennsylvania");
		    
		    driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("15068");
		    Thread.sleep(5000);
		    driver.findElement(By.xpath("//*[@id='btnSave']")).click();
		    System.out.println("clicked on next button");
		    
	 }
	 @When("^I search for \"([^\"]*)\" and click on second card$")
			 public void i_search_for(String arg1) throws Throwable {
		    driver.findElement(By.xpath("//*[@id='search']")).sendKeys(arg1);
	    	driver.findElement(By.xpath("//*[@id='submit']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-2']/div[2]")).click();
			driver.findElement(By.xpath("//*[@id='card-action']/div/div/button")).click();
		 
	 }
	 
	
	 @And("^I click on other card$")
	 public void other_card() throws Throwable {
		 Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='card-6']/div[2]/div/h4[text()=' Add a new Client to the system']")).click();
	 }
	 
	 @And("^provide client details$")
	 public void other_client_details() throws Throwable {
		 Thread.sleep(5000);
		    String alert=driver.findElement(By.xpath("//*[@id='dvAlrt']/span[2]")).getText();
			System.out.println(alert);
			Assert.assertEquals(alert,"INFORMATION: Client must be a Person. Client cannot be a Business or Trust for unchaining with new Client.");
			Select gn= new Select(driver.findElement(By.xpath(".//*[@id='ddlgender']")));
			gn.selectByVisibleText("Male");
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).click();
			driver.findElement(By.xpath("//*[@id='dateofbirth']")).sendKeys("11 12 1992");
			System.out.println("date printed");
			/*driver.findElement(By.id("tincorporatetab")).click();
			Thread.sleep(5000);
			driver.findElement(By.id("taxpayerid")).click();
			driver.findElement(By.id("taxpayerid")).sendKeys("12 111111");
			System.out.println("tax printed");
			Select s=new Select(driver.findElement(By.id("certificationform")));
			s.selectByVisibleText("W-9: Backup Withholding");
			System.out.println("cert selected");
			driver.findElement(By.id("tinpersontab")).click();
			System.out.println("tin person printed");
			Thread.sleep(5000);*/
			//validation of Non-usa country tab
			driver.findElement(By.id("countrynonusatab")).click();
			Thread.sleep(5000);
			driver.findElement(By.id("pobox")).sendKeys("Info Bhubaneswar");
			Select country=new Select(driver.findElement(By.id("country")));
			country.selectByVisibleText("India");
			//validation of Non-usa phone tab
			driver.findElement(By.id("phonenonusatab")).click();
			Thread.sleep(5000);
			driver.findElement(By.id("foreignnumber")).sendKeys("12233");
			driver.findElement(By.id("email")).sendKeys("abinash@gmail.com");
			driver.findElement(By.id("phoneusatab")).click();
			//validation of USA country tab for pop-up
			driver.findElement(By.id("countryusatab")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='taxpayerid']")).sendKeys("454 44 6448");
			System.out.println("pin printed");
			driver.findElement(By.id("pobox")).sendKeys(Keys.HOME,Keys.chord(Keys.SHIFT,Keys.END));
			driver.findElement(By.xpath("//*[@id='pobox']")).sendKeys("311 Hillcrest Dr ");
			System.out.println("po printed");
		    driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Lower Burrell");
		    System.out.println("city printed");
		    Select sc= new Select(driver.findElement(By.xpath(".//*[@id='state']")));
		    sc.selectByVisibleText("PA - Pennsylvania");
		    System.out.println("state selected");
		    
		    driver.findElement(By.xpath("//*[@id='zip']")).sendKeys("15068");
		    System.out.println("zip printed");
		    Thread.sleep(5000);
		    driver.findElement(By.xpath("//*[@id='btnSave']")).click();
		    System.out.println("clicked on next button");
	 }
	 @Then("^I should land on confirm split page$")
	 public void confirmation_page() throws Throwable {
		    Thread.sleep(5000);
		    String heading=driver.findElement(By.xpath("//div[@class='confirm-hd']/h1")).getText();
			System.out.println(heading);
			Assert.assertEquals(heading,"Confirm Split Insured");
			
			
			String subheading=driver.findElement(By.xpath("//div[@class='confirm-subhd']/h2")).getText();
			System.out.println(subheading);
			Assert.assertEquals(subheading,"Resulting Records and Impacting products");
			
			String title=driver.findElement(By.xpath("//div[@id='card-container-top']/span")).getText();
			System.out.println(title);
			Assert.assertEquals(title,"Split This Client's Insured Record");
			
			String titleBottom=driver.findElement(By.xpath("//div[@id='card-container-bottom']/span")).getText();
			System.out.println(titleBottom);
			Assert.assertEquals(titleBottom,"Make This Client the Insured");
			
			String action=driver.findElement(By.xpath("//span[@class='hidden-xs hidden-sm hidden-md']")).getText();
			System.out.println(action);
			Assert.assertEquals(action,"Highlighted Record(s) will be split");
			
			boolean submit=driver.findElement(By.xpath("//button[@class='btn btn-secondary btn-action ']")).isEnabled();
			System.out.println(submit);
			Assert.assertEquals(submit,true);
			System.out.println("test case is Passed");
	 }
	 @After
		public void embedScreenshot(Scenario scenario) {
		       
	        if(scenario.isFailed()) {
	        try {
	        	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	            byte[] screenshot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshot, "image/png");
	            driver.quit();
	        } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	            System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	        	
	        }
	        }
	        else if(!scenario.isFailed())
	            
	        {
	    	
	    	driver.quit();
	    	
	    	}
	    
	    }
	    
	   }
