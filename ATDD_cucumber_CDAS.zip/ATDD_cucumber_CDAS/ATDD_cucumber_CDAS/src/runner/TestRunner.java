package runner;


import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="D:/ATDD_cucumber_CDAS/ATDD_cucumber_CDAS/features/crm.feature",
		glue={"/ATDD_Cucumber_CDAS/src/stepDefinition/crm.java"},
		plugin={"pretty","html:target/cucumber-html-report","json:target/json"}
		
		)
public class TestRunner {
	
	
    }
	
	

