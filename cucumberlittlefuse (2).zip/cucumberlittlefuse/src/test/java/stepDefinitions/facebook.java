package stepDefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver; 

import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;


public class facebook { 
   WebDriver driver = null; 
   @Given("^I am on Facebook login page$") 
	
   public void goToFacebook() { 
	   System.setProperty("webdriver.chrome.driver","C://Users//Shrish//Downloads//chromedriver.exe");
	   driver = new ChromeDriver();
      //driver = new FirefoxDriver(); 
      driver.navigate().to("https://www.facebook.com/"); 
   }
	
   @When("^I enter username as \"(.*)\"$") 
   public void enterUsername(String arg1) {   
      driver.findElement(By.id("email")).sendKeys(arg1); 
   }
	
   @When ("^I enter password as \"(.*)\"$") 
   public void enterPassword(String arg1) {
      driver.findElement(By.id("pass")).sendKeys(arg1);
      driver.findElement(By.id("u_0_v")).click(); 
   } 
	
   @Then("^Login should successful$") 
   public void checksuccessful() throws InterruptedException { 
	  // WebElement loginBtn =
//				 driver.findElement(By.xpath("//input[@type='submit']"));
//				 JavascriptExecutor js = (JavascriptExecutor)driver;
//				 js.executeScript("arguments[0].click();", loginBtn);
//				 }
	   Thread.sleep(3000);
	   driver.findElement(By.xpath(".//input[@type='submit']]")).click();
	  // WebElement LogInBtn = driver.findElement(By.xpath(".//input[@type='submit']]")).click();
	   //JavascriptExecutor js = (JavascriptExecutor)driver;	
		//js.executeScript("arguments[0].click();", LogInBtn);
   }
     
     @Then("^Relogin option should be available$")
     public void relogin_option_should_be_available() throws Throwable {
    	 Assert.assertEquals("Login should be successful","Login");
     }
      
   
}
    
   
   








