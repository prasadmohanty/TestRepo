package runner;

import org.junit.runner.RunWith;
import java.io.*;
import org.junit.AfterClass;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import com.cucumber.listener.Reporter;
import managers.FileReaderManager;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature/Makemytrip.feature",
		glue= {"stepDefinitions"},
		//plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"},
				plugin ={"com.cucumber.listener.ExtentCucumberFormatter:C:\\Users\\Shrish\\eclipse-workspace\\cucumberlittlefuse\\Reports\\cucumber-extent\\report.html"},
		 
		 tags = {"@makemytrip-signin,@makemytrip-footerValidationAUTH,@makemytrip-footerValidation"}
		 ,monochrome = true
		)

public class testrunner {
	
	@AfterClass
    public static void reportSetup() 
 	{
        Reporter.loadXMLConfig(new File("/Users/Shrish/eclipse-workspace/cucumberlittlefuse/extent-config.xml"));
        /*Properties p = System.getProperties();
        p.list(System.out);*/
        
        Reporter.setSystemInfo("User Name",System.getProperty("user.name"));
        Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
        Reporter.setSystemInfo("64 Bit", 	"Windows 7");
        Reporter.setSystemInfo("2.53.0", "Selenium");
        Reporter.setSystemInfo("3.3.9", "Maven");
        Reporter.setSystemInfo("1.8.0_66", "Java Version");
        Reporter.setTestRunnerOutput("Cucumber JUnit Test Runner");
 	}

	
	 }
	
