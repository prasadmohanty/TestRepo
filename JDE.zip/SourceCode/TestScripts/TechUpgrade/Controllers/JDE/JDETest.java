package TestScripts.TechUpgrade.Controllers.JDE;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Controllers.JDE.JDEHomePage;
import Pages.Controllers.JDE.JDELoginPage;
import SupportLibraries.BaseTest;
import SupportLibraries.ListenerClass;

public class JDETest extends BaseTest{
	
	@BeforeClass
	public void intialize()
	{
		jdeLoginpage   		=   new JDELoginPage(driverScript.getBaseTest().getScriptHelper());	
		jdeHomepage			=	new JDEHomePage(driverScript.getBaseTest().getScriptHelper());
	}
	

	/** 
	 * TC_01
	 * Method to launch the JDE application
	 */
	@Test
	public void launchApplication() {
		try {
		
			jdeLoginpage.getApplication();
					
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/** 
	 * TC_01
	 * Method to login into JDE application
	 */
	@Test
	public void loginIntoApplication() {
		try {
		
			jdeLoginpage.typeUserName("dataset1").typePassword("dataset1").clicksignonButton();
			Assert.assertTrue(jdeLoginpage.getPageMainTitle().contains("JD Edwards"), "JDE homepage is not loaded properly");
			
		}
	catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * * TC_01
	 * Method to validate the Open Application side menu 
	 */
	
	@Test
	public void validateOpenAppl() {
		try {
		
			jdeHomepage.clickOpenApplication();
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_01
	 * Method to validate the Recent Reports side menu 
	 */
	
	@Test
	public void validateRecentReports() {
		try {
		
			jdeHomepage.clickRecentReports();
						
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_01
	 * Method to validate the Manage Favorites side menu 
	 */
	
	@Test
	public void validateManageFavorites() {
		try {
					
			jdeHomepage.clickFav();
			
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_02
	 * Method for passing the values in Fast Path 
	 */
	
	@Test
	public void passingFastPathValue() {
		try {
		
			jdeHomepage.clickFavClose();
			jdeHomepage.typeFastPath("dataset2");
						
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_02
	 * Method to pass the batch application values and select the appropriate report from 
	 * the result set
	 */
	@Test
	public void passingBatchApplicationValue() {
		try {
		
			jdeHomepage.typeBatchAppl("dataset3");
			jdeHomepage.selectReport();
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/**
	 * TC_02
	 * Method to validate Row option 
	 */
	
	@Test
	public void validateRowOption() {
		try {
		
			jdeHomepage.clickRow();
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/*
	 * TC_02
	 * Method to validate Form option
	 */
	
	@Test
	public void validateFormOption() {
		try {
		
			jdeHomepage.clickForm();
								
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/*TC_02
	 * Method to validate Tools option
	 */
	
	
	@Test
	public void validateTools() {
		try {
		
			jdeHomepage.clickTools();
								
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
	/*
	 * TC_02
	 * Method to validate close option
	 */
	@Test
	public void validateCloseOption() {
		try {
		
			jdeHomepage.clickclose();
						
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}

	/*
	 * Method to sign out from application
	 */
	@Test
	public void signOut() {
		try {
		
			jdeHomepage.signOut();
						
		}
		catch(Throwable t){
			ListenerClass.setErrorMessage(t.getMessage());
			Assert.fail(t.getMessage());
		}
	}
	
}
