package SupportLibraries;

import org.openqa.selenium.WebDriver;




/**
 * Wrapper class for common framework objects, to be used across the entire test case and dependent libraries
 * @author Cognizant
 */
public class ScriptHelper
{
	
	
	private final WebDriver driver;
	
	/**
	 * Constructor to initialize all the objects wrapped by the {@link ScriptHelper} class
	 * @param dataTable The {@link CraftliteDataTable} object
	 * @param report The {@link SeleniumReport} object
	 * @param driver The {@link WebDriver} object
	 */
	public ScriptHelper( WebDriver driver)
	{
		
		
		this.driver = driver;
	}
	
	/**
	 * Function to get the {@link CraftliteDataTable} object
	 * @return The {@link CraftliteDataTable} object
	 */
	
	
	
	/**
	 * Function to get the {@link WebDriver} object
	 * @return The {@link WebDriver} object
	 */
	public WebDriver getDriver()
	{
		return driver;
	}
}