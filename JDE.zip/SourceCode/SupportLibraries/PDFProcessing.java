package SupportLibraries;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

import Pages.Common.MasterPage;

public class PDFProcessing extends MasterPage {

	public PDFProcessing(ScriptHelper scriptHelper) {
		super(scriptHelper);
		// TODO Auto-generated constructor stub
	}

	
	public static boolean validateDisabilityTableHeaderInPdfDocument(String pdfDocumentName,int pageNumber,String policyNumber,String fieldName){
		String searchID=dataLoader.getTestdata("MappingData",policyNumber +currentTestCaseName, "searchID");
		String contextName = dataLoader.getTestdata("TestData", searchID.trim(), "searchTxt");
		String parsedText=getPDFDocumentText(pdfDocumentName,2);
		String HeaderFieldText=parsedText.split("Disability Insurance")[1].split(contextName)[0].trim();
		return HeaderFieldText.contains(fieldName);
		
		
	}
	
   
	private static String getPDFDocumentText(String pdfDocumentName,
			int startPageNumber) {
		PDFTextStripper pdfStripper = null;
		PDDocument pdDoc = null;
		COSDocument cosDoc = null;
		FileInputStream pdfInput = null;
		String parsedText = null;
		try {
			
			pdfInput = new FileInputStream("C:\\Users\\"
					+ System.getProperty("user.name") + "\\Downloads\\"
					+ pdfDocumentName);
			PDFParser parser = new PDFParser(pdfInput);
			parser.parse();
			cosDoc = parser.getDocument();
			pdfStripper = new PDFTextStripper();
			pdDoc = new PDDocument(cosDoc);
			pdfStripper.setStartPage(startPageNumber);
			pdfStripper.setEndPage(startPageNumber);
			parsedText = pdfStripper.getText(pdDoc);

		} catch (IOException e) {

		} finally {
			pdfStripper = null;
			if(pdDoc!=null)
				try {
					pdDoc .close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			cosDoc = null;
			if (pdfInput != null)
				try {
					pdfInput.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
		}

		return parsedText;

	}

	
	
	

}
