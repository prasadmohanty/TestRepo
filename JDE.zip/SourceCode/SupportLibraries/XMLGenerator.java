package SupportLibraries;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLGenerator {
	
	public static void main(String [] args) throws ParserConfigurationException, TransformerException
	{
		DocumentBuilderFactory documentbuilderfactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentbuilder = documentbuilderfactory.newDocumentBuilder();
		
		Document document =  documentbuilder.newDocument();
		
		Element rootElement = document.createElement("suite");
		
		
		Attr attribute  = document.createAttribute("name");
		attribute.setValue("AllSuitesBatch");
		rootElement.setAttributeNode(attribute);
		
		document.appendChild(rootElement);
		
		
		Element listeners = document.createElement("listeners");
		rootElement.appendChild(listeners);
		
		Element listener = document.createElement("listener");
		listeners.appendChild(listener);
		
		Attr listenerattribute  = document.createAttribute("class-name");
		listenerattribute.setValue("SupportLibraries.ScreenShotCapture");
		listener.setAttributeNode(listenerattribute);
		
		File directory = new File("./TestNgSuiteFiles");
		
		File [] fileList = directory.listFiles();
		
		for(File file: fileList)
		{
		
		Element suitefile = document.createElement("suite-file");
		rootElement.appendChild(suitefile);
		
		Attr suitefileattribute  = document.createAttribute("path");
		suitefileattribute.setValue("TestNgSuiteFiles\\"+file.getName());
		suitefile.setAttributeNode(suitefileattribute);
		
		}
		
		
		
		TransformerFactory transformerfactory = TransformerFactory.newInstance();
		Transformer transformer = transformerfactory.newTransformer();
		
		DOMSource source = new DOMSource(document);
		
		StreamResult streamresult = new StreamResult("./test.xml");
		
		transformer.setOutputProperty(OutputKeys.INDENT,"yes");
		
		transformer.transform(source, streamresult);
		
			
		System.out.println("xml created");
		
	}

}
