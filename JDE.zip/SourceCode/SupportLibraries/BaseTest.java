package SupportLibraries;


import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import Pages.Common.MasterPage;
import Pages.Controllers.JDE.JDEHomePage;
import Pages.Controllers.JDE.JDELoginPage;


/**
 * Base class for all the test cases to be automated
 * @author Cognizant
 */
public  class BaseTest
{
	
	

		
	public MasterPage masterpage;
			
	// following snippet is for JDE application
	public JDELoginPage jdeLoginpage;
	
	public JDEHomePage jdeHomepage;
	
	
	/**
	 * The {@link SeleniumTestParameters} object to be used to specify the test parameters
	 */
	protected SeleniumTestParameters testParameters;
	
	/**
	 * The {@link DriverScript} object to be used to execute the required test case
	 */
	protected DriverScript driverScript;
	
	
	/**
	 * The {@link WebDriver} object (passed from the Driver script)
	 */
	protected static WebDriver driver;
	
	/**
	 * The {@link ScriptHelper} object (required for calling one reusable library from another)
	 */
	protected ScriptHelper scriptHelper;
	
	
	protected Properties properties;
	
	
	/**
	 * Function to initialize the {@link ScriptHelper} object and in turn the objects wrapped by it,
	 * as well as load the {@link Properties} object using the {@link Settings} object
	 * @param scriptHelper The {@link ScriptHelper} object
	 */
	public void initialize(ScriptHelper scriptHelper)
	{
		this.scriptHelper = scriptHelper;
		this.driver = scriptHelper.getDriver();
		properties = Settings.getInstance();
	}
	
	
	/**
	 * Returns {@link ScriptHelper} object (required for calling one reusable library from another)
	 */
	public ScriptHelper getScriptHelper()
	{
		return scriptHelper;
		
	}
	
	
	/**
	 * Returns {@link WebDriver} object (required for calling one reusable library from another)
	 */
	public static WebDriver getWebDriver()
	{
		return driver;
	}
	
	/**
	 * Returns {@link WebDriver} object (required for calling one reusable library from another)
	 */
	public DriverScript getDriverScript()
	{
		 return new DriverScript(testParameters);
	}
	
	@BeforeSuite
	public void suiteSetup()
	{
		testParameters = new SeleniumTestParameters();
		driverScript=getDriverScript();
		driverScript.driveTestExecution();
		
	}
	
	@AfterSuite
	public void suiteTearDown()
	{
	
		driverScript.getBaseTest().quitWebDriver();
		
	}
	
	public void quitWebDriver()
	{
		driver.close();
		driver.quit();
	}
}