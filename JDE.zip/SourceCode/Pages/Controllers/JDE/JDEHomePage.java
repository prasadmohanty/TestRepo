package Pages.Controllers.JDE;


import org.openqa.selenium.By;
import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;

public class JDEHomePage extends MasterPage{


	By txtFastPath			=	By.id("TE_FAST_PATH_BOX");
	By lnkFastPathSearch	=	By.xpath("//*[@id='e1MFastpathForm']/a/img");
	By txtBatchSearch		=	By.id("C0_11");
	By iconSearch			=	By.id("va0_11");
	By drpdnOpenAppl		=	By.id("listOCLArrow");
	By drpdnRecentReport	=	By.id("listRecRptsArrow");
	By drpdnFavorites		=	By.id("listFavArrow");
	By lnkHome				=	By.xpath("//*[@id='listOCL_0']/table/tbody/tr/td[2]");  
	By btnClose				=	By.id("Cancel");
	By btnRow				=	By.id("ROW_EXIT_BUTTON");
	By btnForm				=	By.id("FORM_EXIT_BUTTON");
	By btnTools				=	By.id("TOOLS_EXIT_BUTTON");
	By btnClose1			=	By.id("hc_Close");
	By lnkJobStatus			=	By.cssSelector("#listRRpt_WSJ td[class='listText']");
	By lnkFavorites			=	By.cssSelector("#listFav_manageFavs td[class='listText']");
	By drpdnRoles			=	By.cssSelector("#Role");
	By btnSign				=	By.xpath("//td[contains(@class,'topmenulabel')]/div/a"); 
	By btnSearch			=	By.id("hc_Find");
	By chkBxReport			=	By.cssSelector("#G0_1_R0 > td.JSSelectGrid > div > input[type='checkbox']");

	public JDEHomePage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		// TODO Auto-generated constructor stub
	}


	/*
	 * Method to type Fast path value
	 */

	public JDEHomePage typeFastPath(String Testcase) throws Exception {
		try {
			getElement(txtFastPath).clear();
			String fastpath = dataLoader.getTestdata("JDETestPurpose", Testcase,"FastPath");
			getElement(lnkFastPathSearch).sendKeys(fastpath.trim());

			isElementDisplayed(lnkFastPathSearch);
			clickUsingJavaScript(getElement(lnkFastPathSearch));
			waitForElementInVisible(By.className("loading-indicator"), 25);

		} catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to type fast path value into the text box");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to type batch application value
	 */
	public JDEHomePage typeBatchAppl(String Testcase) throws Exception {
		try {

			switchToFrame("e1menuAppIframe");
			getElement(txtBatchSearch).clear();
			String batchApp = dataLoader.getTestdata("JDETestPurpose", Testcase,"BatchAppl");
			clickUsingJavaScript(getElement(txtBatchSearch));
			getElement(txtBatchSearch).sendKeys(batchApp.trim());

			isElementDisplayed(btnSearch);
			getElement(btnSearch).click();
			waitTill(1000);

		}
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to type batch application value into the text box");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on report check box
	 */
	public JDEHomePage selectReport() throws Exception
	{
		try {

			isElementDisplayed(chkBxReport);
			clickUsingJavaScript(getElement(chkBxReport));
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on report check box");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on Row icon
	 */
	public JDEHomePage clickRow() throws Exception
	{
		try {

			isElementDisplayed(btnRow);
			clickUsingJavaScript(getElement(btnRow));
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Row icon");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
	/*
	 * Method to click on Form menu icon
	 */
	public JDEHomePage clickForm() throws Exception
	{
		try {

			isElementDisplayed(btnForm);
			clickUsingJavaScript(getElement(btnForm));
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Form menu icon");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on Tools icon
	 */
	public JDEHomePage clickTools() throws Exception
	{
		try {

			isElementDisplayed(btnTools);
			clickUsingJavaScript(getElement(btnTools));
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Tools icon");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on Close icon
	 */
	public JDEHomePage clickclose() throws Exception
	{
		try {
			isElementDisplayed(btnClose1);
			clickUsingJavaScript(getElement(btnClose1));
			waitTill(2000);
			clickUsingJavaScript(getElement(btnClose1));
			waitTill(2000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on close icon to close the task");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on Home option under Open application tab
	 */
	public JDEHomePage clickOpenApplication() throws Exception
	{
		try {

			driver.switchTo().defaultContent();

			isElementDisplayed(drpdnOpenAppl);
			clickUsingJavaScript(getElement(drpdnOpenAppl));
			waitTill(1000);
			clickUsingJavaScript(getElement(drpdnOpenAppl));
			waitTill(1000);
			isElementDisplayed(lnkHome);
			getElement(lnkHome).click();
			waitTill(2000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Home option under Open application tab");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on View-Job status option under Open Recent reports tab
	 */
	public JDEHomePage clickRecentReports() throws Exception
	{
		try {

			isElementDisplayed(drpdnRecentReport);
			clickUsingJavaScript(getElement(drpdnRecentReport));
			waitTill(1000);
			clickUsingJavaScript(getElement(drpdnRecentReport));
			waitTill(1000);
			getElement(lnkJobStatus).click();
			waitTill(2000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on View-Job status option under Open Recent reports tab");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}
	
	/*
	 * Method to click on Favorites option
	 */
	public JDEHomePage clickFav() throws Exception
	{
		try {

			isElementDisplayed(drpdnFavorites);
			clickUsingJavaScript(getElement(drpdnFavorites));
			waitTill(1000);
			clickUsingJavaScript(getElement(drpdnFavorites));
			waitTill(1000);
			getElement(lnkFavorites).click();
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Favorites option");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	/*
	 * Method to click on close button
	 */
	public JDEHomePage clickFavClose() throws Exception
	{
		try {

			isElementDisplayed(btnClose);
			getElement(btnClose).click();
			waitTill(1000);
		} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on close button");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}

	public JDEHomePage signOut() throws Exception
	{
		try {
			driver.switchTo().defaultContent();
					
			isElementDisplayed(btnSign);
			getElement(btnSign).click();
			waitTill(5000);
			} 
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to click on Sign Out button");
			throw (new Exception(t.getMessage()));
		}
		return this;
	}


}
