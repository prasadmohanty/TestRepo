package Pages.Controllers.JDE;

import org.openqa.selenium.By;

import Pages.Common.MasterPage;
import SupportLibraries.ListenerClass;
import SupportLibraries.ScriptHelper;
import Utils.StringEncrypt;

public class JDELoginPage extends MasterPage{


	By txtUserName		=	By.id("User");
	By txtPassword		=	By.id("Password");
	By btnSignIn		=	By.cssSelector("#F1 > table > tbody > tr > td > div > table > tbody > tr:nth-child(2) > td.boxcontent > table > tbody > tr:nth-child(3) > td > div:nth-child(17) > input");

	public JDELoginPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		// TODO Auto-generated constructor stub
	}

	/*
	 * Method to launch the JDe Application base URL.
	 */
	public JDELoginPage getApplication() throws Exception {
		try {
			driver.manage().window().maximize();
			driver.get(properties.getProperty("JDETestapplicationURL"));
			waitTill(500);
		}
		catch (Throwable t) {
			ListenerClass
			.setErrorMessage("Failed to launch the JDE application using "
					+ properties.getProperty("JDETestapplicationURL"));
			throw (new Exception());
		}
		return this;
	}

	/*
	 * Method to type username 
	 */
	public JDELoginPage typeUserName(String Testcase) throws Exception {
		try {
			getElement(txtUserName).clear();
			String userName = dataLoader.getTestdata("JDETestPurpose", Testcase,"UserID");
			getElement(txtUserName).sendKeys(userName.trim());
			waitTill(1000);

		} catch (Throwable t) {
			t.printStackTrace();
			ListenerClass
			.setErrorMessage("Failed to type Username into the text box");
			throw (new Exception());
		}
		return this;

	}

	/*
	 * Method to type username 
	 */
	public JDELoginPage typePassword(String Testcase) throws Exception {
		try {
			getElement(txtPassword).clear();
			String key = dataLoader.getTestdata("JDETestPurpose", Testcase, "Key");                                         
            String passWord = dataLoader.getTestdata("JDETestPurpose", Testcase,"Password");
            String decodedPwd = StringEncrypt.decryptXOR(passWord,key);     
			getElement(txtPassword).sendKeys(decodedPwd.trim());
			waitTill(1000);

		} catch (Throwable t) {
			t.printStackTrace();
			ListenerClass
			.setErrorMessage("Failed to type password into the text box");
			throw (new Exception());
		}
		return this;

	}

	/*
	 * Method to click on Sign on button
	 */
	public JDELoginPage clicksignonButton() throws Exception {
		try {

			clickUsingJavaScript(getElement(btnSignIn));
			waitForElementInVisible(By.className("loading-indicator"), 60);

		} catch (Throwable t) {
			ListenerClass.setErrorMessage("Failed to click Login button");
			throw (new Exception());
		}
		return this;
	}

}
