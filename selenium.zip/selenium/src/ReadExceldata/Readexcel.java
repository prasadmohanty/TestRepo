package ReadExceldata;

import java.nio.file.Files;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
public class Readexcel {

	public static void main(String[] args) throws Exception {
		File src=new  File("C:\\Users\\bindushree.p\\Downloads\\New folder\\Exceldata.xlsx");
		FileInputStream fis=new FileInputStream(src);
        XSSFWorkbook ws=new  XSSFWorkbook(fis);
        XSSFSheet sh1=ws.getSheetAt(0);
	
	//String data0=sh1.getRow(0).getCell(0).getStringCellValue();
	//System.out.print("Data from excel is " +data0);
	//String data1=sh1.getRow(0).getCell(1).getStringCellValue();
	//System.out.print("Data from excel is " +data1);
	
	
	int rowcount=sh1.getLastRowNum();
	System.out.println("Total rows is "+rowcount+1);
	for(int i=0;i<rowcount;i++);
	{
		String data0=sh1.getRow(0).getCell(0).getStringCellValue();
	}
System.out.println("Data from Row is +i+ data0");
	ws.close();
}
}
 	 	