package ReadExceldata;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
public class Littlefuse {
	@Given("^open chrome and start application$")
	public void open_chrome_and_start_application()throws Throwable{
	
		
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\bindushree.p\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.get("https://www.littelfuse.com/");
		 driver.manage().window().maximize();
	}
		// @When("^I click on accept button to go to the main page$")
		 //@When("^I enter valid username and valid password$")
		 //public void I_click_on_accept_button_to_go_to_the_main Littlefuse()throws Throwable{
			 
		 //driver .findElement(By.xpath(".//input[ @value='ACCEPT']")).click();
		 
		 //Alert alert = driver.switchTo().alert();
		//  alert.accept();
		 
		  //driver.findElement(By.xpath("//button[contains(text(),'No, thanks')]")).click();
		  
		// driver.findElement(By.id("main-navigation")).click();
		 //
		// driver.findElement(By.("acsMainInvite")).click();
		 //Alert alert = driver.switchTo().alert();
		  //alert.accept();
		 // System.out.println(driver.switchTo().alert().getText());
		 
		   //driver.switchTo().alert().accept();

		 // driver.close();
		 
		 

	}


