package stepDefination;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
public class smokeTest {
	
		 WebDriver driver;		
					 @Given("^Open  chrome and start application$")
					 public void open_chrome_and_start_application()throws Throwable{
				 System.setProperty("webdriver.chrome.driver","C:\\Users\\bindushree.p\\Downloads\\chromedriver_win32\\chromedriver.exe");
					 driver = new ChromeDriver();
					 driver.get("https://facebook.com");
					 driver.manage().window().maximize();
					 }
					
					
					 @When("^I enter valid username and valid password$")
					 public void I_enter_valid_username_and_valid_password()throws Throwable{
						 driver.findElement(By.name("username")).sendKeys("7978424447");
						 driver.findElement(By.name("password")).sendKeys("nmho1234");
					 }
					
					 
					
					 @Then("^user should be able to login successfully$")
					 public void user_should_be_able_to_login_successfully()throws Throwable{
					 driver.findElement(By.id("u_0_2")).click();
					 }
					
					 
					
}
