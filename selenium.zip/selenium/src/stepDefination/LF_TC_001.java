package stepDefination;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LF_TC_001  {
	WebDriver driver;		
	 @Given("^Open  chrome and start application$")
	 public void open_chrome_and_start_application()throws Throwable{
System.setProperty("webdriver.chrome.driver","C:\\Users\\bindushree.p\\Downloads\\chromedriver_win32\\chromedriver.exe");
	 driver = new ChromeDriver();
	 driver.get("https://www.littelfuse.com/");
	 driver.manage().window().maximize();
	 }
	
	 @When("^User click on the link Products$")
	 public void User_click_on_the_link_products()throws Throwable{ 
		driver.findElement(By.xpath(".//input[ @value='ACCEPT']")).click();
		 driver.findElement(By.id("main-navigation")).click();
	 }
		 @Then("^ User should able to click on  industries$")
		 public void user_should_be_able_to_click_on_industries()throws Throwable{
		 driver.findElement(By.xpath("//*[contains(@id,'main-navigation')]")).click();
		 
		 }
		 @And("^User click on the services$")
		 public void user_click_on_the_services()throws Throwable{
		String link= driver.findElement(By.linkText("SERVICES")).getText();
		System.out.println("link");
		Assert.assertEquals(link,"User should successfuly click on the link");
		System.out.println("testcase passed");
		 }
		 @And("^User click on select All$")
		 public void user_click_on_select_All()throws Throwable{
			 Select ls=new Select(driver.findElement(By.xpath("//*[contains(@name,'header_0$ctl00$ddlProperties')]")));
			 ls.selectByVisibleText("Automotive Sensor Products");
			 ls.selectByIndex(1);
		 }
		 @And("^User should select on Automotive Sensor Products$")
		 
		 public void user_should_select_on_Automotive_sensor_products()throws Throwable{
			String fs=driver.findElement(By.xpath("//*[contains(@name,'header_0$ctl00$ddlProperties')]")).getText();
			System.out.println("fs");
			Assert.assertEquals(fs,"Automotive Sensor Products");
		 }
        @And("^User can search the product D(\\d+)and result should displayed$")
		 
		 public void user_can_search_the_product_and_result_should_displayed()throws Throwable{
        	driver.findElement(By.id("searchBox")).sendKeys("155.0892.5501");
        	driver.findElement(By.xpath("//*[contains(text(),'Search')]")).click();
        	Assert.assertEquals(driver.findElement(By.xpath("//*[contains(text(),'Search')]")),"Clicked on search bottom");
        }
			 
		 //@When("^I click on accept button to go to the main page$")
		 //@When("^I enter valid username and valid password$")
		 //public void I_click_on_accept_button_to_go_to_the_main Littlefuse()throws Throwable{
			 
		 //driver .findElement(By.xpath(".//input[ @value='ACCEPT']")).click();
		 
		 //Alert alert = driver.switchTo().alert();
		//  alert.accept();
		 
		  //driver.findElement(By.xpath("//button[contains(text(),'No, thanks')]")).click();
		  
		// driver.findElement(By.id("main-navigation")).click();
		 //
		// driver.findElement(By.("acsMainInvite")).click();
		 //Alert alert = driver.switchTo().alert();
		  //alert.accept();
		 // System.out.println(driver.switchTo().alert().getText());
		 
		   //driver.switchTo().alert().accept();

		 // driver.close();
	 }


