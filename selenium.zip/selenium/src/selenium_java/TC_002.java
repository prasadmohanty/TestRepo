package selenium_java;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class TC_002 {
 

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","D://chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		//System.setProperty("webdriver.firefox.marionette","D:/New folder/geckodriver.exe");
		//WebDriver driver = new FirefoxDriver();
		driver.navigate().to("http://newtours.demoaut.com");
		
		driver.findElement(By.name("userName")).sendKeys("admin");
	driver.findElement(By.name("password")).sendKeys("admin");
	driver.findElement(By.name("login")).click();
		System.out.println(driver.findElement(By.name("login")).getAttribute("height"));

	Thread.sleep(2000);
		
		String title = driver.getTitle();
	if (title.contains("Find a Flight"))
	{
		System.out.println("Login successful");
		}
		else
	{
		System.out.println("Login is not successful");
		}
		
System.out.println(driver.getPageSource());
	}



	
	}


