package selenium_java;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test 
{
	public static void main(String[] args) throws InterruptedException 
	{ 
		System.setProperty("webdriver.chrome.driver","D://chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		
		driver.findElement(By.name("userName")).sendKeys("mercury");
		driver.findElement(By.name("password")).sendKeys("mercury");
		driver.findElement(By.name("login")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("findFlights")).click();
		driver.findElement(By.linkText("SIGN-OFF")).click();
	}


	
		

	}


