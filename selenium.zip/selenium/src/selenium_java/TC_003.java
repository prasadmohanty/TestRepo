package selenium_java;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC_003 {
	
	
		 
		public static void main(String[] args) {
			
			System.setProperty("webdriver.chrome.driver","D://chromedriver_win32//chromedriver.exe");
			
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.localjobserver.com/");
			List<WebElement> allitems = driver.findElements(By.tagName("a"));
			int count = 0;
			for(WebElement ele : allitems)
			{
				String LinkValue = ele.getText();
				if (LinkValue.length()>1)
				{
					count = count + 1;
				}
			}
			System.out.println(count);
		}
	

	

	}


