package selenium_java;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class implicitwait {
	

	public static void main(String[] args) {
		
			WebDriver driver = new ChromeDriver();
			
			System.setProperty("webdriver.chrome.driver","D://chromedriver_win32//chromedriver.exe");
			driver.get("http://newtours.demoaut.com/");
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			List<WebElement> allitems = driver.findElements(By.xpath("//input[@size='10']"));
			for(WebElement ele:allitems)
			{
				ele.sendKeys("mercury");
			}
			driver.findElement(By.name("login")).click();	
		}
	

	
		
	}


