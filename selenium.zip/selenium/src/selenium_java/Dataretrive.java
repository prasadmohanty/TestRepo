package selenium_java;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dataretrive {

	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\bindushree.p\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		List<WebElement> rows = driver.findElements(By.xpath("//table[@width='270']/tbody/tr"));
		int rowcount = rows.size();
		for(int i = 1 ;i<=rowcount;i++)
		{
			List<WebElement> cols = driver.findElements(By.xpath("//table[@width='270']/tbody/tr[" + i + "]/td"));
			int colcount = cols.size();
			for(int j = 1 ;j<=colcount;j++)
			{
				WebElement cell = driver.findElement(By.xpath("//table[@width='270']/tbody/tr[" + i + "]/td[" + j + "]"));
				System.out.println(cell.getText());
			}
		}
	}





	}


