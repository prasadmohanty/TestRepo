package selenium_java;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
public class facebook {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","C:\\Users\\bindushree.p\\Downloads\\chromedriver_win32\\chromedriver.exe");
		 driver = new ChromeDriver();
		 driver.get("https://facebook.com");
		 driver.manage().window().maximize();
		 driver.findElement(By.name("email")).sendKeys("7978424447");
		 driver.findElement(By.xpath(".//input[@type='password']")).sendKeys("nmho1234");
		 driver.findElement(By.id("u_0_2")).click();
		 Thread.sleep(3000);
		 Assert.assertEquals(true,false);
	}

}
