package selenium_java;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TC_004 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D://chromedriver_win32//chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://newtours.demoaut.com/");
		
		List<WebElement> allitems = driver.findElements(By.xpath("//input[@size='10']"));
		for(WebElement ele:allitems)
		{
			ele.sendKeys("mercury");
		}
	}


	}

