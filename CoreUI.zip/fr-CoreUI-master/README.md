# fr-CoreUI
Field Rewards Core UI Automation Framework- Selenium
