package com.nm.automation.core.mail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.internet.MimeMultipart;

public class MailSender {
	
	private boolean isMailEnabled;
	private String strSmtpHost;
	private InternetAddress[] arrToRecipients;
	private InternetAddress[] arrCcRecipients;
	private String strSubject = "";
	private String strDirAttachment = "";
	private String strFileName = "";
	private String strMsgHeader = "";
	private String strMsgFooter = "";
	
	public void send(Properties prop, String pdfName){
		// set property value
		try{
			this.setMailEnabled(Boolean.parseBoolean(prop
					.getProperty("mail.enable")));
			this.setArrToRecipients(prop.getProperty("mail.to"));
			this.setArrCcRecipients(prop.getProperty("mail.cc"));
			this.setStrSubject(prop.getProperty("mail.subject"));
			this.setStrFileName(prop.getProperty("mail.attachment"));
			this.setStrSmtpHost(prop.getProperty("mail.smtphost"));
			this.setStrFileName(pdfName);
			
			if(this.isMailEnabled()){
				sendEmailWithAttachment();
			    System.out.println("The mail has been sent successfully");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void sendEmailWithAttachment() {
		try {
	         Properties  properties = System.getProperties(); 
	         properties.put("mail.smtp.host", this.getStrSmtpHost());
	         properties.put("mail.smtp.auth", "false");
	         properties.put("mail.smtp.ssl.enable", "true");
	     
	          Session emailSession = Session.getInstance(properties,null);
	          Message emailMessage = new MimeMessage(emailSession);
	          
	          emailMessage.setRecipients(Message.RecipientType.TO, this.getArrToRecipients());
	          emailMessage.addRecipients(RecipientType.CC, this.getArrCcRecipients());
	          emailMessage.setFrom(new InternetAddress("subhasmita.nayak@northwestrenmutual.com"));
	          emailMessage.setSubject(this.getStrSubject());
	          emailSession.setDebug(true);
	          
	          BodyPart messageBodyPart1 = new MimeBodyPart();  
	          String msg = this.getStrMsgHeader() + this.getStrMsgFooter();
	          messageBodyPart1.setContent(msg, "text/html");
	          
	          BodyPart messageBodyPart2 = new MimeBodyPart();
	          String AttachPath = this.getStrDirAttachment() + this.getStrFileName();
	          DataSource source = new FileDataSource(AttachPath);
	          messageBodyPart2.setDataHandler(new DataHandler(source)); 
	          
	          messageBodyPart2.setFileName(this.getStrFileName()); 
	          
	          //Create Multipart object and add MimeBodyPart objects to this object      
	          Multipart multipart = new MimeMultipart();  
	          multipart.addBodyPart(messageBodyPart1);  
	          multipart.addBodyPart(messageBodyPart2); 
	          
	          emailMessage.setContent(multipart );//set the multiplart object to the message object    
	          
	          Transport.send(emailMessage);  // send message  
	         
          } catch (AddressException e) {
                   e.printStackTrace();
          } catch (MessagingException e) {
               e.printStackTrace();
          }
	}
	
	public boolean isMailEnabled() {
		return isMailEnabled;
	}
	public void setMailEnabled(boolean isMailEnabled) {
		this.isMailEnabled = isMailEnabled;
	}
	public InternetAddress[] getArrToRecipients() {
		return arrToRecipients;
	}
	public InternetAddress getInternetAddress(String emailId) throws AddressException{
		return new InternetAddress(emailId);
	}
	public void setArrToRecipients(String to) throws AddressException {	
		ArrayList< String> arrTo = new ArrayList<String>();
		if(to.length() > 2){
			String newStr = to.replaceAll("\\[", "").replaceAll("\\]","");
			String[] parts = newStr.split(",");
			List<String> wordList = Arrays.asList(parts);  
			for (String s : wordList){  
				arrTo.add(s);
		        System.out.println("To recipients : " + s);  
		    }
		}
		InternetAddress inetAddress[] = new InternetAddress[arrTo.size()];
		for(int i = 0; i < arrTo.size(); i++){
			String eachMailId = arrTo.get(i);
			inetAddress[i] = getInternetAddress(eachMailId);
		}
		this.arrToRecipients = inetAddress;
	}
	public InternetAddress[] getArrCcRecipients() {
		return arrCcRecipients;
	}
	public void setArrCcRecipients(String cc) throws AddressException {
		ArrayList< String> arrCc = new ArrayList<String>();
		if(cc.length() > 2){
			String newStr = cc.replaceAll("\\[", "").replaceAll("\\]","");
			String[] parts = newStr.split(",");
			List<String> wordList = Arrays.asList(parts);  
			for (String s : wordList){  
				arrCc.add(s);
		        System.out.println("Cc recipients : " + s);  
		    }
		}
		InternetAddress inetAddress[] = new InternetAddress[arrCc.size()];
		for(int i = 0; i < arrCc.size(); i++){
			String eachMailId = arrCc.get(i);
			inetAddress[i] = getInternetAddress(eachMailId);
		}
		this.arrCcRecipients = inetAddress;
	}
	public String getStrSubject() {
		return strSubject;
	}
	public void setStrSubject(String strSubject) {
		this.strSubject = strSubject;
	}
	public String getStrDirAttachment() {
		return strDirAttachment;
	}
	public void setStrDirAttachment(String strDirAttachment) {
		this.strDirAttachment = strDirAttachment;
	}
	public String getStrFileName() {
		return strFileName;
	}
	public void setStrFileName(String strFileName) {
		this.strFileName = strFileName;
	}
	
	public String getStrMsgHeader() {
		strMsgHeader = "Hi All,</br></br>This is an auto generated mail from NM system Team, "
				+ "to notify the excecution report</br><br>";
		return strMsgHeader;
	}
	public void setStrMsgHeader(String strMsgHeader) {
		this.strMsgHeader = strMsgHeader;
	}
	public String getStrMsgFooter() {
		strMsgFooter = "Regards, </br>nm syatem team Team";
		return strMsgFooter;
	}
	public void setStrMsgFooter(String strMsgFooter) {
		this.strMsgFooter = strMsgFooter;
	}

	public String getStrSmtpHost() {
		return strSmtpHost;
	}
	public void setStrSmtpHost(String strSmtpHost) {
		this.strSmtpHost = strSmtpHost;
	}
}