/**************************************************
#Project Name: North western Mutual- Selenium Framework
#Function Name: readProperties()
#Author: Subhasmita Nayak
#Description: This function reads the property File containing the static data.
#Date of creation: 
#Input Parameters:Property File Location
#Name of person modifying: Tester
#Date of modification: 
â€˜**************************************************/

package com.nm.automation.core.io;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.codec.binary.Base64;

import com.nm.automation.core.reportwriter.GeneratePDFReport;

public class ReadProperties {
	String strFilename;
	String strreportPath;
	String strsuiteName;
	String strscreenShotOnFail;

	int intimplicitWaitTime;
	String strsrcFolder;
	private int intpageLoadTimeOut;
	String baseUrl;
	String userName;
	String password;
	String envdetails;
	String solution;
	String browser;

	public ReadProperties(String strFilename) throws IOException {
		this.strFilename = strFilename;
		strFilename = System.getProperty("user.dir") + "\\config.properties";
		/// Log.info("strFilename--->"+strFilename);

		readPropFile();
	}

	private void readPropFile() throws IOException {
		Properties prop = new Properties();
		// FileReader file = new FileReader(strFilename + ".properties");
		FileReader file = new FileReader(strFilename);
		prop.load(file);
		strreportPath = prop.getProperty("reportPath");
		strsuiteName = prop.getProperty("suiteName");
		strscreenShotOnFail = prop.getProperty("screenShotOnFail");
		intimplicitWaitTime = Integer.parseInt(prop.getProperty("waitTime"));
		strsrcFolder = prop.getProperty("srcFolder");
		intpageLoadTimeOut = Integer.parseInt(prop.getProperty("pageLoadTimeOut"));
		baseUrl = prop.getProperty("baseUrl");
		userName = prop.getProperty("userName");
		password = prop.getProperty("password");
		browser = prop.getProperty("browser");
		if (prop.getProperty("environment") == null) {

			Log.info("The value is null for environment");
			prop.put("environment", "");
			// FileOutputStream fileOut = new FileOutputStream(strFilename +
			// ".properties");
			FileOutputStream fileOut = new FileOutputStream(strFilename);
			prop.store(fileOut, "");
			fileOut.close();
		} else {
			Log.info("No value for environment Present");
			envdetails = prop.getProperty("environment");
			GeneratePDFReport.arr_testEnvironment = envdetails;
			Log.info("environment Name is    " + envdetails);
		}
		if (prop.getProperty("solution") == null) {
			Log.info("The value is null for Solution");
			prop.put("solution", "");
			// FileOutputStream fileOut = new FileOutputStream(strFilename +
			// ".properties");
			FileOutputStream fileOut = new FileOutputStream(strFilename);
			prop.store(fileOut, "");
			fileOut.close();
		} else {
			Log.info("No value for Solution Present");
			solution = prop.getProperty("solution");
			GeneratePDFReport.arr_testSolution = solution;
			Log.info("Solution Name is    " + envdetails);
		}

	}

	public int getimplicitWait() {
		return intimplicitWaitTime;
	}

	public int getpageLoadTimeOut() {
		return intpageLoadTimeOut;
	}

	public String getreportPath() {
		return strreportPath;
	}

	public String getsuiteName() {
		return strsuiteName;
	}

	public String getscreenShotcriteria() {
		return strscreenShotOnFail;
	}

	public String getsrcFolder() {
		return strsrcFolder;
	}

	public String getBrowser() {
		return browser;
	}

	public String getbaseurl() {
		Log.info("Inside getbaseUrl");
		return baseUrl;
	}


	public String getSourceUserName() {

		return userName;
	}

	public String getSourcepassword() {
		return password;
	}


	
	

	public String getpassword() {
		String password = getSourcepassword();
		byte[] bytesDecoded = Base64.decodeBase64(password.getBytes());
		String result = new String(bytesDecoded);
		Log.info("decoded value::" + result);
		return result;
	}
	public String getuserName() {
		String userName = getSourceUserName();
		byte[] bytesDecoded = Base64.decodeBase64(userName.getBytes());
		String result = new String(bytesDecoded);
		Log.info("decoded value::" + result);
		return result;
	}

}
