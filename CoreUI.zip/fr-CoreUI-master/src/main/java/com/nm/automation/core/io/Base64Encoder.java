package com.nm.automation.core.io;

import org.apache.commons.codec.binary.Base64;

/**
 * 
 * @author nay6538
 * @Url: tps://www.base64decode.org/
 *
 */

public class Base64Encoder {
	
	public String encode(String value){
		byte[] bytesEncoded=Base64.encodeBase64(value.getBytes());
		String result=new String(bytesEncoded);
		System.out.println("Encoded value::"+result);
		return result;
		
	}
	public String decode(String value){
		byte[] bytesDecoded=Base64.decodeBase64(value.getBytes());
		String result=new String(bytesDecoded);
		System.out.println("decoded value::"+result);
		return result;
		
	}
	
	public static void main(String[] args) {
		Base64Encoder be=new Base64Encoder();
		be.decode("bGlua3U=");
	

	}

}
