package com.nm.automation.core.io;

import java.awt.Graphics;

import javax.swing.JLabel;

/**
 * @author Subhasmita
 * @return
 **/
public class FlashMessage {
	// private static String message = "Your Message";
	private static JLabel label = new JLabel();
	private static String labelMessage = "Hello";

	/**
	 * This method returns the flash
	 * 
	 * @return
	 **/
	public void flash() {
		// label.enable();
		label.setText(labelMessage);

	}

	public void paint(Graphics g) {
		g.drawString("abc", 25, 25);
	}

	public static void main(String[] args) throws InterruptedException {
		FlashMessage fm = new FlashMessage();
		fm.paint(null);
	}
}
