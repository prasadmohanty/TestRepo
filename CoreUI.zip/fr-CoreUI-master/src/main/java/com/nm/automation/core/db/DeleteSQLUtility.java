package com.nm.automation.core.db;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.nm.automation.core.io.Log;

/**
 * @ClassName: DeleteSQLUtility
 * @Desc: Defines Database delete utility functions
 * @author Subhasmita
 * @Date 25-April-2017
 *
 */
public class DeleteSQLUtility {
	public DBConnectionUtility dbConnectionUtility;
	Connection conn = null;
	String path = System.getProperty("user.dir") + "\\sql\\deleteSql.txt";

	public DeleteSQLUtility() throws IOException {
		dbConnectionUtility = new DBConnectionUtility();

	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc A switch case method to perform delete action in different data
	 *       base
	 * @throws SQLException
	 * 
	 */
	public void doDelete(String dbName) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			@SuppressWarnings("resource")
			Scanner linReader = new Scanner(new File(path));
			int i = 1;
			while (linReader.hasNext()) {

				String line = linReader.nextLine();
				statement = conn.createStatement();
				statement.executeUpdate(line);
				Log.info(i + "-Record deleted ");
				i++;
			}

		} catch (Exception e) {
			e.getStackTrace();
			Log.info("Please check your DB name!!!");
		}
		dbConnectionUtility.closeConnection(conn);
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc THis function performs delete action by linenum defined in the
	 *       deletesql.txt available in sql folder
	 * @param dbName
	 * @param lineNum
	 * @throws SQLException
	 */
	public void deleteQueryByLineNum(String dbName, int lineNum) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = Files.readAllLines(Paths.get(path)).get(lineNum);
			Log.info(line);
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			Log.info("Mentioned line num not found ");
		}
		dbConnectionUtility.closeConnection(conn);
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc THis function performs delete action by statement defined in the
	 *       test script
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void deleteQueryByStatement(String dbName, String sqlStatement) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = sqlStatement;
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			Log.info("Mentioned line num not found ");
		}
		dbConnectionUtility.closeConnection(conn);
	}
}
