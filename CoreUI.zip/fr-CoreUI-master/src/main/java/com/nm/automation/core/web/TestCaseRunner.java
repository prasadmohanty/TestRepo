package com.nm.automation.core.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.itextpdf.text.DocumentException;
import com.nm.automation.core.io.ExcelReader;
import com.nm.automation.core.io.Log;
import com.nm.automation.core.io.ReadProperties;

import jxl.read.biff.BiffException;

public abstract class TestCaseRunner {

	public final static String DP = "parameters";

	// Mandatory Variable Declarations.
	public WebDriver driver;
	static String strBrowser;
	static Object[][] browser;
	public static String className;
	int browserCount = 0;
	static String dataFilePath;
	static String propFilePath;

	// Core Classes
	DriverFunctions df;
	public TestEnginee te;
	public static ReadProperties rp;
	public static ExcelReader EH;

	@BeforeSuite
	public void beforeTest() {
		setPropertyFileName();
		System.out.println("Before suite driver--->"+driver);

		try {

			System.out.println("***************************************");
			System.out
					.println("  -------------- EXECUTION STARTS HERE----------------------");
			System.out
					.println("  -------------- BEFORE TEST   ----------------------");
			System.out.println("PropFilePath--->"+propFilePath);
			rp = new ReadProperties(propFilePath);
			te = new TestEnginee();
			te.createSuitePath(rp.getreportPath(), rp.getsuiteName(),
					rp.getscreenShotcriteria());
			te.set_StartTime_suite();
			EH = new ExcelReader();
			System.out
					.println("  -------------- BEFORE TEST ENDS  ----------------------");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * The below sections handles parameterization. Its mandatory to create a
	 * .xls file against each test case. The file name should be equal to the
	 * test class name. *
	 */

	@DataProvider(name = DP)
	public static Object[][] credentials() throws BiffException, IOException {
		browser = null;
		browser = EH.defreadExcel(className);
		for (int i = 0; i < browser.length; i++) {
			Log.info("The browsers are : ------" + browser[i][0]);
		}
		return browser;
	}

	/**
	 * Method for before Class
	 * 
	 * @throws IOException
	 */
	@SuppressWarnings(value = { "all" })
	@BeforeClass
	public void beforeClass() throws IOException {
		killExecutables("iexplore.exe");
		killExecutables("IEDriverServer.exe");
		Log.info("********************************************");
		Log.info("--------------In before Class****************");
		rp = new ReadProperties(propFilePath);
		Log.info("        Source Folder is " + rp.getsrcFolder());

		String internalPath = this.getClass().getName()
				.replace(".", File.separator);
		String externalPath = System.getProperty("user.dir") + File.separator
				+ rp.getsrcFolder();
		String workDir = externalPath
				+ File.separator
				+ internalPath.substring(0,
						internalPath.lastIndexOf(File.separator));
		this.dataFilePath = workDir;

		Log.info("----------------datafile name----------------" + dataFilePath);
		this.className = this.getClass().getSimpleName().trim();
		te = new TestEnginee(this.getClass().getSimpleName().trim(),
				rp.getsuiteName());
		Log.info("Class Name is : " + className);
		EH.openExecl(dataFilePath + "\\testdata");
		te.set_StartTime_test();
		System.out
				.println("*********--------------Before Class ENDS--------****************");
	}

	/**
	 * Method for AfterMethod
	 */
	
	@AfterMethod
	public void afterMethod() {
		Log.info("------        After Method Executed---------");
		//te.generateMethodInfo();
		try {
			df.closebrowser();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Method for AfterClass
	 */
	@AfterClass
	public void afterClass() throws IOException {
		Log.info("------        After Class Starts---------");
		
		//te.endReport();
		te.generateTestReport();
		DriverFunctions.closeAllBrowserWindows(driver);
		
		Log.info("------        After Class Executed---------");
	}

	/**
	 * Method for AfterMethod
	 */
	public void beforeMethod(){
		Log.info("------        Before Method Starts---------");
		strBrowser = (String) browser[browserCount][0];
		df = new DriverFunctions(driver, strBrowser, rp.getimplicitWait(),
				rp.getpageLoadTimeOut());
		try {
		
			driver = df.openBrowser();
			System.out.println("Testcase Runner browser return---->"+driver);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		te.initializeMethod(driver, strBrowser);
		browserCount++;
		Log.info("------        Before Method Ends---------");
		
	}

	/**
	 * Method for AfterTest
	 */

	@AfterSuite
	public void afterTest() throws IOException, DocumentException {
		Log.info("------        After Test Starts---------");
		te.set_EndTime_suite();
		te.createSuiteReport();
		killExecutables("phantomjs.exe");
		killExecutables("chromedriver.exe");
		killExecutables("IEDriverServer.exe");
		Log.info("------       EXECUTION COMPLETED..---------");
	}

	
	/**
	 * Reads the Property File Name and processes it.
	 */
	public abstract void setPropertyFileName();

	public void setPropertyFileName(String propFilePath) {
		this.propFilePath = propFilePath;

	}

	/**
	 * This method will explicitly kill Phantom.exe processes.	 * 
	 * @throws IOException
	 */
	private void killExecutables(String browserDriver) throws IOException {
		String pidInfo;
		Process p = Runtime.getRuntime().exec(
				System.getenv("windir") + "\\system32\\" + "tasklist.exe");
		BufferedReader input = new BufferedReader(new InputStreamReader(
				p.getInputStream()));

		String line;
		while ((line = input.readLine()) != null) {
			pidInfo = line;
			// System.out.println(pidInfo);

			// TODO Auto-generated method stub
			if (pidInfo.contains("phantomjs.exe")) {
				Runtime.getRuntime().exec("taskkill /F /IM " + browserDriver);
			}

		}
	}

}
