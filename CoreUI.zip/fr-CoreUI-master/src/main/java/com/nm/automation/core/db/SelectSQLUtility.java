package com.nm.automation.core.db;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.nm.automation.core.io.Log;
/**
 * @ClassName: InsertSQLUtility
 * @Desc: Defines Database Select utility functions
 * @author Subhasmita
 * @Date 25-April-2017
 *
 */
public class SelectSQLUtility {
	public DBConnectionUtility dbConnectionUtility;
	Connection conn = null;

	String path = System.getProperty("user.dir") + "\\sql\\selectSql.txt";

	public SelectSQLUtility() throws IOException {
		dbConnectionUtility = new DBConnectionUtility();

	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc This function performs all the select query action by database name
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void selectQuery(String dbName) {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			@SuppressWarnings("resource")
			Scanner linReader = new Scanner(new File(path));
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			boolean found = false;
			@SuppressWarnings("unused")
			int i = 1;
			while (linReader.hasNext()) {
				String line = linReader.nextLine();
				Log.info("line::" + line);
				pstmt = conn.prepareStatement(line.toString());
				rset = pstmt.executeQuery();

				if (rset != null) {
					found = true;
					DBTablePrinter.printTableRecord(conn, line);
					/*
					 * while (rset.next()) { found = true;
					 * DBTablePrinter.printTableRecord(conn, line); }
					 */
				} else {
					Log.info("rset is null");
				}
				if (found == false) {
					Log.info("No Information Found");
				}

				i++;
			}
		} catch (Exception e) {
			Log.info("No query found");
		}

	}
	
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc This function performs select action by line num defined in the
	 *       selectsql.txt file
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void selectQuery(String dbName, int sqlFileLineNum) {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			@SuppressWarnings("resource")
			Scanner linReader = new Scanner(new File(path));
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			boolean found = false;
			@SuppressWarnings("unused")
			int i = 1;
			while (linReader.hasNext()) {
				String line = linReader.nextLine();
				Log.info("line::" + line);
				pstmt = conn.prepareStatement(line.toString());
				rset = pstmt.executeQuery();

				if (rset != null) {
					found = true;
					DBTablePrinter.printTableRecord(conn, line);
					/*
					 * while (rset.next()) { found = true;
					 * DBTablePrinter.printTableRecord(conn, line); }
					 */
				} else {
					Log.info("rset is null");
				}
				if (found == false) {
					Log.info("No Information Found");
				}

				i++;
			}
		} catch (Exception e) {
			Log.info("No query found");
		}

	}

	public String selectQuery(String dbName, int lineNum, int columnIndex) {
		String returnVal=null;
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			boolean found = false;
			String line = Files.readAllLines(Paths.get(path)).get(lineNum);
			Log.info("Line:" + line);
			pstmt = conn.prepareStatement(line.toString());
			rset = pstmt.executeQuery();
			while (rset.next()) {
				returnVal = rset.getString(columnIndex);
				
				Log.info("Returnval" + returnVal);
				DBTablePrinter.printTableRecord(conn, line);
			}
			/*if (rset != null) {
				found = true;
				DBTablePrinter.printTableRecord(conn, line);

			} else {
				Log.info("rset is null");
			}
			if (found == false) {
				Log.info("No Information Found");
			}*/

		} catch (Exception e) {
			Log.info("Mentioned line number not found");

		}
		return returnVal;
	}
	public String selectQuery(String dbName, int lineNum, String colName) {
		String returnVal=null;
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			boolean found = false;
			String line = Files.readAllLines(Paths.get(path)).get(lineNum);
			Log.info("Line:" + line);
			pstmt = conn.prepareStatement(line.toString());
			rset = pstmt.executeQuery();
			while (rset.next()) {
				returnVal = rset.getString(colName);
				DBTablePrinter.printTableRecord(conn, line);
			}
			/*if (rset != null) {
				found = true;
				DBTablePrinter.printTableRecord(conn, line);

			} else {
				Log.info("rset is null");
			}
			if (found == false) {
				Log.info("No Information Found");
			}*/

		} catch (Exception e) {
			Log.info("Mentioned line number not found");

		}
		return returnVal;
	}
	public String selectQuery(String dbName, String sqlStatement, String colName) {
		String returnVal = null;
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			String line = sqlStatement;
			pstmt = conn.prepareStatement(line.toString());
			rset = pstmt.executeQuery();
			while (rset.next()) {
				returnVal = rset.getString(colName);
				DBTablePrinter.printTableRecord(conn, line);
			}
			/*
			 * if (rset != null) { found = true;
			 * Log.info("Colname"+colName);
			 * 
			 * 
			 * } else { Log.info("rset is null"); } if (found ==
			 * false) { Log.info("No Information Found"); }
			 */
		} catch (Exception e) {
			Log.info("Please check the query");

		}
		 return returnVal;
	}
public int getRowCount(String dbName, String sqlStatement) {
		String returnVal = null;
		int count=0;
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			PreparedStatement pstmt = null;
			ResultSet rset = null;
			String line = sqlStatement;
			pstmt = conn.prepareStatement(line.toString());
			rset = pstmt.executeQuery();
			while (rset.next()) {
				String colName="1";
				returnVal = rset.getString(colName);
				DBTablePrinter.printTableRecord(conn, line);
			}
			/*
			 * if (rset != null) { found = true;
			 * Log.info("Colname"+colName);
			 * 
			 * 
			 * } else { Log.info("rset is null"); } if (found ==
			 * false) { Log.info("No Information Found"); }
			 */
			 count = Integer.parseInt(returnVal);
		} catch (Exception e) {
			Log.info("Please check the query");

		}
		 return count;
	}
}
