package com.nm.automation.core.db;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.nm.automation.core.io.Log;

/**
 * @ClassName: InsertSQLUtility
 * @Desc: Defines Database insert utility functions
 * @author Subhasmita
 * @Date 25-April-2017
 *
 */
public class InsertSQLUtility {
	public DBConnectionUtility dbConnectionUtility;
	Connection conn = null;
	String path = System.getProperty("user.dir") + "\\sql\\insertSql.txt";

	public InsertSQLUtility() throws IOException {
		dbConnectionUtility = new DBConnectionUtility();
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc A switch case method to perform insert action in different data
	 *       base
	 * @throws SQLException
	 * 
	 */
	public void doInsert(String dbName) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			// @SuppressWarnings("resource")
			@SuppressWarnings("resource")
			Scanner linReader = new Scanner(new File(path));
			int i = 1;
			while (linReader.hasNext()) {

				String line = linReader.nextLine();
				Log.info(line);
				statement = conn.createStatement();
				statement.executeUpdate(line);
				Log.info(i + "Record Inserted ");
				i++;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
		dbConnectionUtility.closeConnection(conn);
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc THis function performs insert action by linenum defined in the
	 *       insertsql.txt available in sql folder
	 * @param dbName
	 * @param lineNum
	 * @throws SQLException
	 */
	public void insertQueryByLineNum(String dbName, int lineNum) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				Log.info("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				Log.info("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = Files.readAllLines(Paths.get(path)).get(lineNum);
			Log.info(line);
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			Log.info("Mentioned line num not found ");
		}
		dbConnectionUtility.closeConnection(conn);
	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc THis function performs delete action by statement defined in the
	 *       test script
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void insertQueryByStatement(String dbName, String sqlStatement) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				conn = DBConnectionUtility.getDBT1Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = sqlStatement;
			Log.info(line);
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			Log.info("Mentioned line num not found ");
		}
	dbConnectionUtility.closeConnection(conn);
	}
}
