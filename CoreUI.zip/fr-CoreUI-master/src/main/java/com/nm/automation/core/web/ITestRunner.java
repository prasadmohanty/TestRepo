package com.nm.automation.core.web;

import java.awt.AWTException;
import java.io.IOException;

public interface ITestRunner {
	

	public void beforemethod() throws IOException ;
	
}
