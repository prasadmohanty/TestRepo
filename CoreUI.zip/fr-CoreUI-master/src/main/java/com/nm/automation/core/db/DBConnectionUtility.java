package com.nm.automation.core.db;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.nm.automation.core.io.Log;

public class DBConnectionUtility {
	static String db2Name;
	static String db2Driver;
	static String db2Url;
	static String db2Username;
	static String db2Password;

	static String sybaseName;
	static String sybaseDriver;
	static String sybaseUrl;
	static String sybaseUsername;
	static String sybasePassword;

	static String dbt1Name;
	static String dbt1Driver;
	static String dbt1Url;
	static String dbt1Username;
	static String dbt1Password;
	static String dbFilename = System.getProperty("user.dir") + "\\sql\\db.properties";

	public Connection conn = null;

	/**
	 * Constructor created to read the DB properties file
	 * 
	 * @throws IOException
	 */
	public DBConnectionUtility() throws IOException {
		readDBPropFile();
	}

	/**
	 * This function stores all the DB properties value
	 * 
	 * @throws IOException
	 */
	private static void readDBPropFile() throws IOException {
		Properties prop = new Properties();
		File fileCheck = new File(dbFilename);
		FileReader file = new FileReader(dbFilename);
		if (fileCheck.exists()) {
			Log.info("db.properties file exist");
			System.out.println("db.properties file exist");
		} else {
			Log.info("Please add db.properties in to path");
			System.out.println("Please add db.properties in to path");
		}
		prop.load(file);
		db2Name = prop.getProperty("db.db2name");
		System.out.println("DB2NAME:" + db2Name);
		db2Driver = prop.getProperty("db.db2driver");
		System.out.println("db2Driver:" + db2Driver);
		db2Url = prop.getProperty("db.db2url");
		System.out.println("db2Url:" + db2Url);
		db2Username = prop.getProperty("db.db2username");
		System.out.println("db2Username:" + db2Username);
		db2Password = prop.getProperty("db.db2password");
		System.out.println("db2Password:" + db2Password);

		sybaseName = prop.getProperty("db.sybasename");
		System.out.println("sybaseDBNAME:" + sybaseName);
		sybaseDriver = prop.getProperty("db.sybasedriver");
		System.out.println("sybasedbDriver:" + sybaseDriver);
		sybaseUrl = prop.getProperty("db.sybaseurl");
		System.out.println("sybasedbUrl:" + sybaseUrl);
		sybaseUsername = prop.getProperty("db.sybaseusername");
		System.out.println("sybasedbUsername:" + sybaseUsername);
		sybasePassword = prop.getProperty("db.sybasepassword");
		System.out.println("sybasedbPassword:" + sybasePassword);

		dbt1Name = prop.getProperty("db.dbt1name");
		System.out.println("dbt1DBNAME:" + dbt1Name);
		dbt1Driver = prop.getProperty("db.dbt1driver");
		System.out.println("dbt1dbDriver:" + dbt1Driver);
		dbt1Url = prop.getProperty("db.dbt1url");
		System.out.println("dbt1dbUrl:" + dbt1Url);
		dbt1Username = prop.getProperty("db.dbt1username");
		System.out.println("dbt1dbUsername:" + dbt1Username);
		dbt1Password = prop.getProperty("db.dbt1password");
		System.out.println("dbt1dbPassword:" + dbt1Password);
	}

	/***
	 * Get all the properties file value and store in to variables
	 * 
	 * @return
	 */
	public static String getDb2Name() {
		return db2Name;
	}

	public static String getSybaseName() {
		return sybaseName;
	}

	public static String getDBT1Name() {
		return dbt1Name;
	}

	public static String getDb2Driver() {
		return db2Driver;
	}

	public static String getSybaseDriver() {
		return sybaseDriver;
	}

	public static String getDBT1Driver() {
		return dbt1Driver;
	}

	public static String getDb2Url() {
		return db2Url;
	}

	public static String getSybaseUrl() {
		return sybaseUrl;
	}

	public static String getDBT1Url() {
		return dbt1Url;
	}

	public static String getDb2Username() {
		return db2Username;
	}

	public static String getSybaseUsername() {
		return sybaseUsername;
	}

	public static String getDBT1Username() {
		return dbt1Username;
	}

	public static String getDb2Password() {
		return db2Password;
	}

	public static String getSybasePassword() {
		return sybasePassword;
	}

	public static String getDBT1Password() {
		return dbt1Password;
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc Get the database connection
	 * @return
	 * @throws SQLException
	 */
	public static Connection getDB2Connection() throws SQLException {

		try {

			Class.forName(getDb2Driver());
			System.out.println("Inside get connection");
			System.out.println("DB2 driver is loaded successfully");
		} catch (ClassNotFoundException e) {
			System.out.println("Please include Classpath  Where your DB2 Driver is located");
			e.printStackTrace();
		}
		return DriverManager.getConnection(getDb2Url(), getDb2Username(), getDb2Password());

	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc Get the database connection for DBT1
	 * @return
	 * @throws SQLException
	 */
	public static Connection getDBT1Connection() throws SQLException {

		try {
			Class.forName(getDBT1Driver());
			Log.info("Inside DBT1 connection.DBT1 driver is loaded successfully");
		} catch (Exception e) {
			System.out.println("Please include Classpath  Where your DBT1 Driver is located");
			e.printStackTrace();
		}
		return DriverManager.getConnection(getDBT1Url(), getDBT1Username(), getDBT1Password());

	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc Get the database connection for SYBASE
	 * @return
	 * @throws SQLException
	 */
	public static Connection getSybaseConnection() throws SQLException {

		try {

			Class.forName(getSybaseDriver());
			Log.info("Inside DB2 connection. DB2 driver is loaded successfully");
		} catch (ClassNotFoundException e) {
			Log.info("Please include Classpath  Where your DB2 Driver is located");
			System.out.println("Please include Classpath  Where your DB2 Driver is located");
			e.printStackTrace();
		}
		return DriverManager.getConnection(getSybaseUrl(), getSybaseUsername(), getSybasePassword());

	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc Switch case method to get the database connection 
	 * @return
	 * @throws SQLException
	 */
	public void doDBConnnection(String dbName) throws SQLException {
		switch (dbName) {
		case "db2":
			getDB2Connection();
			if (conn != null) {
				System.out.println(dbName + " Database Connected");
			} else {
				System.out.println(dbName + "connection Failed ");
			}
			break;
		case "sybase":
			getSybaseConnection();
			if (conn != null) {
				System.out.println(dbName + " Database Connected");
			} else {
				System.out.println(dbName + "connection Failed ");
			}
			break;
		default:
			System.out.println("Database not found!");
			break;
		}
	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc verify Database connection, whether database connection is successful or not
	 * @return
	 * @throws SQLException
	 */
	public static void verifyDatabaseConnection(Connection conn, String dbname) throws SQLException {

		String databaseName = dbname;
		if (conn != null) {
			System.out.println(databaseName + " Database Connected");
		} else {
			System.out.println(databaseName + "connection Failed ");
		}
	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc Close the database connection
	 * @return
	 * @throws SQLException
	 */
	public void closeConnection(Connection conn) throws SQLException {
		System.out.println("closeConnection");
		conn.close();
	}

}
