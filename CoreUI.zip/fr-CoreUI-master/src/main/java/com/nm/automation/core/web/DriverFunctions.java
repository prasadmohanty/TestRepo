package com.nm.automation.core.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.LogFactory;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.nm.automation.core.io.Log;
//commnent addded for git demo- pls remove
public class DriverFunctions {

	private WebDriver driver;
	// HtmlUnitDriver driver2;
	private String browser;

	private int implicitWait;
	private int pageLoadTimeOut;
	protected static DesiredCapabilities dCaps;
	public static boolean headless = false;

	public void setHeadless(Boolean headlessinp) {
		headless = headlessinp;
	}

	public WebDriver openBrowser() throws IOException {
		Log.info("Is browser headless: " + headless);
		if (headless == true) {
			Log.info("Actual Browser is Headless");
			try {

				LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log",
						"org.apache.commons.logging.impl.NoOpLog");
				java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
				java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit")
						.setLevel(java.util.logging.Level.OFF);
				driver = new HtmlUnitDriver(true);
				((HtmlUnitDriver) driver).setProxy("10.66.1.108", 3128);

				driver.manage().window().maximize();
				Log.info("Implicit Wait is " + implicitWait);

				driver.manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);
				Log.info("Page load time out is " + pageLoadTimeOut);
				driver.manage().timeouts().pageLoadTimeout(pageLoadTimeOut, TimeUnit.SECONDS);
				driver.manage().timeouts().setScriptTimeout(pageLoadTimeOut, TimeUnit.SECONDS);

				return driver;
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		Log.info("Broswer value is " + browser);

		if ((browser.equalsIgnoreCase("headless"))) {
			Log.info("Actual Browser is Headless");
			try {
				setHeadless(true);
				LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log",
						"org.apache.commons.logging.impl.NoOpLog");
				java.util.logging.Logger.getLogger("org.apache.http").setLevel(java.util.logging.Level.OFF);
				java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit")
						.setLevel(java.util.logging.Level.OFF);
				driver = new HtmlUnitDriver(true);
				((HtmlUnitDriver) driver).setProxy("10.66.1.108", 3128);
				driver.manage().window().maximize();
				Log.info("Implicit Wait is " + implicitWait);
				((HtmlUnitDriver) driver).manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);
				Log.info("Page load time out is " + pageLoadTimeOut);
				((HtmlUnitDriver) driver).manage().timeouts().pageLoadTimeout(pageLoadTimeOut, TimeUnit.SECONDS);
				//((HtmlUnitDriver) driver).manage().timeouts().setScriptTimeout(pageLoadTimeOut, TimeUnit.SECONDS);

				return (HtmlUnitDriver) driver;
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		if (browser.equalsIgnoreCase("firefox")) {
			FirefoxProfile profile = new FirefoxProfile();
			String path = ".\\InpFiles";
			File file = new File(path);
			path = file.getCanonicalPath();
			System.out.println(path);
			// profile.setPreference("browser.download.dir", path);
			profile.setPreference("browser.download.folderList", 2);
			profile.setPreference("browser.download.manager.showWhenStarting", false);
			profile.setPreference("browser.download.dir", path);
			profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			// profile.setPreference("browser.helperApps.neverAsk.saveToDisk",
			// "application/msword,application/csv,text/csv,image/png
			// ,image/jpeg, application/pdf,
			// text/html,text/plain,application/octet-stream");
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/xml");

			profile.setPreference("browser.download.manager.focusWhenStarting", false);
			profile.setPreference("browser.download.useDownloadDir", true);
			profile.setPreference("browser.helperApps.alwaysAsk.force", false);
			profile.setPreference("browser.download.manager.alertOnEXEOpen", false);
			profile.setPreference("browser.download.manager.closeWhenDone", false);
			profile.setPreference("browser.download.manager.showAlertOnComplete", false);
			profile.setPreference("browser.download.manager.useWindow", false);
			profile.setPreference("browser.download.manager.showWhenStarting", false);
			profile.setPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false);
			DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			capabilities.setCapability(FirefoxDriver.PROFILE, profile);
			capabilities.setCapability(CapabilityType.SUPPORTS_ALERTS, "true");
			capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
			driver = new FirefoxDriver(capabilities);

		} else if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "lib\\chromedriver.exe");
			//Trying to launch Chrome as a different user
			/*DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			String chromeProfile = "C:\\Users\\MOH6146\\AppData\\Local\\Google\\Chrome\\User Data\\Profile1";
			ArrayList<String> switches = new ArrayList<String>();
			switches.add("--user-data-dir=" + chromeProfile);
			capabilities.setCapability("chrome.switches", switches);
			driver = new ChromeDriver(capabilities);
			*/
			
			//Trying to launch chrome as sandbox
			ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("test-type");
            chromeOptions.addArguments("start-maximized");
            chromeOptions.addArguments("--disable-extensions");
            chromeOptions.addArguments("no-sandbox");
            driver = new ChromeDriver(chromeOptions);
			
			//driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("iexplore")) {
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);

			System.setProperty("webdriver.ie.driver", "lib\\IEDriverServer.exe");
			driver = new InternetExplorerDriver(capabilities);
		}
		driver.manage().window().maximize();
		Log.info("Implicit Wait is " + implicitWait);
		driver.manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);
		Log.info("Page load time out is " + pageLoadTimeOut);
		driver.manage().timeouts().pageLoadTimeout(pageLoadTimeOut, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(pageLoadTimeOut, TimeUnit.SECONDS);

		return driver;
	}

	public void closebrowser() throws InterruptedException {
		Object[] windows = driver.getWindowHandles().toArray();
		for (int i = 0; i < windows.length; i++) {
			driver.switchTo().window(windows[i].toString());
			driver.close();
		}
	}

	public DriverFunctions(WebDriver driver, String browser, int implicitWait, int pageLoadTimeOut) {
		this.driver = driver;
		this.browser = browser;
		this.implicitWait = implicitWait;
		this.pageLoadTimeOut = pageLoadTimeOut;

	}

	@SuppressWarnings("unused")
	private Boolean checkInstanceofPhantom() throws IOException {
		Boolean found = false;
		String pidInfo;
		Process p = Runtime.getRuntime().exec(System.getenv("windir") + "\\system32\\" + "tasklist.exe");
		BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

		String line;
		while ((line = input.readLine()) != null) {
			pidInfo = line;
			// System.out.println(pidInfo);

			// TODO Auto-generated method stub
			if (pidInfo.contains("phantomjs.exe")) {
				found = true;
			}

		}
		return found;

	}
public static void closeAllBrowserWindows(WebDriver driver) {
		Set<String> handles = driver.getWindowHandles();
		if (handles.size() > 1) {
			Log.info("Closing " + handles.size() + " window(s).");
			for (String windowId : handles) {
				Log.info("-- Closing window handle: " + windowId);
				// this can hang if you replaced the DOM with a document.write
				// before calling this
				driver.switchTo().window(windowId).close();
			}
		} else if (handles.size() == 1) {
			Log.info("Closing last open window.");
		} else {
			Log.info("There were no window handles to close.");
		}
		driver.quit(); // this quit is critical, otherwise last window will hang
						// open
	}
}
