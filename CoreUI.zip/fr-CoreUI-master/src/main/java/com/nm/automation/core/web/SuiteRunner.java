package com.nm.automation.core.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.nm.automation.core.io.Log;
import com.nm.automation.core.reportwriter.GeneratePDFReport;

public abstract class SuiteRunner {
	String packageName;
	static Boolean suiteRun = false;
	static int testCount = 0;
	XmlSuite mySuite = new XmlSuite();

	List<XmlTest> myTests = new ArrayList<XmlTest>();
	XmlTest myTest;
	ArrayList<XmlClass> myClasses = new ArrayList<XmlClass>();
	private static ArrayList<String> groups = new ArrayList<String>();
	public String testPlanName;

	public void run() throws Exception {
		suiteRun = true;
		try {
			if (isGroupPresent()) {
				setHeadless();
				TestNG myTestNG = new TestNG();
				mySuite.setName("Sample Suite");
				// mySuite.setParallel("tests");
				// mySuite.setThreadCount(2);
				// Create an instance of XmlTest and assign a name for it.

				 addtest();

				// add the list of tests to your Suite.
				mySuite.setTests(myTests);

				// Add the suite to the list of suites.
				List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
				mySuites.add(mySuite);

				// Set the list of Suites to the testNG object you created
				// earlier.
				myTestNG.setXmlSuites(mySuites);
				System.out.println("Suite is " + mySuites);
				// invoke run() - this will run your class.
				myTestNG.run();
			} else {
				Log.error("Group Declaration Not Present in TestSuite.xls");
				throw new Exception("Group Declaration Not Present in TestSuite.xls");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addPackage(String packageName) {
		this.packageName = packageName;
		System.out.println("Package Name--->"+this.packageName);
	}

	// public void addClasses() ;
	public void addClass(String ClassName) {
		myClasses.add(new XmlClass(packageName + "." + ClassName));
		System.out.println("classname-->"+ClassName);

	}

	public void addtest() {
		String testName = "test" + testCount;
		System.out.println("TestName------>"+testName);
		// myClasses.removeAll(myClasses);
		XmlTest myTest = new XmlTest(mySuite);
		myTest.setName(testName);
		testCount++;
		ArrayList<XmlClass> newList = (ArrayList<XmlClass>) myClasses.clone();

		myTest.setXmlClasses(newList);
		myTests.add(myTest);
		myClasses.removeAll(myClasses);

	}

	public abstract void Run() throws Exception;

	public abstract void validategroups();

	private boolean isGroupPresent() throws IOException {
		FileInputStream file;
		Workbook workbook = null;
		Sheet sheet;
		validategroups();
		System.out.println("***---------Is Testsuite Present---------------");
		Boolean found = false;
		try {
			file = new FileInputStream(new File("TestSuite.xls"));
			workbook = new HSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);
		} catch (IOException e) {
			System.out.println("Its an xlsx file");
			file = new FileInputStream(new File("TestSuite.xlsx"));
			workbook = new XSSFWorkbook(file);
			sheet = workbook.getSheetAt(0);

		} finally {
			workbook.close();
		}
		System.out.println("No of groups :" + getGroups().size());
		for (int i = 0; i < getGroups().size(); i++) {
			try {
				int rownum = findRow(sheet, getGroups().get(i));
				if (rownum > 0) {
					System.out.println("Rownum " + rownum);
					Log.info("Group " + getGroups().get(i) + "  found");
					found = true;
				}
			} catch (Exception e) {
				Log.error("The Group is not Present");

			}
		}

		file.close();
		return found;
	}

	public void validategroups(String group) {
		this.groups.add(group);
	}

	private ArrayList<String> getGroups() {
		return groups;
	}

	private int findRow(Sheet sheet, String cellContent) {
		/*
		 * This is the method to find the row number
		 */

		int rowNum = 0;
		for (Row row : sheet) {
			for (Cell cell : row) {
				if (cell.getRichStringCellValue().getString().trim().equalsIgnoreCase(cellContent)) {
					System.out.println("*************** " + cell.getRichStringCellValue().getString().trim());
					rowNum = row.getRowNum();
					System.out.println("Row Number is " + rowNum);
					try {
						testPlanName = sheet.getRow(rowNum).getCell(2).toString();
						Log.info("Test Plan Name:" + testPlanName);
						GeneratePDFReport.arr_testPlanName = testPlanName;
						//BaseApiTestType.testPlanName = testPlanName;
					} catch (Exception e) {
						testPlanName = "";
					}
					return rowNum;
				}
				;
			}

		}
		return rowNum;
	}

	public abstract void setHeadless();

	public void setHeadless(Boolean value) {
		System.out.println("Inside setheadless in suite runner : " + value);
		DriverFunctions.headless = value;
	}
}
