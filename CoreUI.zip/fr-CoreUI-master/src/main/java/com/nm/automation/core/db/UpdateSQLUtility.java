package com.nm.automation.core.db;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
/**
 * @ClassName: UpdateSQLUtility
 * @Desc: Defines Database Update utility functions
 * @author Subhasmita
 * @Date 25-April-2017
 *
 */
public class UpdateSQLUtility {
	public DBConnectionUtility dbConnectionUtility;
	Connection conn = null;
	String path = System.getProperty("user.dir") + "\\sql\\UpdateSql.txt";

	public UpdateSQLUtility() throws IOException {
		dbConnectionUtility = new DBConnectionUtility();

	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc This function performs all the update query action by database name
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void doUpdate(String dbName) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				System.out.println("DB name ::"+dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				System.out.println("Connection:::"+conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			// @SuppressWarnings("resource")
			@SuppressWarnings("resource")
			Scanner linReader = new Scanner(new File(path));
			int i = 1;
			while (linReader.hasNext()) {

				String line = linReader.nextLine();
				System.out.println(line);
				statement = conn.createStatement();
				statement.executeUpdate(line);
				System.out.println(i + "-Record Modified ");
				i++;
			}

		} catch (Exception e) {
			e.getStackTrace();
		}
	dbConnectionUtility.closeConnection(conn);
	}
	
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc This function performs all the update query action by line num mentioned in updatesql.txt
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void updateQueryByLineNum(String dbName, int lineNum) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				System.out.println("DB name ::"+dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				System.out.println("Connection:::"+conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = Files.readAllLines(Paths.get(path)).get(lineNum);
			System.out.println(line);
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			System.out.println("Mentioned line num not found ");
		}
		 dbConnectionUtility.closeConnection(conn);
	}
	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc This function performs all the update query action by sql statememt
	 * @param dbName
	 * @param sqlStatement
	 * @throws SQLException
	 */
	public void updateQueryByStatement(String dbName, String sqlStatement) throws SQLException {
		try {
			if (dbName.contentEquals("db2")) {
				conn = DBConnectionUtility.getDB2Connection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);

			} else if (dbName.contentEquals("sybase")) {
				conn = DBConnectionUtility.getSybaseConnection();
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			} else {
				System.out.println("DB name ::" + dbName);
				conn = DBConnectionUtility.getDBT1Connection();
				System.out.println("Connection:::" + conn);
				DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			}
			DBConnectionUtility.verifyDatabaseConnection(conn, dbName);
			Statement statement = null;
			String line = sqlStatement;
			System.out.println(line);
			statement = conn.createStatement();
			statement.executeUpdate(line);

		} catch (Exception e) {
			System.out.println("Mentioned line num not found ");
		}
		dbConnectionUtility.closeConnection(conn);
	}
}
