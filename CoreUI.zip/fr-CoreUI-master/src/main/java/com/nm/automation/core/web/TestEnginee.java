package com.nm.automation.core.web;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

import com.nm.automation.core.io.Log;



public class TestEnginee extends ReusableTestKeywords {
	//public static int testCalltimes;
	public static Map<String, Integer> tcInvocation= new HashMap<String, Integer>();;
	
	/*----------------------------------------------------------------------------------------------------------------------
	 *                                                    CONSTRUCTORS                                                |
	 ----------------------------------------------------------------------------------------------------------------------*/

	public TestEnginee() {
		super(driver);
	}

	
	public TestEnginee(String tcName, String suiteName) {	
		super(driver);
		try{
			int numofOccurance=(int) tcInvocation.get(tcName);
			numofOccurance++;
			tcInvocation.put(tcName, numofOccurance);
		}
		catch(NullPointerException e){
			tcInvocation.put(tcName, 0);
		}
		
		int newNumOfOccurance=(int) tcInvocation.get(tcName);
		if(newNumOfOccurance>0){
			reportPath = reportPathSuite + "\\" + tcName+"_"+newNumOfOccurance;
		}
		else{
		reportPath = reportPathSuite + "\\" + tcName;
		}
		this.tcName = tcName;	
		Log.info("ReportPath from test level " + reportPath);
	}

	
	
}