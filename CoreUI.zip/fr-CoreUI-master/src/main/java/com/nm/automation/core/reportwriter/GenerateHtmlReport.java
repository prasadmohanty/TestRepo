package com.nm.automation.core.reportwriter;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;

import com.itextpdf.text.DocumentException;
import com.nm.automation.core.io.Log;
import com.nm.automation.core.web.TestEnginee;

public class GenerateHtmlReport {


	List<String[]> stepsDetails = new ArrayList<String[]>();
	String[] stepDetails = new String[4];
	List<String> htmlrep = new ArrayList<String>();
	List<String> htmlrepsuite = new ArrayList<String>();
	static String coordinateList;
	static List<String> status = new ArrayList<String>();
	static int count = 1;
	int serielNo;
	boolean flag_Complete = false;
	static Date startTime;
	File[] listOfFolders;
	String[] teststatus;
	String[] arrTcDesc;

	static GeneratePDFReport gpr = new GeneratePDFReport();

	public void isTestComplete(Boolean val) {
		flag_Complete = val;

	}

	public void createSuiteReport(String projectPath, Date startTime, Date endTime) {
		if (count > 1) {
			return;
		}
		count++;
		Log.info("************************************************************");
		Log.info("-         Inside Create Suite Report                        -");
		Log.info("          Start time is :                        " + startTime);
		Log.info("          End time is :                          " + endTime);
		String htmlFile = projectPath + "\\report.html";
		Log.info("          File name :                             " + htmlFile);

		long diff = endTime.getTime() - startTime.getTime();
		int diffsec = (int) (diff / (1000));
		int min = diffsec / 60;
		int sec = diffsec % 60;
		Log.info(min + "." + sec);

		Log.info("Differnece is " + diff);
		int j = 0;
		try {

			File folder = new File(projectPath);
			listOfFolders = folder.listFiles();
			String testCases[] = new String[listOfFolders.length];
			teststatus = new String[listOfFolders.length];
			arrTcDesc = new String[listOfFolders.length];
			Log.info("NO of folders " + listOfFolders.length);
			for (int i = 0; i < listOfFolders.length; i++) {
				if (listOfFolders[i].isDirectory()) {
					System.out.println(listOfFolders[i].getName());
					testCases[i] = listOfFolders[i].getName();
					File[] listOfFiles = listOfFolders[i].listFiles();
					for (j = 0; j < listOfFiles.length; j++) {
						if (listOfFiles[j].isFile()) {
							if (listOfFiles[j].getName().equalsIgnoreCase("status.txt")) {
								FileInputStream fstream = new FileInputStream(projectPath + "\\"
										+ listOfFolders[i].getName() + "\\" + listOfFiles[j].getName());
								DataInputStream in = new DataInputStream(fstream);
								BufferedReader br = new BufferedReader(new InputStreamReader(in));
								String strLine;

								if ((strLine = br.readLine()) != null) {
									String[] data = strLine.split("###");
									teststatus[i] = data[0];
									arrTcDesc[i] = data[1];
								}
								in.close();
							}
						}

					}
				}
			}
			htmlrepsuite.add("<!DOCTYPE html>");
			htmlrepsuite.add("<html>");
			htmlrepsuite.add("<head>");
			htmlrepsuite.add("<style>");
			htmlrepsuite.add("#header {");
			htmlrepsuite.add("background-color:navy;");
			htmlrepsuite.add("color:silver;");
			htmlrepsuite.add("text-align:center;");
			htmlrepsuite.add("padding:5px;}");
			htmlrepsuite.add("#article {");
			htmlrepsuite.add("width:350px;");
			htmlrepsuite.add("float:left;");
			htmlrepsuite.add("text-align:center;");
			htmlrepsuite.add("padding:10px;}");
			htmlrepsuite.add("#footer {");
			htmlrepsuite.add(" background-color:black;");
			htmlrepsuite.add("color:white;");
			htmlrepsuite.add("clear:both;");
			htmlrepsuite.add("text-align:center;");
			htmlrepsuite.add("position: relative;");
			htmlrepsuite.add("bottom:0;");
			htmlrepsuite.add("right: 0;");
			htmlrepsuite.add("left: 0;");
			htmlrepsuite.add("height:30px;}");
			htmlrepsuite.add("table, th, td {");
			htmlrepsuite.add("border: 2px solid black;");
			htmlrepsuite.add("border-collapse: collapse;");
			htmlrepsuite.add("text-align:center}");
			htmlrepsuite.add("th, td {padding: 5px;}</style>");
			htmlrepsuite.add("</head>");
			htmlrepsuite.add("<body>");
			htmlrepsuite.add("<div id=\"wrapper\">");
			htmlrepsuite.add("<div id=\"header\">");
			htmlrepsuite.add(
					"<img src=\".\\image\\nmimg.jpg\" alt=\"HTML6 Icon\" style=\"width:130px;height:98px\" align=\"left\">");
			htmlrepsuite.add(
					"<img src=\".\\image\\nmactual.jpg\" alt=\"HTML5 Icon\" style=\"width:130px;height:98px\" align=\"right\">");
			htmlrepsuite.add("<h1 align=\"center\"> TEST SUITE REPORT</h1>");
			htmlrepsuite.add("<br></div>");
			htmlrepsuite.add("<div id=\"Section\">");
			htmlrepsuite.add("<br><br>");
			htmlrepsuite.add("<span align=\"left\"> <b> Execution Start Time: " + startTime + "</b></span>");
			htmlrepsuite.add("<span align=\"right\"> <b>Execution Time: " + min + " mins:" + sec + " secs </b></span>");
			htmlrepsuite.add("<span align=\"left\"><b> Execution End Time: " + endTime + "</b></span>");

			htmlrepsuite.add("<br><br>");
			htmlrepsuite.add("<div id=\"Section1\">");
			htmlrepsuite.add("<table style=\"width:100%\" align=\"center\">");
			htmlrepsuite.add("<tr>");
			htmlrepsuite.add("<th>Sl.No</th>");
			htmlrepsuite.add("<th>Test Case Details</th>");
			htmlrepsuite.add("<th>Status</th>");

			htmlrepsuite.add("</tr>");

			for (int i = 0; i < listOfFolders.length; i++) {
				Log.info("Value of I" + i);
				htmlrepsuite.add("<tr>");
				htmlrepsuite.add("<td>" + (i + 1) + "</td>");
				htmlrepsuite.add("<td>");
				htmlrepsuite.add("<a href=.\\" + listOfFolders[i].getName() + "\\" + listOfFolders[i].getName()
						+ ".html>" + listOfFolders[i].getName() + " - " + arrTcDesc[i] + "</a>");
				htmlrepsuite.add("</td>");
				if (teststatus[i].equalsIgnoreCase("Pass")) {
					htmlrepsuite.add("<td bgcolor=\"green\">" + teststatus[i] + "</td>");
				} else if (teststatus[i].equalsIgnoreCase("Fail")) {
					htmlrepsuite.add("<td bgcolor=\"red\">" + teststatus[i] + "</td>");
				} else if (teststatus[i].equalsIgnoreCase("Incomplete")) {
					htmlrepsuite.add("<td bgcolor=\"darkorange\">" + teststatus[i] + "</td>");
				}
				// else if (teststatus[i].equalsIgnoreCase("Fail")){

				else {
					htmlrepsuite.add("<td bgcolor=\"yellow\">" + teststatus[i] + "</td>");
				}

				//

				htmlrepsuite.add("</tr>");

			}

			htmlrepsuite.add("</table>");
			htmlrepsuite.add("</div>");
			htmlrepsuite.add("<br><br><br><br>");
			htmlrepsuite.add("<div id=\"footer\">");
			htmlrepsuite.add("Copyright @ nm.com");
			htmlrepsuite.add("</div>");
			htmlrepsuite.add("</div>");
			htmlrepsuite.add("</body>");
			htmlrepsuite.add("</html>");
			File file = new File(htmlFile);
			if (!file.exists()) {
				BufferedWriter bw = new BufferedWriter(new FileWriter(file));
				for (int num_tcs = 0; num_tcs < htmlrepsuite.size(); num_tcs++) {
					bw.write(htmlrepsuite.get(num_tcs));
				}

				bw.close();
			}
			System.out.println("Successfully generated the report.html file in this location  " + projectPath);

			Log.info("-          Create Suite Report    - ENDS                    -");
			Log.info("************************************************************");
			File repfile = new File(projectPath);
			repfile.mkdirs();
			File source = new File(".\\image");
			File dest = new File(repfile + "\\image");
			try {
				FileUtils.copyDirectory(source, dest);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		gpr.setListofFolder(listOfFolders);
		gpr.setarrTcDesc(arrTcDesc);
		gpr.settestStatus(teststatus);

		try {
			gpr.createPDF(projectPath, startTime, endTime);
		} catch (IOException | DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void createTestReport(ArrayList<ArrayList<String[]>> testDetails, ArrayList<String> browserlist,
			String reportPath, String tcName, String tcDescription) throws IOException {
		Date date = new Date();
		startTime = date;
		System.out.println("Inside create TestReprot********");
		System.out.println("Test Details:::----------------"+testDetails);
		Log.info("************************************************************");
		Log.info("-         Inside Create Test Report                        -");
		Log.info("           Test Case Name :              " + tcName);
		String testCaseStatus = "Pass";
		Boolean notRun = true;
		// HTML REPORT FOR TEST CASE
		htmlrep.add("<!DOCTYPE html>");
		htmlrep.add("<html>");
		htmlrep.add("<head>");
		htmlrep.add("<style>");
		htmlrep.add("#header {");
		htmlrep.add("background-color:navy;");
		htmlrep.add("color:silver;");
		htmlrep.add("text-align:center;");
		htmlrep.add("padding:5px;}");
		htmlrep.add("#article {");
		htmlrep.add("width:350px;");
		htmlrep.add("float:left;");
		htmlrep.add("text-align:center;");
		htmlrep.add("padding:10px;}");
		htmlrep.add("#footer {");
		htmlrep.add(" background-color:black;");
		htmlrep.add("color:white;");
		htmlrep.add("clear:both;");
		htmlrep.add("text-align:center;");
		htmlrep.add("position: relative;");
		htmlrep.add("bottom:0;");
		htmlrep.add("right: 0;");
		htmlrep.add("left: 0;");
		htmlrep.add("height:30px;}");
		htmlrep.add("table, th, td {");
		htmlrep.add("border: 2px solid black;");
		htmlrep.add("border-collapse: collapse;");
		htmlrep.add("text-align:center}");
		htmlrep.add("font-family:verdana");
		htmlrep.add("th, td {padding: 5px;}</style>");
		htmlrep.add("</head>");
		htmlrep.add("<body>");
		htmlrep.add("<div id=\"wrapper\">");
		htmlrep.add("<div id=\"header\">");
		htmlrep.add(
				"<img src=\".\\image\\nmimg.jpg\" alt=\"HTML5 Icon\" style=\"width:130px;height:98px\" align=\"left\">");
		htmlrep.add(
				"<img src=\".\\image\\nmactual.jpg\" alt=\"HTML5 Icon\" style=\"width:130px;height:98px\" align=\"right\">");
		htmlrep.add("<h1 align=\"center\">FUNCTIONAL TEST REPORT</h1>");
		htmlrep.add("<br>");
		//htmlrep.add(
				//"</div><div id=\"section\">Executed On: <span id=\"date\"></span><script>document.getElementById(\"date\").innerHTML = Date();</script>");
		htmlrepsuite.add("<span align=\"left\"> <b> Execution on: " + startTime + "</b></span>");
		htmlrep.add("<div id=\"report\" class=\"container\">");
		htmlrep.add("<h2 align=\"center\">TEST CASE ID :" + tcName + "</h2>");
		htmlrep.add("<br>");
		// htmlrep.add("<h2 align=\"center\">TEST CASE NAME :" + tcDescription
		// + "</h2>");
		htmlrep.add("</div>");

		for (int numOfTests = 0; numOfTests < testDetails.size(); numOfTests++) {
			stepsDetails = testDetails.get(numOfTests);
			Log.info("No of steps are " + stepsDetails.size());
			htmlrep.add("<div id=\"section\">");
			htmlrep.add("<h3 align=\"center\">BROWSER : " + browserlist.get(numOfTests).toUpperCase() + "</h3>");
			htmlrep.add("<h3 align=\"center\">TEST CASE NAME : " + tcDescription.toUpperCase() + "</h3>");
			htmlrep.add("<p>");
			htmlrep.add("font-family:verdana");
			htmlrep.add("<table style=\"width:100%\" align=\"center\">");
			htmlrep.add("<tr>");
			htmlrep.add("<th  bgcolor=\"teal\">Sl.No </th>");
			htmlrep.add("<th  bgcolor=\"teal\">Test Step Desc</th>");
			htmlrep.add("<th  bgcolor=\"teal\">Status</th>");
			htmlrep.add("<th  bgcolor=\"teal\">Screenshot</th>");
			htmlrep.add("</tr>");

			for (int i = 0; i < stepsDetails.size(); i++) {
				// System.out.println("size of the
				// stepsdetails--->"+stepsDetails.size());
				// System.out.println("value of the steps detail
				// array"+stepsDetails.get(0));
				serielNo = i + 1;
				htmlrep.add("<tr>");
				htmlrep.add("<td>" + serielNo + "</td>");
				htmlrep.add("<td>" + stepsDetails.get(i)[0] + "</td>");
				if (stepsDetails.get(i)[1].equalsIgnoreCase("Pass")) {
					htmlrep.add("<td bgcolor=\"green\">" + stepsDetails.get(i)[1] + "</td>");
					notRun = false;
				} else if (stepsDetails.get(i)[1].contains("Fail")) {
					htmlrep.add("<td bgcolor=\"red\">" + stepsDetails.get(i)[1] + "</td>");
					testCaseStatus = "Fail";
					notRun = false;
				} else {
					htmlrep.add("<td bgcolor=\"blue\">" + stepsDetails.get(i)[1] + "</td>");
					// testCaseStatus = "Fail";
					notRun = false;
				}
				String screenshotPath = System.getProperty("user.dir");
				htmlrep.add("<td><a href= \"file:///" + "" + screenshotPath + "" + "\\screenshots\\" + serielNo
						+ ".png\">SCREENSHOT</a></td>");
				
				// htmlrep.add("<td><a href=\"hi\">SCREENSHOT</a></td>");
				// htmlrep.add("<td><a href=\"./" + "/screenshots/" + serielNo +
				// ".png\">SCREENSHOT</a></td>");
				htmlrep.add("</tr>");

			}
			htmlrep.add(" </table></p></p>");
			htmlrep.add("</div>");
		}
		htmlrep.add("</div>");
		htmlrep.add("<div id=\"footer\">");
		htmlrep.add("Copyright @ nm.com");
		htmlrep.add("</div>");
		htmlrep.add("</body>");
		htmlrep.add("</html>");

		File file = new File(reportPath);
		System.out.println("report Path inside create test report " + reportPath);
		file.mkdirs();
		File source = new File(".\\image");
		File dest = new File(file + "\\image");
		try {
			FileUtils.copyDirectory(source, dest);
		} catch (IOException e) {
			e.printStackTrace();
		}
		int newNumOfOccurance = (int) TestEnginee.tcInvocation.get(tcName);
		if (newNumOfOccurance > 0) {

			tcName = tcName + "_" + newNumOfOccurance;
		}
		FileWriter f1 = new FileWriter(file + "\\" + tcName + ".html");
		FileWriter f2 = new FileWriter(file + "\\status.txt");
		if (notRun == false) {
			if (testCaseStatus.contains("Fail")) {
				f2.write("Fail");
			} else {
				if (flag_Complete == false) {
					f2.write("Incomplete");
				} else {
					f2.write(testCaseStatus);
				}
			}
		}

		else {
			f2.write("NotRun");
		}
		f2.write("###");

		f2.write(tcDescription);
		for (int j = 0; j < htmlrep.size(); j++) {
			f1.write(htmlrep.get(j));

		}
		f1.close();
		f2.close();
		Log.info("-          Create Test Report For  " + tcName + "   - ENDS                    -");
		Log.info("*****************************************************************************");

	}
}
