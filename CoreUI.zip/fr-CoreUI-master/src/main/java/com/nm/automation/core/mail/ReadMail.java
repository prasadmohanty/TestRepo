package com.nm.automation.core.mail;

public class ReadMail {

}
