package com.nm.automation.core.db;

import org.apache.commons.codec.binary.Base64;

/**
 * 
 * @author Subhasmita Nayak
 * @Url: https://www.base64decode.org/
 * This page is used for username and password encryption/Decryption 
 * 
 *
 */

public class Base64Encoder {
	
	/**@author Subhasmita
	 * Function is used to read encrypted value
	 * @param value
	 * @return
	 */
	public String encode(String value){
		byte[] bytesEncoded=Base64.encodeBase64(value.getBytes());
		String result=new String(bytesEncoded);
		System.out.println("Encoded value::"+result);
		return result;
		
	}
	/**
	 * @author Subhasmita
	 * Function is used to convert encrypted value to decrypted value
	 * @param value
	 * @return
	 */
	public String decode(String value){
		byte[] bytesDecoded=Base64.decodeBase64(value.getBytes());
		String result=new String(bytesDecoded);
		System.out.println("decoded value::"+result);
		return result;
		
	}
	
	public static void main(String[] args) {
		Base64Encoder be=new Base64Encoder();
		be.decode("bGlua3U=");
	

	}

}
