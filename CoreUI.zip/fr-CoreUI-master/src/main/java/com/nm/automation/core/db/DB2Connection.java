package com.nm.automation.core.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 
 * @author nay6538 This page defines the database connection for DB2.
 */
public class DB2Connection {
	public static void main(String[] argv) throws SQLException {
		try {
			Class.forName("com.ibm.db2.jcc.DB2Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Please include Classpath  Where your DB2 Driver is located");
			e.printStackTrace();
			return;
		}
		System.out.println("DB2 driver is loaded successfully");
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		boolean found = false;
		try {
			conn = DriverManager.getConnection("jdbc:db2://jade006:5156/DISTOP29", "sin2433", "nmho0123");
			if (conn != null) {
				System.out.println("DB2 Database Connected");
			} else {
				System.out.println("Db2 connection Failed ");
			}
			//pstmt = conn.prepareStatement("select *from commisns.BONUS_YEAR");
			pstmt = conn.prepareStatement("select *from commisns.BONUS_YEAR");
			rset = pstmt.executeQuery();
			if (rset != null) {

				while (rset.next()) {
					found = true;
					System.out.println("COMP_PROGRAM_NUM: " + rset.getString("LAST_MODIFIED_DTM"));
					// System.out.println("Name: " + rset.getString("name"));
					DBTablePrinter.printTable(conn, "commisns.BONUS_YEAR");
				}
			}
			if (found == false) {
				System.out.println("No Information Found");
			}
		} catch (SQLException e) {
			System.out.println("DB2 Database connection Failed");
			e.printStackTrace();
			return;
		}
		conn.close();
	}

	@SuppressWarnings("unused")
	private static Connection getConnection(String url, String username, String pwd) throws Exception {
		Class.forName("org.hsqldb.jdbcDriver");
		// String url = "jdbc:hsqldb:mem:data/tutorial";
		return DriverManager.getConnection(url, username, pwd);
	}

}
