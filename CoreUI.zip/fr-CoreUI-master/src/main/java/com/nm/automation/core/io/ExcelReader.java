/**************************************************
#Project Name: North Western Mutual - Selenium Framework
#Function Name: readExcel()
#Author: Subhasmita
#Description: This function reads the excelsheet containing test data related to test case.
#Date of creation: 09-May-15
#Input Parameters:File Path,Test Class Name
#Name of person modifying: Tester
#Date of modification: 
**************************************************/

package com.nm.automation.core.io;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;


public class ExcelReader {

	int intColumnValue;
	int intNum_Val_Row = 0;
	static String testDescription;
	Workbook wb;
	static Sheet S1;
	static int numCols = 1;
	String oldStrFilePath;
	int cellCount = 0;

	public void openExecl(String newStrFilePath) {
		System.out
				.println("****************************************************");
		Log.info("New File Path ---------" + newStrFilePath);
		Log.info("Old File Path ---------" + oldStrFilePath);
		System.out
				.println("****************************************************");

		try {
			newStrFilePath = newStrFilePath + ".xls";
			if (numCols == 1 || (!newStrFilePath.equals(oldStrFilePath))) {
				S1 = null;
				wb = Workbook.getWorkbook(new File(newStrFilePath));
				System.out.println(wb.getNumberOfSheets() + "********");
				System.out.println(wb.getSheet(0).getName());
				S1 = wb.getSheet(0);
				Log.info("Opening the Excel");
			} else {
				Log.info("Reusing the excel");
			}
		} catch (BiffException e) {

		} catch (IOException e) {
			e.printStackTrace();
		}
		oldStrFilePath = newStrFilePath;
		numCols++;
	}

	public Object[][] defreadExcel(String strClassName) throws BiffException,
			IOException {
		ArrayList<Integer> listrow_val = new ArrayList<Integer>();
		intNum_Val_Row = 0;
		cellCount=0;
		System.out
				.println("************************************************************");
		Log.info("---------------Inside Read Excel---------------");
		Log.info("No of Total Rows are " + S1.getRows());
		Log.info("No of Total Cols are " + S1.getColumns());
		Log.info(" Class Name is: " + strClassName);
		int rownum = S1.findCell(strClassName).getRow();
		Log.info("The TestCase is present at  " + rownum + " row.");

		Boolean dataFound = true;
		while (dataFound.equals(true)) {
			for (int j = 0; j < S1.getColumns(); j++) {
				if (j == (S1.getColumns() - 1)) {
					dataFound = false;
				}

				try {
					if (S1.getCell(j, rownum).getContents().trim().length() <= 0) {
						dataFound = false;
					}

					else {
						Log.info("Cellcount is :" + cellCount);
						Log.info("Value is "
								+ S1.getCell(j, rownum).getContents());
						Log.info("length is :"
								+ S1.getCell(j, rownum).getContents().length());

						cellCount++;
					}

				} catch (NullPointerException e) {
					dataFound = false;
				}
			}
		}

		Log.info("No of Parameters passed to the Test Case(Including TC ID and TC Desc): "
				+ cellCount);
		/*************************************************************************
		 * get the number of Times the TC is present in the Input Excel. Store
		 * the value in the variable intNum_Val_Row
		 **************************************************************************/
		for (int j = 0; j < S1.getRows(); j++) {
			if (S1.getCell(0, j).getContents().equals(strClassName)) {
				testDescription = S1.getCell(1, j).getContents();
				listrow_val.add(j);
				intNum_Val_Row++;
			}
		}

		// Reads the TC related values from the Sheet
		Object[][] arrTable = new Object[intNum_Val_Row][cellCount - 2];
		for (int i = 0; i < intNum_Val_Row; i++) {
			for (int k = 2; k < cellCount; k++) {
				if (!S1.getCell(k, listrow_val.get(i)).getContents().isEmpty()) {
					arrTable[i][k - 2] = S1.getCell(k, listrow_val.get(i))
							.getContents();
				}
			}

		}

		// Log.info("No of values: " + intColumnValue);
		Log.info(" Test Case Desc:" + testDescription);
		Log.info(" No of Rows for the Test Case :" + intNum_Val_Row);
		System.out
				.println("************************************************************");

		return arrTable;
	}

	public String getTestDescription() {
		Log.info("inside getTestDescription " + testDescription);
		return testDescription;
	}
}
