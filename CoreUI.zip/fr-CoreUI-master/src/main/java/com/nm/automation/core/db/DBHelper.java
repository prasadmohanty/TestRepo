package com.nm.automation.core.db;

import java.io.IOException;
import java.sql.SQLException;

/**
 * @ClassName: DBConnectionUtility
 * @Desc: Defines all the Database related utility functions
 * @author Subhasmita
 * @Date 25-April-2017
 *
 */
public class DBHelper {

	public static final String SQL_INSERT = "insert";
	public static final String SQL_SELECT = "select";
	public static final String SQL_UPDATE = "update";
	public static final String SQL_DELETE = "delete";

	public DBConnectionUtility dbConnectionUtility;
	public InsertSQLUtility insertsqlUtility;
	public UpdateSQLUtility updateSqlUtility;
	public DeleteSQLUtility deleteSqlUtility;
	public SelectSQLUtility selectSqlUtility;

	public DBHelper() throws IOException {
		dbConnectionUtility = new DBConnectionUtility();
		// insertsqlUtility = new InsertSQLUtility();
		// updateSqlUtility = new UpdateSQLUtility();
		// deleteSqlUtility = new DeleteSQLUtility();
		// selectSqlUtility = new SelectSQLUtility();
	}

	/**
	 * @author Subhasmita
	 * @Date 25-April-2017
	 * @Desc A switch case method to execute different queries
	 * @throws SQLException
	 * @throws IOException
	 */
	public void executeQuery(String sqlOption, String dbName) throws SQLException, IOException {

		System.out.println("Inside Execute query");
		switch (sqlOption) {
		case SQL_SELECT:
			selectSqlUtility = new SelectSQLUtility();
			System.out.println("Inside SQL_SELECT");
			selectSqlUtility.selectQuery(dbName);
			break;
		case SQL_INSERT:
			insertsqlUtility = new InsertSQLUtility();
			System.out.println("Inside SQL_INSERT");
			insertsqlUtility.doInsert(dbName);
			break;
		case SQL_UPDATE:
			updateSqlUtility = new UpdateSQLUtility();
			System.out.println("Inside SQL_UPDATE");
			updateSqlUtility.doUpdate(dbName);
			break;
		case SQL_DELETE:
			deleteSqlUtility = new DeleteSQLUtility();
			System.out.println("Inside SQL_DELETE");
			deleteSqlUtility.doDelete(dbName);
			break;
		default:
			break;
		}
	}

	/**
	 * @author Subhasmita
	 * @Date 27-June-2017
	 * @Desc A switch case method to execute different queries
	 * @throws SQLException
	 * @throws IOException
	 */
	public void executeQueryByLine(String sqlOption, String dbName, int lineNum,int colIndex) throws SQLException, IOException {

		System.out.println("Inside Execute query");
		switch (sqlOption) {
		case SQL_SELECT:
			selectSqlUtility = new SelectSQLUtility();
			System.out.println("Inside SQL_SELECT");
			selectSqlUtility.selectQuery(dbName, lineNum,colIndex);
			break;
		case SQL_INSERT:
			insertsqlUtility = new InsertSQLUtility();
			System.out.println("Inside SQL_INSERT");
			insertsqlUtility.insertQueryByLineNum(dbName, lineNum);
			break;
		case SQL_UPDATE:
			updateSqlUtility = new UpdateSQLUtility();
			System.out.println("Inside SQL_UPDATE");
			updateSqlUtility.updateQueryByLineNum(dbName, lineNum);
			break;
		case SQL_DELETE:
			deleteSqlUtility = new DeleteSQLUtility();
			System.out.println("Inside SQL_DELETE");
			deleteSqlUtility.deleteQueryByLineNum(dbName, lineNum);
			break;
		default:
			break;
		}
	}
	
	/**
	 * @author Subhasmita
	 * @Date 27-June-2017
	 * @Desc A switch case method to execute different queries
	 * @throws SQLException
	 * @throws IOException
	 */
	public void executeQueryByStatement(String sqlOption, String dbName, String sqlStatement,String colName) throws SQLException, IOException {

		System.out.println("Inside Execute query");
		switch (sqlOption) {
		case SQL_SELECT:
			selectSqlUtility = new SelectSQLUtility();
			System.out.println("Inside SQL_SELECT");
			selectSqlUtility.selectQuery(dbName, sqlStatement,colName);
			break;
		case SQL_INSERT:
			insertsqlUtility = new InsertSQLUtility();
			System.out.println("Inside SQL_INSERT");
			insertsqlUtility.insertQueryByStatement(dbName, sqlStatement);
			break;
		case SQL_UPDATE:
			updateSqlUtility = new UpdateSQLUtility();
			System.out.println("Inside SQL_UPDATE");
			updateSqlUtility.updateQueryByStatement(dbName, sqlStatement);
			break;
		case SQL_DELETE:
			deleteSqlUtility = new DeleteSQLUtility();
			System.out.println("Inside SQL_DELETE");
			deleteSqlUtility.deleteQueryByStatement(dbName, sqlStatement);
			break;
		default:
			break;
		}
	}

}
