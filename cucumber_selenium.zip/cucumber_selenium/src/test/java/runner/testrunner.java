package runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
features = "Feature/test.feature"
,glue= {"/cucumber_selenium/src/test/java/seleniumgluecode/test.java"},

plugin = { "pretty","html:target/cucumber-reports"},
monochrome = true)

public class testrunner {

}
